# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------


#
# Delete any existing table `wp_afp_categories`
#

DROP TABLE IF EXISTS `wp_afp_categories`;


#
# Table structure of table `wp_afp_categories`
#

CREATE TABLE `wp_afp_categories` (
  `cat_id` int(5) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) DEFAULT NULL,
  `cat_description` text,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_afp_categories (2 records)
#
 
INSERT INTO `wp_afp_categories` VALUES (1, 'Graphic Design', '') ; 
INSERT INTO `wp_afp_categories` VALUES (2, 'Web Design', '') ;
#
# End of data contents of table wp_afp_categories
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------


#
# Delete any existing table `wp_afp_items`
#

DROP TABLE IF EXISTS `wp_afp_items`;


#
# Table structure of table `wp_afp_items`
#

CREATE TABLE `wp_afp_items` (
  `item_id` int(5) NOT NULL AUTO_INCREMENT,
  `item_title` varchar(100) DEFAULT NULL,
  `item_link` varchar(500) DEFAULT NULL,
  `item_description` text,
  `item_client` varchar(100) DEFAULT NULL,
  `item_date` date DEFAULT NULL,
  `item_thumbnail` varchar(200) DEFAULT NULL,
  `item_image` varchar(200) DEFAULT NULL,
  `item_category` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_afp_items (2 records)
#
 
INSERT INTO `wp_afp_items` VALUES (1, 'School Flyers', '', '', 'Brookline College', '1970-01-01', 'http://localhost:8888/wp-content/uploads/2014/05/LizPonceLogo.png', 'http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png', 'Graphic Design') ; 
INSERT INTO `wp_afp_items` VALUES (2, 'Web Test', '', '', '', '0000-00-00', 'http://localhost:8888/wp-content/uploads/2014/05/LizPonce_WebLogo.png', 'http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png', 'Web Design') ;
#
# End of data contents of table wp_afp_items
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-04-27 04:13:11', '2014-04-27 04:13:11', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=477 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (155 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Liz Ponce', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Designer Extraordinaire', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'liz@lizponce.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '4', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (32, 'active_plugins', 'a:4:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:24:"wordpress-seo/wp-seo.php";i:3;s:27:"wp-filebase/wp-filebase.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'home', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '/work', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', 'a:2:{i:0;s:98:"/Users/eponce_420/Website/www.lizponce.com/wp-content/plugins/awesome-filterable-portfolio/afp.php";i:1;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'stanleywp', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'stanley-child', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:9:{i:1399172400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1399650980;a:1:{s:9:"wpfb_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1399651994;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1399662060;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1399676400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1399695218;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1399695263;a:1:{s:14:"yoast_tracking";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1399695338;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";s:69:"https://downloads.wordpress.org/release/wordpress-3.9.1-partial-0.zip";s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:3:"3.9";}i:1;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";s:69:"https://downloads.wordpress.org/release/wordpress-3.9.1-partial-0.zip";s:8:"rollback";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-rollback-0.zip";}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:3:"3.9";s:13:"support_email";s:27:"updatehelp391@wordpress.org";}}s:12:"last_checked";i:1399647463;s:15:"version_checked";s:3:"3.9";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1399647464;s:7:"checked";a:2:{s:13:"stanley-child";s:3:"1.0";s:9:"stanleywp";s:5:"3.0.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (113, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (115, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, 'recently_activated', 'a:1:{s:36:"awesome-filterable-portfolio/afp.php";i:1399431301;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (136, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1398639600;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (137, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1399172400;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, 'wpseo_titles', 'a:72:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:0:"";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:0:"";s:15:"title-404-wpseo";s:0:"";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:17:"noauthorship-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:17:"noauthorship-page";b:1;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:23:"noauthorship-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;s:15:"title-portfolio";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:18:"metadesc-portfolio";s:0:"";s:17:"metakey-portfolio";s:0:"";s:17:"noindex-portfolio";b:0;s:22:"noauthorship-portfolio";b:1;s:18:"showdate-portfolio";b:0;s:21:"hideeditbox-portfolio";b:0;s:24:"title-tax-portfolio_cats";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:27:"metadesc-tax-portfolio_cats";s:0:"";s:26:"metakey-tax-portfolio_cats";s:0:"";s:30:"hideeditbox-tax-portfolio_cats";b:0;s:26:"noindex-tax-portfolio_cats";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'wpseo', 'a:18:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:11:"ignore_tour";b:1;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:19:"tracking_popup_done";b:1;s:7:"version";s:7:"1.5.2.8";s:11:"alexaverify";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:15:"pinterestverify";s:0:"";s:12:"yandexverify";s:0:"";s:14:"yoast_tracking";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (142, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398572065;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (143, 'current_theme', 'stanley-child', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'theme_mods_lp-bootstrap', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398615306;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (149, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2797230562', 'no') ; 
INSERT INTO `wp_options` VALUES (150, '_transient_hmbkp_schedule_default-1_database_filesize', '671744', 'no') ; 
INSERT INTO `wp_options` VALUES (154, '_transient_lp_bootstrap_categories', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (177, 'theme_mods_stanleywp', 'a:7:{i:0;b:0;s:15:"homepage_blocks";a:2:{s:7:"enabled";a:2:{s:7:"placebo";s:7:"placebo";s:16:"home_static_page";s:12:"Page Content";}s:8:"disabled";a:2:{s:7:"placebo";s:7:"placebo";s:14:"home_portfolio";s:9:"Portfolio";}}s:7:"backups";N;s:9:"smof_init";s:31:"Sun, 27 Apr 2014 16:15:08 +0000";s:14:"custom_favicon";s:0:"";s:11:"custom_logo";s:0:"";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398893839;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (178, 'theme_mods_stanley-child', 'a:17:{i:0;b:0;s:15:"homepage_blocks";a:2:{s:7:"enabled";a:2:{s:7:"placebo";s:7:"placebo";s:16:"home_static_page";s:12:"Page Content";}s:8:"disabled";a:2:{s:7:"placebo";s:7:"placebo";s:14:"home_portfolio";s:9:"Portfolio";}}s:7:"backups";N;s:9:"smof_init";s:31:"Sun, 27 Apr 2014 16:27:55 +0000";s:14:"custom_favicon";s:0:"";s:11:"custom_logo";s:48:"/wp-content/uploads/2014/05/LizPonce_WebLogo.png";s:20:"home_portfolio_count";s:1:"3";s:14:"read_more_text";s:9:"Read More";s:19:"enable_disable_tags";s:1:"1";s:13:"project_title";s:1:"1";s:24:"portfolio_post_type_name";s:9:"Portfolio";s:24:"portfolio_post_type_slug";s:9:"portfolio";s:15:"tracking_header";s:0:"";s:15:"tracking_footer";s:0:"";s:14:"custom_css_box";s:0:"";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398893804;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}s:18:"nav_menu_locations";a:1:{s:7:"top-bar";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (209, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, 'wpcf7', 'a:1:{s:7:"version";s:3:"3.8";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (275, 'afpOptions', 'a:7:{s:8:"sort_cat";N;s:10:"sort_items";s:2:"id";s:12:"project_link";s:5:"blank";s:10:"anim_speed";s:3:"600";s:11:"anim_easing";s:2:"on";s:7:"startFX";s:6:"normal";s:7:"hoverFX";s:6:"normal";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (279, 'portfolio_cats_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (312, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (351, '_transient_random_seed', 'ab5030b868d00c4634cf348d65b3f737', 'yes') ; 
INSERT INTO `wp_options` VALUES (420, '_site_transient_timeout_browser_a64afbf86ac7a1ef023e4b1e1f62f178', '1400215165', 'yes') ; 
INSERT INTO `wp_options` VALUES (421, '_site_transient_browser_a64afbf86ac7a1ef023e4b1e1f62f178', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.131";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (422, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1399653568', 'no') ; 
INSERT INTO `wp_options` VALUES (423, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=4.0-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23289:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mikemanger">mikemanger</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 09 May 2014 04:39:28 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 08 May 2014 18:40:58 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (424, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1399653568', 'no') ; 
INSERT INTO `wp_options` VALUES (425, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1399610368', 'no') ; 
INSERT INTO `wp_options` VALUES (426, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1399653569', 'no') ; 
INSERT INTO `wp_options` VALUES (427, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: Help Test the BuddyPress Attachments Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22581";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:150:"http://wptavern.com/help-test-the-buddypress-attachments-plugin?utm_source=rss&utm_medium=rss&utm_campaign=help-test-the-buddypress-attachments-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3091:"<p>After shipping BuddyPress 2.0, the plugin&#8217;s core contributors decided to adopt WordPress&#8217; features-as-plugins development model for working on the possibility of a <a href="http://wptavern.com/buddypress-to-adopt-features-as-plugins-model-to-develop-new-media-component" target="_blank">new media component</a>.  Mathieu Viet, better known as <a href="http://buddypress.org/members/imath/" target="_blank">@imath</a>, has been working on an Attachments API that will allow BuddyPress to store media as attachments. Plugin developers will also be able to make use of the new API for handling media and files.</p>
<p>@imath <a href="http://bpdevel.wordpress.com/2014/05/08/attachments-in-buddypress/" target="_blank">reported</a> today that the plugin is now ready for preliminary testing with Group and Member attachments and avatars. With the plugin activated, a new Attachments menu is added to the user profile menu where users can manage (edit/delete) attachments:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/attachments-user-profile.jpeg" rel="prettyphoto[22581]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/attachments-user-profile.jpeg?resize=800%2C775" alt="attachments-user-profile" class="aligncenter size-full wp-image-22592" /></a></p>
<p>Here&#8217;s an example of an example of a group avatar cropped using the &#8220;BP Media Editor&#8221;:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/group-avatars.jpeg" rel="prettyphoto[22581]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/group-avatars.jpeg?resize=800%2C502" alt="group-avatars" class="aligncenter size-full wp-image-22590" /></a></p>
<p>A robust media component is one of the features that BuddyPress site administrators request most often. If you’re hoping for this to become a reality, you can help by testing the plugin while it’s being developed.</p>
<p><a href="https://github.com/buddypress/bp-attachments" target="_blank">BuddyPress Attachments</a> requires BP 2.0+ and WordPress 3.9+. You can download it from the plugin’s homepage on Github, where you’ll also find a <a href="https://github.com/buddypress/bp-attachments/wiki" target="_blank">wiki</a> for installing and using it. @imath is seeking feedback from different types of users. Here’s how you can help:</p>
<ul>
<li>Test it, <a href="https://github.com/buddypress/bp-attachments/issues" target="_blank">report bugs</a>, add recommend enhancements and add your feedback</li>
<li>Plugin authors can test for conflicts, such as duplicate names in functions</li>
<li>Contribute code: Pull requests and patches are welcome</li>
</ul>
<p>If you want to see the progress on the plugin so far, the video below is a live demonstration where you can view the bleeding edge version 1.0 of the plugin in action. Download it from Github and take it for a test drive. You can also follow along and contribute to the development discussion on <a href="https://buddypress.trac.wordpress.org/ticket/5429" target="_blank">Trac</a>.</p>
<p></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 21:34:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: WordPress Contributors Move Toward Automating Accessibility Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22333";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:198:"http://wptavern.com/wordpress-contributors-move-toward-automating-accessibility-testing?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-contributors-move-toward-automating-accessibility-testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7143:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/guided-road.jpg" rel="prettyphoto[22333]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/guided-road.jpg?resize=900%2C421" alt="guided-road" class="aligncenter size-full wp-image-22575" /></a></p>
<p>Accessibility is one of those areas of WordPress contribution that hardly ever ends up in the spotlight. Much of the work that goes on in this area is invisible to the vast majority of users. Accessibility experts are generally in shorter supply than other types of contributors as well. Why aren’t more people involved in this important aspect of the web?</p>
<p><a href="http://davidakennedy.com/" target="_blank">David Kennedy</a> has been an active member of the WordPress Accessibility team for more than a year, and he believes that accessibility can be an artful science. His involvement began shortly after he started working on <a href="http://wordpress.org/themes/accessible-zen" target="_blank">Accessible Zen</a>, a free accessible WordPress theme. This led him to attend the weekly IRC meetings and contribute by testing patches.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/davidkennedy.jpg" rel="prettyphoto[22333]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/davidkennedy.jpg?resize=150%2C150" alt="davidkennedy" class="alignright size-thumbnail wp-image-22576" /></a>Kennedy first started learning about the basics of web accessibility while working for <a href="http://wptavern.com/feed">The Arc</a>, a national nonprofit that helps people with intellectual and developmental disabilities. The more he dug into it, the more he enjoyed it. Now it’s part of his daily life as a frontend developer and contributor to WordPress.</p>
<h3>Digging Deeper to Find the Beauty of Web Accessibility</h3>
<p>I asked Kennedy to give us a window into why so few people are drawn to get involved with accessibility.</p>
<p>“The answers to web accessibility challenges and problems aren&#8217;t always clear,” he said. &#8220;So much of the right approach often depends on the context of the website or web application in question.&#8221;</p>
<p>Harnessing the right solution will often require delving deeper into the specifics of the content you’re trying to communicate. Kennedy cites a specific example:</p>
<blockquote><p>The alt attribute you write for an image on Site A can be vastly different than the alt attribute for the same image on Site B. Why? Each site&#8217;s content is vastly different. This stumps a lot of talented web workers. </p></blockquote>
<p>Accessibility improvements are often implemented under the surface of the application and Kennedy says that the goal is to keep them invisible.</p>
<blockquote><p>When web accessibility is done right, it&#8217;s undetectable. So it&#8217;s not something designers, developers or users can see to make a note of for future inspiration. You have to dig deeper to find the beauty in web accessibility. But trust me, it&#8217;s there.</p></blockquote>
<p>Kennedy and other WordPress accessibility contributors are working together to improve the application along these lines with an initial focus on modernizing their testing tools.</p>
<h3>WordPress Contributors Are Collaborating With the Drupal Accessibility Team To Automate Testing</h3>
<p>The WordPress Accessibility team is <a href="http://make.wordpress.org/accessibility/2014/05/02/automated-accessibility-testing/" target="_blank">moving toward automating testing</a> in order to improve its efficiency. Kennedy hopes that automated testing will bring accessibility improvements to a new level, as well as help to educate other types of contributors, i.e. designers and developers:</p>
<blockquote><p>Its biggest benefits include helping us find simple errors, like missing form labels or missing alt attributes, and alerting us to potentially large trouble spots within code that may need more manual testing. Automated accessibility testing also shows many developers that accessibility is as much a code quality issue as it is a design and user interface challenge.</p></blockquote>
<p>Pursuant to that goal, Kennedy contacted <a href="http://jessebeach.github.io/" target="_blank">Jesse Beach</a> from the Drupal project. She is a contributor to <a href="http://quailjs.org/" target="_blank">QuailJS</a>, a jQuery plugin for checking content against accessibility guidelines. The Drupal Accessibility team already <a href="http://opensource.com/business/14/5/new-release-drupal-8-accessibility-advantage" target="_blank">has this in the bag</a> and the application is well-known for its attention to web accessibility guidelines. Their input has been invaluable to WordPress contributors, who may opt for incorporating QuailJS or a similar tool as part of their testing suite, depending on what fits.</p>
<p>Some of WordPress’ accessibility team members have joined in the Drupal Accessibility Group’s Skype chat and a few Drupal members have jumped in on the WordPress IRC chats. They’re brainstorming new ways to keep the conversation going for improving both projects.</p>
<p>What exactly do WordPress and Drupal have to gain by collaborating on accessibility? Kennedy has a few thoughts:</p>
<blockquote><p>At a broad level? More accessible, open software meaning that more people can create content on the web. Deeper than that? More efficient processes around managing accessibility in large, open software projects.</p>
<p>Potentially, a unified way to approach new accessibility web standards, meaning if both Drupal and WordPress adopt a standard quickly, it might help push browser makers to move sooner.</p></blockquote>
<p>Modernizing the testing tools that WordPress accessibility contributors have at their disposal is the first step towards getting on the same page.</p>
<h3>Making WordPress Accessibility More Approachable for New Contributors</h3>
<p>The accessibility team remains rather small, with just a handful of regular contributors. But you don’t have to be an established accessibility wizard to join the team. Kennedy offers a new way to look at the field.</p>
<p>&#8220;Web accessibility crosses all disciplines and touches every aspect of the web. But many people don&#8217;t realize they already have what it takes to make a project accessible. We have to embrace that.</p>
<p>&#8220;Good web accessibility comes down to making informed decisions, making sure the people involved have an awareness of accessibility and paying attention to the smallest of details throughout,” he said.</p>
<p>&#8220;Notice I didn&#8217;t mention anything about design, specific accessibility standards or coding. It usually starts with asking the question, &#8216;How&#8217;s this really going to work?&#8217; Anyone can help us do that.&#8221;</p>
<p>If you’re interested in learning more, join the WordPress accessibility team at <a href="http://make.wordpress.org/accessibility/" target="_blank">make.wordpress.org/accessibility</a>. You’ll find a group of contributors who are passionate about making the web a better place.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 20:54:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:89:"WordPress.tv: John James Jacoby: WordPress’s Role Based Access Control – WPRBACOMGBBQ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34534";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wordpress.tv/2014/05/08/john-james-jacoby-wordpresss-role-based-access-control-wprbacomgbbq/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:730:"<div id="v-wU6eIUq9-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34534/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34534/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34534&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/08/john-james-jacoby-wordpresss-role-based-access-control-wprbacomgbbq/"><img alt="John James Jacoby: WordPress’s Role Based Access Control &#8211; WPRBACOMGBBQ" src="http://videos.videopress.com/wU6eIUq9/video-ceb1da387f_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:42:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Dev Blog: WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3072:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WordPress.tv: Josh Broton: You Don’t Need jQuery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34532";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.tv/2014/05/08/josh-broton-you-dont-need-jquery/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:652:"<div id="v-FUCgovHK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34532/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34532/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34532&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/08/josh-broton-you-dont-need-jquery/"><img alt="Josh Broton: You Don’t Need jQuery" src="http://videos.videopress.com/FUCgovHK/video-3818ea47dc_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:38:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:110:"WordPress.tv: Reid Peifer: So Long Fixed Templates And Thanks For All The Fish: Modular Content With WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34530";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:126:"http://wordpress.tv/2014/05/08/reid-peifer-so-long-fixed-templates-and-thanks-for-all-the-fish-modular-content-with-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:768:"<div id="v-kouQpxTd-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34530/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34530/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34530&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/08/reid-peifer-so-long-fixed-templates-and-thanks-for-all-the-fish-modular-content-with-wordpress/"><img alt="Reid Peifer: So Long Fixed Templates And Thanks For All The Fish: Modular Content With WordPress" src="http://videos.videopress.com/kouQpxTd/video-7d1ed9106c_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:22:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WordPress.tv: Interview de Mathieu Viet, orateur de “Prototypez vos applications avec WordPress”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34554";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:111:"http://wordpress.tv/2014/05/07/interview-de-mathieu-viet-orateur-de-prototypez-vos-applications-avec-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:700:"<div id="v-ajHHYA3X-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34554/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34554/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34554&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/07/interview-de-mathieu-viet-orateur-de-prototypez-vos-applications-avec-wordpress/"><img alt="14 &#8211; Mathieu Viet-Itw-WCParis2014.mp4" src="http://videos.videopress.com/ajHHYA3X/video-d5d12de588_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 23:51:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: Keep Track Of WordCamp Miami Through WPArmchair";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22544";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/keep-track-of-wordcamp-miami-through-wparmchair?utm_source=rss&utm_medium=rss&utm_campaign=keep-track-of-wordcamp-miami-through-wparmchair";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1855:"<p><a title="http://2014.miami.wordcamp.org/" href="http://2014.miami.wordcamp.org/">WordCamp Miami 2014</a>, is shaping up to be one of the best WordPress events of the year. With <a title="http://2014.miami.wordcamp.org/tickets/" href="http://2014.miami.wordcamp.org/tickets/">700 tickets sold</a> and 100 people on the waiting list, the opportunity to attend the event has disappeared for all but the luckiest individuals. If you can&#8217;t make it to the event, keep an eye on <a title="http://wcmia.wparmchair.com/" href="http://wcmia.wparmchair.com/">WPArmchair.com</a>.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WPArmChairWCMiamiSite.png" rel="prettyphoto[22544]"><img class="aligncenter size-full wp-image-22545" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WPArmChairWCMiamiSite.png?resize=818%2C188" alt="Official Armchair Site Of WordCamp Miami" /></a><a title="http://wptavern.com/monitor-wordcamps-online-with-wp-armchair" href="http://wptavern.com/monitor-wordcamps-online-with-wp-armchair">Created by</a> WordCamp Miami organizer David Bisset, WPArmchair is a way to keep track of WordCamp events via their assigned hashtag. For example, the hashtag for WordCamp Miami will be <strong>#wcmia</strong>. Any photo, tweet, or Vine hosted video published to Twitter using the hashtag will show up on the site. Visitors can click the heart icon to mark posts as favorites.</p>
<h3>WPTavern Will Be In Full Force At The Event</h3>
<p>Sarah Gooding and I will be in attendance at WordCamp Miami. We plan to take photos, record interviews, and give you updates via the <a title="https://twitter.com/wptavern" href="https://twitter.com/wptavern">WPTavern Twitter</a> account all weekend long. If you happen to see us, stop and say hi. We love talking to readers face to face and hearing feedback.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 23:07:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Highlights Of The WPBacon WordPress Webhosting Roundtable";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22443";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/highlights-of-the-wpbacon-wordpress-webhosting-roundtable?utm_source=rss&utm_medium=rss&utm_campaign=highlights-of-the-wpbacon-wordpress-webhosting-roundtable";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5566:"<p>Earlier today, WPBacon hosted a <a title="http://wpbacon.com/podcast/wordpress-hosting-panel/" href="http://wpbacon.com/podcast/wordpress-hosting-panel/">WordPress hosting</a> roundtable featuring high-profile employees of notable webhosting companies. The panel consisted of the following people.</p>
<ul>
<li>Ben Welch-Bolen CEO of <a title="http://www.site5.com/" href="http://www.site5.com/">Site 5</a></li>
<li>Tenko Nikolov CEO of <a title="http://siteground.com/" href="http://siteground.com/">Siteground</a></li>
<li>Vanessa Vasile Tier 3 Systems Architecture Lead of <a title="http://www.inmotionhosting.com/" href="http://www.inmotionhosting.com/">InMotion Hosting</a></li>
<li>James Grierson VP Business Development of <a title="http://www.bluehost.com/" href="http://www.bluehost.com/">Bluehost</a></li>
<li>Ryan Sullivan Founder of <a title="http://www.wpsitecare.com" href="http://www.wpsitecare.com">WP Site Care</a></li>
</ul>
<p><strong>While the entire show was filled with great information, these are the statements that really caught my attention:</strong></p>
<p><strong>75% of customer sites</strong> on Site 5 are powered by WordPress. This is the reason for setting up an optimized server configuration specifically for WordPress.</p>
<p><strong>50% of users</strong> on Bluehost have WordPress installed on their account.</p>
<h3>What&#8217;s The Biggest Security Threat Affecting Hosts?</h3>
<p>Brute force login attempts were labeled as one of the biggest threats to webhosting. Hosts are getting increasingly aggressive in protecting users and forcing customers to use strong passwords. The majority of those on the panel stated they are blocking thousands of requests per second of automated attacks. 80-90% of the attacks are determined to be automated.</p>
<p>Welch of Site 5 explained how the core of WordPress has been solid for the past two years. The focus has now shifted towards themes and plugins for security and performance issues.</p>
<h3>How Do They Contribute Back To WordPress?</h3>
<p>Siteground has a contractor who works for them but also contributes to the core of WordPress. Siteground is pro-active in fixing bugs and sends those patches upstream for the benefit of everyone who uses WordPress.</p>
<p>Out of all the companies represented on the panel, Bluehost is the only one that works exclusively with Automattic and the WordPress project. They also have two employees who work full time contributing to WordPress.</p>
<p>Site 5 attends and sponsors as many WordCamps as they can. Site 5 helps users get a grasp of WordPress and solving customer problems is their way of contributing to the larger WordPress ecosystem.</p>
<h3>What&#8217;s The Biggest Challenges Facing WordPress Specific Hosting Companies?</h3>
<p>So many hosting companies advertise their support of WordPress, that Vasile of InMotion hosting says you need to specify that you can run WordPress on your servers or else customers don&#8217;t think it&#8217;s possible.</p>
<p>One of the largest challenges in WordPress hosting is struggling to host customers who fail to keep WordPress and their site up to date and secure. Auto updates for security and bug fixes have been a big help in keeping sites secure.</p>
<h3>What Is The Most Common Support Issue?</h3>
<p>InMotion hosting sees a bit of everything. Sometimes the security measures put in place to protect users such as mod_security can cause problems.</p>
<p>Site 5 has a lot of support requests that are high level due to their customer base. A lot of customers are the developer/designer type. They don&#8217;t have many customers who ask basic questions.</p>
<p>Bluehost sees a lot of support requests due to plugins and themes if they negatively affect the performance of their customer&#8217;s sites.</p>
<h3>Questions I Would Have Asked</h3>
<p>Although I submitted a few questions to the panel, none were asked. In the hopes that these individuals will stop by and answer them in the comments, here are the questions I submitted to the show.</p>
<p><strong>To the panel</strong>: Have you made any strategic deals with WordPress product and service companies in order to offer your customers more than just a hosting account?</p>
<p><strong>To Bluehost</strong>: How beneficial has it been for the company to be <a title="http://wordpress.org/hosting/" href="http://wordpress.org/hosting/">one of the recommended webhosts</a> on WordPress.org? A follow up question would ask them to explain how they ended up in that position.</p>
<p><strong>To the panel</strong>: How are they differentiating themselves from each other considering almost every webhost has the capability to host a WordPress site?</p>
<h3>Watch The Entire Interview and Tell Us What You Think</h3>
<p>The hosts of WPBacon, Robert Neu and Ozzy Rodriguez announced they will be hosting a WordPress Managed Hosting roundtable in the near future. Since the market has a lot of choices between shared and managed WordPress hosting, the duo decided to host two seperate roundtables.</p>
<p>If you need help choosing the right webhost, <a title="http://wptavern.com/14-things-to-consider-when-choosing-a-webhost-for-your-wordpress-powered-site" href="http://wptavern.com/14-things-to-consider-when-choosing-a-webhost-for-your-wordpress-powered-site">consider these 14 things</a> before you make your decision.</p>
<p>Watch the interview and let us know what you think in the comments. A word of caution, some parts of the episode contain language of an adult nature.</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 23:04:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Create A Custom WordPress Admin Experience With Adminimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22504";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/create-a-custom-wordpress-admin-experience-with-adminimize?utm_source=rss&utm_medium=rss&utm_campaign=create-a-custom-wordpress-admin-experience-with-adminimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4551:"<p>Over the years, WordPress has added features, menus, and options throughout the backend. I&#8217;m constantly reminded of the <a title="http://en.wikipedia.org/wiki/Pareto_principle" href="http://en.wikipedia.org/wiki/Pareto_principle">80/20 rule of software development</a> where 20% of the software is not used. I&#8217;ve noticed I rarely visit some of the links and menus in the backend of WordPress but there is no easy way to remove them from view.</p>
<p><a title="http://wordpress.org/plugins/adminimize/" href="http://wordpress.org/plugins/adminimize/">Adminimize</a> by <a title="http://profiles.wordpress.org/bueltge/" href="http://profiles.wordpress.org/bueltge/">Frank Bültge</a> and <a title="http://inpsyde.com/en/" href="http://inpsyde.com/en/">Inpsyde GmbH </a>makes it easy to remove items from view based on a user&#8217;s role.</p>
<div id="attachment_22537" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/AdminimizeRoles.png" rel="prettyphoto[22504]"><img class="size-full wp-image-22537" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/AdminimizeRoles.png?resize=1025%2C269" alt="User Roles Support In Adminimize" /></a><p class="wp-caption-text">User Roles Support In Adminimize</p></div>
<p>The first thing you&#8217;ll notice on the settings page is the large number of check boxes. The check boxes correspond to the default and custom user roles on the site. On this page, you can control which users see which parts of the WordPress backend. The options are split up into sections and are easily accessible from the top mini menu.</p>
<p>After toying around with the settings, I was able to remove items from view I don&#8217;t use very often. The result was a simpler user interface that contained fewer things to look at. If you&#8217;re curious, here is what I removed.</p>
<ul>
<li>Contextual help</li>
<li>The about menu</li>
<li>The add new menu within the admin bar</li>
<li>The username and search box on the right hand side of the admin bar</li>
</ul>
<p>Where this plugin really shines is the options it provides to hide things from users based on their user role. While WordPress naturally hides things from view <a title="http://codex.wordpress.org/Roles_and_Capabilities" href="http://codex.wordpress.org/Roles_and_Capabilities">based on a user&#8217;s role</a>, this plugin can override the capabilities assigned to the role, providing more fine grain control. It&#8217;s not just tied to WordPress either, bbPress and WordPress multisite are supported as well.</p>
<div id="attachment_22538" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/AdminimizeImportExport.png" rel="prettyphoto[22504]"><img class="size-full wp-image-22538" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/AdminimizeImportExport.png?resize=468%2C361" alt="Import Export Of Options" /></a><p class="wp-caption-text">Import Export Of Options</p></div>
<p>Depending on the level of control you&#8217;re exerting, configuring the display options can be an exhaustive chore. Thankfully, Adminimize contains an import/export system so you don&#8217;t have to start over from scratch. The files are saved using the <a title="http://filext.com/file-extension/SEQ" href="http://filext.com/file-extension/SEQ">.SEQ file extension</a>. This makes it easy to transport settings from one WordPress site to another.</p>
<p>If you decide to deactivate and uninstall the plugin, the database entries will not be removed. In order to completely remove the plugin from your site, you&#8217;ll need to check the <strong>Delete Options</strong> box.</p>
<h3>Perfect For Consultants Handing Off Sites To Clients</h3>
<p>One of the core philosophies of WordPress development is decisions, not options. In a similar fashion, Adminimize enables consultants to decide whether or not clients should have access to specific parts of the WordPress backend. Crippling the backend is not a good way for clients to learn WordPress but at the same time, I understand how limiting access could help prevent clients from breaking their sites.</p>
<h3>The Adminimize Experiment</h3>
<p>As a fun experiment, I encourage everyone to try out Adminimize and remove the sections of the dashboard you don&#8217;t often use. Then, take a screenshot of the user interface and submit the link in the comments. I&#8217;m curious to see which parts of the backend are the most common to be hidden and how the overall interface looks.</p>
<p>&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 22:51:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WordPress.tv: Michelle Schulp: Design Is In The Details: How Decisions Shape Communication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34528";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:106:"http://wordpress.tv/2014/05/07/michelle-schulp-design-is-in-the-details-how-decisions-shape-communication/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:734:"<div id="v-WRb8Ki7T-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34528/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34528/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34528&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/07/michelle-schulp-design-is-in-the-details-how-decisions-shape-communication/"><img alt="Michelle Schulp: Design Is In The Details: How Decisions Shape Communication" src="http://videos.videopress.com/WRb8Ki7T/video-693b3399d5_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 18:40:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Travis Totz: Designing For Interaction";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34526";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/05/07/travis-totz-designing-for-interaction/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:653:"<div id="v-QZEe8OE7-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34526/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34526/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34526&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/07/travis-totz-designing-for-interaction/"><img alt="Travis Totz: Designing For Interaction" src="http://videos.videopress.com/QZEe8OE7/video-7d96b4ae35_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 18:25:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress.tv: Michal Kopecký: Blog na steroidoch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34592";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.tv/2014/05/07/michal-kopecky-blog-na-steroidoch/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:646:"<div id="v-BppvtDpf-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34592/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34592/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34592&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/07/michal-kopecky-blog-na-steroidoch/"><img alt="Michal Kopecký: Blog na steroidoch" src="http://videos.videopress.com/BppvtDpf/video-afec1d93ca_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 18:24:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Official WordPress Plugin for the Add to Homescreen Javascript Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22511";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:202:"http://wptavern.com/official-wordpress-plugin-for-the-add-to-homescreen-javascript-plugin?utm_source=rss&utm_medium=rss&utm_campaign=official-wordpress-plugin-for-the-add-to-homescreen-javascript-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3997:"<div id="attachment_22530" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/mobile-homescreen.jpg" rel="prettyphoto[22511]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/mobile-homescreen.jpg?resize=1024%2C473" alt="photo credit: yum9me - cc" class="size-full wp-image-22530" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/yum9me/4955656853/">yum9me</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p><a href="http://addtohome.cubiq.org/" target="_blank">Add to Homescreen</a> is an open source project, developed by <a href="http://cubiq.org/" target="_blank">Matteo Spinelli</a>, that allows website owners to include the add to home screen call-out for mobile devices. The Javascript plugin is self-contained, dependency-free, and often recommended. Spinelli has just released an <a href="http://wordpress.org/plugins/official-add-to-homescreen/" target="_blank">official WordPress plugin</a> that will guide users through the complicated task of configuring the script.</p>
<p>Once the plugin is installed and configured, it will open an always-on-top message inviting mobile users to add the application to the home screen, a feature currently only available on iOS and Mobile Chrome browsers. Spinelli explains that &#8220;While other devices have the ability to bookmark any website to the home screen, only iOS and Mobile Chrome have a straightforward way to do it.&#8221;</p>
<p>The Add to Homescreen plugin includes both basic and advanced configuration options, debugging, and statistics for how often your site is added to users&#8217; homescreens:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-to-homescreen-settings.png" rel="prettyphoto[22511]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-to-homescreen-settings.png?resize=927%2C841" alt="add-to-homescreen-settings" class="aligncenter size-full wp-image-22514" /></a></p>
<p>The plugin&#8217;s basic configuration page includes four presets for you to choose from:</p>
<ul>
<li><strong>Anonymous</strong> &#8211; Displays the message but never tracks the users</li>
<li><strong>Display Once</strong> &#8211; Displays the callout only once and tracks when added</li>
<li><strong>Always Show</strong> &#8211; Displays the callout once every 24 hours until the user has added the website to the homescreen</li>
<li><strong>Silent</strong> &#8211; Never show the callout but track when users add the application to the homescreen</li>
</ul>
<p>The built-in stats feature allows you to keep track of the number of views vs. added to the homescreen:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-to-homescreen-stats.png" rel="prettyphoto[22511]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-to-homescreen-stats.png?resize=926%2C497" alt="add-to-homescreen-stats" class="aligncenter size-full wp-image-22515" /></a></p>
<p>Stats are a nice option, but if you have conflicts with other plugins, it might serve you better to disable it. Spinelli advises that the Anonymous option is the only 100% fail-safe solution if you are having trouble.</p>
<p>The plugin also includes the ability to upload a custom application icon, so you can brand it to your website accordingly. Spinelli plans to continue developing the plugin and is currently working on adding Windows Phone support to a future release.</p>
<p>The <a href="http://wordpress.org/plugins/official-add-to-homescreen/" target="_blank">Official Add to Homescreen</a> plugin is considered official because it is developed by the same author of the popular <a href="http://addtohome.cubiq.org/" target="_blank">Javascript widget</a>. If you are already using this script or another plugin that uses it, your best option is to switch to the official plugin in order to stay up to date and receive the latest bug fixes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 07 May 2014 17:29:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: 5 Free Plugins for Hosting a Giveaway on Your WordPress Site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22338";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/5-free-plugins-for-hosting-a-giveaway-on-your-wordpress-site?utm_source=rss&utm_medium=rss&utm_campaign=5-free-plugins-for-hosting-a-giveaway-on-your-wordpress-site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7525:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/giveaway.jpg" rel="prettyphoto[22338]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/giveaway.jpg?resize=1019%2C477" alt="giveaway" class="aligncenter size-full wp-image-22494" /></a></p>
<p>Hosting a giveaway is a popular way to introduce a new product or service on your website. When properly promoted, a giveaway can bring you an influx of new readers, traffic and can boost participation on your existing content. Other than using a 3rd party randomizer of some kind, there&#8217;s no easy way to do it in WordPress without a plugin. Not all giveaways are structured the same, so we&#8217;ve selected five unique plugins that make it easy to set up a giveaway on your WordPress site.</p>
<h3>WP Giveaways</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-giveaways.png" rel="prettyphoto[22338]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-giveaways.png?resize=1025%2C471" alt="wp-giveaways" class="aligncenter size-full wp-image-22476" /></a></p>
<p><a href="http://wordpress.org/plugins/wp-giveaways/" target="_blank">WP Giveaways</a> is one of the most comprehensive plugins for selecting a winner from your WordPress users. It makes it possible for you to select a random winner(s) from a pool of subscribers or any role you select. The plugin allows you to host multiple giveaways and each will have a unique shortcode that will display the date of the next scheduled draw. WP Giveaways features the following:</p>
<ul>
<li>Set up a custom email template used to email the prize</li>
<li>Attach files or simply email out the links to the prize(s)</li>
<li>Each giveaway can be set as a recurring giveaway or a onetime deal</li>
<li>Limit the contestant pool to the subscribers that registered since the giveaway was initially published</li>
<li>View the history for each of the giveaways in terms of draw dates and the associated winners</li>
<li>Choose how many winners to announce for each giveaway</li>
</ul>
<p>The handy thing about WP Giveaways is that it is totally automated. Once you schedule your giveaway, there is nothing else you have to do. The plugin utilizes WP Cron to schedule the draw and will automatically email the winner using the alert template that you create.</p>
<h3>Give It Away Now</h3>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/give-it-away-now.png" rel="prettyphoto[22338]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/give-it-away-now.png?resize=627%2C331" alt="give-it-away-now" class="aligncenter size-full wp-image-22478" /></a></p>
<p><a href="http://wordpress.org/plugins/give-it-away-now/" target="_blank">Give It Away Now</a> is a relatively new plugin that is specifically for creating daily giveaways. Users can only enter once per day and the results are available in the admin settings page. Giveaways are created as a new content type with a featured image and the following fields: Why, About, Rules, Number of Prizes and End Date. This is how the new content type appears on the frontend:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/screenshot-1.png" rel="prettyphoto[22338]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/screenshot-1.png?resize=776%2C680" alt="screenshot-1" class="aligncenter size-full wp-image-22481" /></a></p>
<p>The post will automatically indicate when the giveaway has closed and all published giveaways will appear in their own archive. The Give It Away Now plugin is useful if you are hosting giveaways that last only 24 hours.</p>
<h3>Meetup Winner</h3>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/winner.jpg" rel="prettyphoto[22338]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/winner.jpg?resize=720%2C553" alt="winner" class="aligncenter size-full wp-image-22485" /></a></p>
<p><a href="http://wordpress.org/plugins/meetup-winner/" target="_blank">Meetup Winner</a> is a plugin that allows you to host a giveaway at your local meetup. It integrates with the Meetup.com API to select a random member of your Meetup who RSVPed to your event. You can then give away swag or prizes at the event.</p>
<p>The Meetup Winner plugin is very easy to use. Simply add your API key in the settings, add your shortcode with the event&#8217;s ID to a page, and the winner will be shown on the frontend of the page.</p>
<h3>Pick Giveaway Winner</h3>
<p>If you want to select a winner based on comments on a post, the <a href="http://wordpress.org/plugins/pick-giveaway-winner/" target="_blank">Pick Giveaway Winner</a> plugin will do the trick. Its configuration page is found under the Tools menu.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/pick-winner.jpg" rel="prettyphoto[22338]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/pick-winner.jpg?resize=794%2C348" alt="pick-winner" class="aligncenter size-full wp-image-22487" /></a></p>
<p>The plugin uses  MySQL&#8217;s random function RAND() to randomly select the winners directly from the database. When selecting a winner, you have the option to disqualify entrants who have submitted multiple entries, allow multiple entries, or disqualify multiple entries and allow only one to count. Pick Giveaway Winner hasn&#8217;t been updated in awhile, but I tested it with WordPress 3.9 and had no issues.</p>
<h3>Golden Ticket</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/golden-ticket.png" rel="prettyphoto[22338]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/golden-ticket.png?resize=772%2C250" alt="golden-ticket" class="aligncenter size-full wp-image-22489" /></a></p>
<p>The idea behind the <a href="http://wordpress.org/plugins/golden-ticket/" target="_blank">Golden Ticket</a> plugin is to incentive interaction on your WordPress site. Essentially, the golden ticket is like a prize the user has to hunt for in order to win the reward. You can create multiple golden tickets and hide them throughout your content using a simple [ goldenticket ] shortcode. The golden ticket will pop into view after triggered by an action, which you can define in the settings.</p>
<p><span class="embed-youtube"></span></p>
<p>There are three available triggers for revealing the ticket:</p>
<ul>
<li><strong>After a set amount of time:</strong> If you want to reward only the most loyal of readers, set the delay to something like 30 seconds. If they are still reading your content after 30 seconds, odds are they will read the ticket when it appears.</li>
<li><strong>When the mouse is over the ticket:</strong> The ticket will remain invisible until the user hovers over it with the mouse. This is for those readers who scan through the content with their mouse cursor.</li>
<li><strong>When the ticket is scrolled into view:</strong> The ticket will remain hidden on the page until the position of the ticket is scrolled into view. This means if you hide the ticket near the end of the content, it will never show until the user scrolls to that point.</li>
</ul>
<p>The Golden Ticket plugin offers a nice way to identify readers who interact with your content and reward them accordingly. It&#8217;s not your traditional giveaway plugin, but it&#8217;s likley more accurate at rewarding those who are truly interested in your content, instead of randomly selecting from visitors who are only interested in the prize.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 22:25:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: New wptheory Service Launches WordPress Websites in a Day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22402";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/new-wptheory-service-launches-wordpress-websites-in-a-day?utm_source=rss&utm_medium=rss&utm_campaign=new-wptheory-service-launches-wordpress-websites-in-a-day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5606:"<p>Adam Clark, founder of <a href="http://bottlerocketcreative.com/" target="_blank">Bottlerocket Creative</a>, just launched a new WordPress service that churns out a website in one day.</p>
<p>That&#8217;s right, a complete website in a single day, for $999.</p>
<p>This new project is called <a href="http://wptheory.net/" target="_blank">wptheory</a> and the service claims to be be able to customize and launch a WordPress theme in a scheduled workday beginning with an 8 a.m. discussion and culminating in a 6 p.m. launch party. The service includes brand matching, content migration and setup (up to 10 pages worth) and plugin installation to make a client&#8217;s site look and feel just like the demo of the theme they have chosen. Hosting setup is also included in the flat rate.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wptheory.jpg" rel="prettyphoto[22402]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wptheory.jpg?resize=800%2C489" alt="wptheory" class="aligncenter size-full wp-image-22453" /></a></p>
<p>Clark, who has long been providing custom WordPress development services for clients, is aiming to get website creation down to a science with his new venture. He&#8217;s hoping that packaging the services as products will be a successful business model.</p>
<p><strong>&#8220;I&#8217;ve always wanted to productize my development services, but could never figure out a good way to do it,&#8221;</strong> he said. &#8220;The idea came from a friend of mine, <a href="http://andrewramos.com" target="_blank">Andrew Ramos</a>, who has a productized design service called <a href="http://appediem.com/" target="_blank">Appe Diem</a>, where he designs your iPhone app in a day.&#8221; Clark brainstormed with him about a developer equivalent to that kind of service and landed upon the WordPress theme customization idea.</p>
<p>&#8220;I felt like I could provide a lot of value to customers by offering a service that customized their theme, uploaded all their content and launched the site in a single day.&#8221;</p>
<p>Clark is launching wptheory alone but is open to adding a team if there is a demand for the service. He believes that this specific theme customization service is the first of its kind but isn&#8217;t sure whether it will take off. &#8220;Theme customization is a service that a lot of companies offer, but I haven’t seen anything exclusively devoted to this one service,&#8221; Clark said. &#8220;And definitely no one doing it in a single day.&#8221;</p>
<h3>Selling Peace of Mind and Convenience</h3>
<p>There&#8217;s no shortage of developers capable of customizing WordPress themes, but Clark is hoping that his new service will offer customers a tidy, branded package of WordPress convenience.</p>
<blockquote><p>wptheory provides more than just theme customization. It’s an end-to-end website launching service that includes theme customization, content setup and hosting setup. It’s designed to take your mind off your website and let you focus on running your business. A customer shows up at 8 a.m. with their theme and they have a fully-functioning, customized website that is live on the internet by the end of the day. I don’t know anyone who is doing that. My hope is that customers will find a lot of value in the tailored service we offer.</p></blockquote>
<p>Clark&#8217;s target market is people who don&#8217;t have a budget for a full custom design and development package and customers who are looking to get a site up fast.</p>
<p>&#8220;Maybe you have an idea for a product or service and you want a way to quickly validate the idea, but don’t want to spend a ton of cash or invest a lot of time in getting a site up,&#8221; he ventured in an example scenario. &#8220;There are a lot companies you could go to, but none that I think would provide wptheory’s level of quality and peace of mind.&#8221;</p>
<p>wptheory is aimed squarely at those who would be anxious at the prospect of creating their own websites. Clark summarizes his intentions with the new service:</p>
<blockquote><p>Mostly, I want to provide a lot of peace of mind. Launching a website is a complicated task for non-web-geeks. There are a lot of best practices to be aware of and I want to take all of that off your plate (even your hosting setup) and provide you with a beautiful, usable website before dinnertime.</p></blockquote>
<p>It is important to note that wptheory&#8217;s basic package does not include custom development or structural changes to the chosen WordPress theme or plugins, although Clark does offer those services for an additional fee.  The advantage for the developer in this kind of arrangement is that it clearly defines and limits the scope of the project. It also keeps the client interaction happening within one day and not spread out over many days&#8217; worth of emails.</p>
<p>One challenge Clark may face is that this service depends heavily on the client already having all the content ready to launch a website in a day. Even the most well-prepared clients are often clueless as to what this will entail, especially those that fall within his targeted &#8220;non-web-geek&#8221; demographic.</p>
<p>For someone with a thriving WordPress development business, the venture isn&#8217;t all that much of a risk, given that it might as well be a natural extension of the services he already offers. But is there a market for websites launched in a day, just before dinnertime? Does <a href="http://wptheory.net/" target="_blank">wptheory</a> have a viable business model?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 18:47:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WordPress.tv: Miro Veselý: Ako si zjednodušiť tvorbu webov a ako ich zmeniť na zisk?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34574";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2014/05/06/miro-vesely-ako-si-zjednodusit-tvorbu-webov-a-ako-ich-zmenit-na-zisk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:726:"<div id="v-yenxWqgv-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34574/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34574/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34574&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/06/miro-vesely-ako-si-zjednodusit-tvorbu-webov-a-ako-ich-zmenit-na-zisk/"><img alt="Miro Veselý: Ako si zjednodušiť tvorbu webov a ako ich zmeniť na zisk?" src="http://videos.videopress.com/yenxWqgv/video-ebf504f5f3_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 09:18:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WordPress.tv: Mathieu Viet : Prototypez vos applications avec WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34552";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wordpress.tv/2014/05/06/mathieu-viet-prototypez-vos-applications-avec-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-0qYuEY4u-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34552/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34552/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34552&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/06/mathieu-viet-prototypez-vos-applications-avec-wordpress/"><img alt="14 &#8211; Mathieu Viet-Conf-WCParis2014.mp4" src="http://videos.videopress.com/0qYuEY4u/video-f440394b45_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 08:49:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Panel Discussion On Commercial WordPress Products and Services";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22427";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:188:"http://wptavern.com/panel-discussion-on-commercial-wordpress-products-and-services?utm_source=rss&utm_medium=rss&utm_campaign=panel-discussion-on-commercial-wordpress-products-and-services";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1954:"<p>One of the highlights of <a title="http://2014.minneapolis.wordcamp.org/" href="http://2014.minneapolis.wordcamp.org/">WordCamp Minneapolis 2014</a>, was the <a title="http://2014.minneapolis.wordcamp.org/sessions/" href="http://2014.minneapolis.wordcamp.org/sessions/">panel discussion</a> on commercial WordPress products. The panel was filled with successful business minds sharing their knowledge of running commercial WordPress products and services.</p>
<p>Each of the panelists shared their story on how they started their business. One thing they all have in common is they concentrated on one specific problem and hammered away at it until they had the best solution.</p>
<ul>
<li>Moderated by Kiko Doran of <a title="http://ingroupconsulting.com/" href="http://ingroupconsulting.com/">InGroup Consulting</a></li>
<li>Marc Benzakein of <a title="http://serverpress.com/products/desktopserver/" href="http://serverpress.com/products/desktopserver/">DesktopServer</a></li>
<li>Carl Hancock of <a title="http://www.rocketgenius.com/" href="http://www.rocketgenius.com/">RocketGenius</a></li>
<li>Ben Fox of <a title="http://www.wpuniversity.com/" href="http://www.wpuniversity.com/">WP University/Sidekick</a></li>
<li>Tony Perez of <a title="https://sucuri.net/" href="https://sucuri.net/">Sucuri</a></li>
<li>Reid Peifer of <a title="https://tri.be/" href="https://tri.be/">ModernTribe</a></li>
</ul>
<p>One of my favorite parts of the discussion was near the end when each individual shared the reality of owning and running a business. It&#8217;s not as simple as creating a product and then making money hand over fist. Managing benefits, taxes, out of state employees versus contractors, support, and accounting are all aspects of a business that need to be taken care of in addition to the product or service.</p>
<p>Watch the session and let us know in the comments if you learned anything you can apply to your own business.</p>
<p></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 04:32:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Short Interview With John James Jacoby On The Progress Of bbPress 2.6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22416";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:202:"http://wptavern.com/short-interview-with-john-james-jacoby-on-the-progress-of-bbpress-2-6?utm_source=rss&utm_medium=rss&utm_campaign=short-interview-with-john-james-jacoby-on-the-progress-of-bbpress-2-6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2962:"<div id="attachment_22420" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/JJJatWordCampNorthCanton2014.png" rel="prettyphoto[22416]"><img class="size-full wp-image-22420" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/JJJatWordCampNorthCanton2014.png?resize=734%2C282" alt="John James Jacoby Presenting On The bb\'s At WCNC 2014" /></a><p class="wp-caption-text">John James Jacoby Presenting On The bb&#8217;s At WCNC 2104</p></div>
<p>Over the past few years, I&#8217;ve had the privilege of conversing with a lot of smart people in the WordPress community. <a title="http://jaco.by/" href="http://jaco.by/">John James Jacoby</a> is one of those people I can talk to for hours on end. Not only does he care about online communities and forums as much as I do, but he&#8217;s incredibly intelligent about it.</p>
<p>Every time he and I are at a WordCamp together, I always find time to talk to him. I share the feelings I had while being an active member on forums and how he&#8217;s helping to bring that experience to the masses through the bb&#8217;s (<a title="http://buddypress.org/" href="http://buddypress.org/">BuddyPress</a> and <a title="https://bbpress.org/" href="https://bbpress.org/">bbPress</a>).</p>
<p>In the following interview, Jacoby explains how BuddyPress was able to achieve dramatic increases in performance. We also discuss whether or not forums are dead. Hint, we don&#8217;t think so. Last but not least, he gives us an update on what&#8217;s in store for bbPress 2.6 and why it hasn&#8217;t been released yet.</p>
<div class="audio-shortcode-wrap"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/JJJatWordCampNorthCanton2014.png?resize=175%2C131" alt="John James Jacoby Presenting On The bb\'s At WCNC 2104" class="landscape thumbnail post-thumbnail audio-image" /><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href="http://wptavern.com/wp-content/uploads/2014/05/John-James-Jacoby-at-WordCamp-North-Canton-2014.mp3">http://wptavern.com/wp-content/uploads/2014/05/John-James-Jacoby-at-WordCamp-North-Canton-2014.mp3</a></div><div class="media-shortcode-extend"><div class="media-info audio-info"><ul class="media-meta"><li><span class="prep">Run Time</span> <span class="data">7:38</span></li><li><span class="prep">Artist</span> <span class="data">Jeff Chandler</span></li><li><span class="prep">File Name</span> <span class="data"><a href="http://wptavern.com/wp-content/uploads/2014/05/John-James-Jacoby-at-WordCamp-North-Canton-2014.mp3">John-James-Jacoby-at-WordCamp-North-Canton-2014.mp3</a></span></li><li><span class="prep">File Size</span> <span class="data">3.92 MB</span></li><li><span class="prep">File Type</span> <span class="data">MP3</span></li><li><span class="prep">Mime Type</span> <span class="data">audio/mpeg</span></li></ul></div><a class="media-info-toggle">Audio Info</a></div>
<p>&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 03:30:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WPTavern: Recap Of WordCamp North Canton 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22365";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:134:"http://wptavern.com/recap-of-wordcamp-north-canton-2014?utm_source=rss&utm_medium=rss&utm_campaign=recap-of-wordcamp-north-canton-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8142:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/WCNC2014FeaturedImage.png" rel="prettyphoto[22365]"><img class="aligncenter size-full wp-image-22404" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/WCNC2014FeaturedImage.png?resize=650%2C192" alt="WordCamp North Canton 2014 Featured Image" /></a></p>
<p>Held within the Business and Entrepreneurial Center on the <a title="http://www.starkstate.edu/" href="http://www.starkstate.edu/">Stark State College campus</a>, <a title="http://2014.northcanton.wordcamp.org/" href="http://2014.northcanton.wordcamp.org/">WordCamp North Canton 2014</a> was a repeat success. Sessions ranged from <a title="http://2014.northcanton.wordcamp.org/sessions/#wcorg-session-511220" href="http://2014.northcanton.wordcamp.org/sessions/#wcorg-session-511220">Plugins 101</a> to the <a title="http://2014.northcanton.wordcamp.org/sessions/#wcorg-session-522042" href="http://2014.northcanton.wordcamp.org/sessions/#wcorg-session-522042">Science Of Design</a>. I only attended two sessions throughout the day as I spent the majority of my time networking. The sessions I participated in only had about 10-12 attendees but that didn&#8217;t faze the speaker as they still delivered a great presentation.</p>
<h3>Organizing The Second WordCamp Proved More Difficult Than The First</h3>
<p>When I interviewed one of the primary organizers of the event Joe Rozsa, he said the event was difficult to put together despite it being the second event he&#8217;s organized. A large amount of ticket sales near the time of the event added complexity but the team was able to overcome the challenge and maintain a smooth running WordCamp.</p>
<p>In the following interview, Rosza tells me how he was able to secure the venue on a college campus and the challenges he faced while organizing the event. He also gives some great advice to first time WordCamp organizers.</p>
<div class="audio-shortcode-wrap"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/WCNC2014FeaturedImage.png?resize=175%2C131" alt="WordCamp North Canton 2014 Featured Image" class="landscape thumbnail post-thumbnail audio-image" /><a href="http://wptavern.com/wp-content/uploads/2014/05/Interview-With-Joe-Rozsa.mp3">http://wptavern.com/wp-content/uploads/2014/05/Interview-With-Joe-Rozsa.mp3</a></div><div class="media-shortcode-extend"><div class="media-info audio-info"><ul class="media-meta"><li><span class="prep">Run Time</span> <span class="data">6:31</span></li><li><span class="prep">Artist</span> <span class="data">Jeff Chandler</span></li><li><span class="prep">File Name</span> <span class="data"><a href="http://wptavern.com/wp-content/uploads/2014/05/Interview-With-Joe-Rozsa.mp3">Interview-With-Joe-Rozsa.mp3</a></span></li><li><span class="prep">File Size</span> <span class="data">3.33 MB</span></li><li><span class="prep">File Type</span> <span class="data">MP3</span></li><li><span class="prep">Mime Type</span> <span class="data">audio/mpeg</span></li></ul></div><a class="media-info-toggle">Audio Info</a></div>
<h3>There Is Room For Improvement</h3>
<div id="attachment_22407" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/MainSessionRoomWordCampCanton2014.jpg" rel="prettyphoto[22365]"><img class="size-full wp-image-22407" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/MainSessionRoomWordCampCanton2014.jpg?resize=800%2C597" alt="Main Session Room" /></a><p class="wp-caption-text">Main Session Room</p></div>
<p>The room you see in the image above is the main session room. The front of room is where sessions were held while the tables in the back of the room were used for networking. Unfortunately during some of the sessions, there was a considerable amount of noise and chatter from the back of the room. Although some of the speakers didn&#8217;t mind, it felt rude to be talking and networking while a speaker was presenting.</p>
<p>I mentioned this to Rozsa who told me the facility would not allow him to close and open the room as needed. Hopefully next year, the building will allow this room to be sectioned off to keep the networking room and the presentation rooms separate.</p>
<div id="attachment_22408" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/WordCampNorthCanton2014Schedule.png" rel="prettyphoto[22365]"><img class="size-full wp-image-22408" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/WordCampNorthCanton2014Schedule.png?resize=834%2C307" alt="WordCamp North Canton 2014 Schedule" /></a><p class="wp-caption-text">WordCamp North Canton 2014 Schedule</p></div>
<p>This years event featured two tracks, one for users and developers. With under 200 attendees, I felt like having five sessions at the same time was too much. Some of the sessions I witnessed had under 10 people in the room while others were packed. I&#8217;d like to see the event scale back to three sessions at a time max. The event just doesn&#8217;t have the amount of attendees to justify five sessions at any given time.</p>
<p>There were also three sessions dedicated to security during the day. I attended the third session by <a title="http://2014.northcanton.wordcamp.org/sessions/#wcorg-session-511208" href="http://2014.northcanton.wordcamp.org/sessions/#wcorg-session-511208">Joseph Herbrandson</a> of Sucuri and it seemed like folks were worn out by the topic. Herbrandson delivers his information in an energetic way but being the third security session of day lead attendees to check out other sessions. With fewer presentations going on at the same time, it will help prevent this scenario from happening.</p>
<h3>Ermano&#8217;s Hits Another Home Run</h3>
<p>One of the highlights for me was the lunch prepared by <a href="http://ermannospizza.com/">Ermannos pizza</a>. Their Margherita pizza was just as good as last years. There were also plenty of salad dishes and beverages on hand. Lunch was capped off by Ermannos&#8217; now famous WordCamp S&#8217;mores. WordCamp North Canton 2014 ended the day at a local hotel bar for the after party.</p>
<h3>Looking Forward To Next Year</h3>
<p>Overall, the event was a success albeit with a few things to work on for 2015. The sessions I attended were presented by people passionate about the subject they were talking about. Most of the people in the audience were either new to WordPress or had little to no development experience. When I asked some of the attendees who also attend my local WordPress meetup what they thought of the event, every one of them said <strong>it was worth every penny</strong> with big smiles on their faces.</p>
<p>Joe Rozsa and his team of volunteer staff members are to be commended for a job well done. Thanks to everyone who helped put on a fantastic event in my back yard. As long as North Canton keeps holding a WordCamp, I&#8217;ll keep coming. Meanwhile, keep an eye on the official <a title="http://2014.columbus.wordcamp.org/" href="http://2014.columbus.wordcamp.org/">WordCamp Columbus Ohio blog</a> for information on the third WordCamp to be held in Ohio this year.</p>

<a href="http://wptavern.com/recap-of-wordcamp-north-canton-2014/attachment/712"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/712.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Plenty Of Salad Greens" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-north-canton-2014/attachment/713"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/713.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Best Pizza In Town" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-north-canton-2014/attachment/716"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/716.jpg?resize=150%2C150" class="attachment-thumbnail" alt="Ermannos Famous S\'mores" /></a>
<a href="http://wptavern.com/recap-of-wordcamp-north-canton-2014/attachment/715"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/715.jpg?resize=150%2C150" class="attachment-thumbnail" alt="WordCamp North Canton 2014" /></a>

<p>&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 06 May 2014 03:03:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Save Time Building WordPress Customizer Controls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=20157";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/save-time-building-wordpress-customizer-controls?utm_source=rss&utm_medium=rss&utm_campaign=save-time-building-wordpress-customizer-controls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4836:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/customizer-controls.jpg" rel="prettyphoto[20157]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/customizer-controls.jpg?resize=732%2C290" alt="customizer-controls" class="aligncenter size-full wp-image-22384" /></a></p>
<p>Adding controls to WordPress&#8217; theme customizer can be somewhat tedious and there are <a href="http://code.tutsplus.com/articles/custom-controls-in-the-theme-customizer--wp-34556" target="_blank">many</a> <a href="http://ottopress.com/2012/making-a-custom-control-for-the-theme-customizer/" target="_blank">tutorials</a> dedicated to creating your own controls. <a href="https://github.com/paulund/Wordpress-Theme-Customizer-Custom-Controls" target="_blank">WordPress Theme Customizer Custom Controls</a> is a project on Github that provides a collection of ready-made controls that you can drop right into your theme. This set of extra controls was created by WordPress developer <a href="http://www.paulund.co.uk/" target="_blank">Paul Underwood</a>.</p>
<p>The collection includes:</p>
<ul>
<li><strong>Category Dropdown</strong> &#8211; Creates a dropdown of all the categories on your WordPress theme</li>
<li><strong>Date Picker</strong> &#8211; Adds a date picker control to the theme customizer</li>
<li><strong>Layout Picker</strong> &#8211; Adds 3 images of layouts to the page for you to select a new style</li>
<li><strong>Menu Dropdown</strong> &#8211; Creates a dropdown of all the menus on your WordPress site</li>
<li><strong>Post Dropdown</strong> &#8211; Creates a dropdown of all the posts on your WordPress site</li>
<li><strong>Tags Dropdown</strong> &#8211; Creates a dropdown of all tags on your WordPress site</li>
<li><strong>Text Editor</strong> &#8211; Creates a textbox with the TinyMCE textarea</li>
<li><strong>Textarea</strong> &#8211; Creates a textarea input field</li>
<li><strong>Taxonomy Dropdown</strong> &#8211; Creates a dropdown of taxonomies ( Usage: see Gist <a href="https://gist.github.com/4538951" target="_blank">4538951</a> )</li>
<li><strong>User List Dropdown</strong> &#8211; Creates a dropdown of users for a role ( Usage: see Gist <a href="https://gist.github.com/4564337" target="_blank">4564337</a> )</li>
<li><strong>Google Fonts Dropdown</strong> &#8211; Create a dropdown to show you the 30 most popular fonts on Google web fonts</li>
</ul>
<h3>How to Use the WordPress Theme Customizer Custom Controls</h3>
<p>If you want to use all of the custom controls in your theme, including them is very simple. Download the project from Github, unpack it and then drop the /wordpress-theme-customizer-custom-controls/ directory wherever you want within your theme&#8217;s structure, making sure to adjust the path below if you change it. Add this to your theme&#8217;s <em>functions.php</em> file:</p>
<pre class="brush: php; light: true; title: ; notranslate">require_once \'/inc/wordpress-theme-customizer-custom-controls/theme-customizer-demo.php\';</pre>
<p>This will put all of the custom controls into the customizer under a &#8220;Custom Controls Demo&#8221; item and will include WordPress&#8217; default controls under &#8220;Default Demo Controls:&#8221;</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/controls.jpg" rel="prettyphoto[20157]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/controls.jpg?resize=578%2C458" alt="controls" class="aligncenter size-full wp-image-22393" /></a></p>
<p>Ideally, you would adjust the controls to better suit your theme and add only the ones that work with the design. It provides a great starting place and an easy way to learn more about how the controls are created, should you want to add more of your own.</p>
<p>The Taxonomy and User List dropdowns both require a bit of extra setup and the usage is demonstrated in the example gists for each. The Google Fonts Dropdown has built-in caching, which <a href="http://www.paulund.co.uk/cache-google-web-fonts-api" target="_blank">creates a cache file on the user&#8217;s machine</a> so that you don&#8217;t have to call the API so many times.</p>
<p>Adding custom controls to the customizer is a great way to allow for more personalization in a theme created for a client or for public distribution. The user can easily change styles and preview them live, without having to make requests for design changes. Hopefully, the <a href="https://github.com/paulund/Wordpress-Theme-Customizer-Custom-Controls" target="_blank">Custom WordPress Customizer Controls</a> can save you a little time in building out your next theme. For more information, check out the project&#8217;s Github page and Paul Underwood&#8217;s <a href="http://www.paulund.co.uk/custom-wordpress-controls" target="_blank">post</a> detailing each control.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 May 2014 22:14:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WordPress.tv: Nick Pelton: WP-to-JS And Back Again";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34524";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.tv/2014/05/05/nick-pelton-wp-to-js-and-back-again/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:655:"<div id="v-ZhP9A2Yv-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34524/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34524/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34524&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/05/nick-pelton-wp-to-js-and-back-again/"><img alt="Nick Pelton: WP-to-JS And Back Again" src="http://videos.videopress.com/ZhP9A2Yv/video-4f0e59c288_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 May 2014 21:25:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: Automattic Is Raising $160M in New Funding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22349";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:146:"http://wptavern.com/automattic-is-raising-160m-in-new-funding?utm_source=rss&utm_medium=rss&utm_campaign=automattic-is-raising-160m-in-new-funding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3433:"<div id="attachment_22370" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/automattic-offices.jpg" rel="prettyphoto[22349]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/automattic-offices.jpg?resize=1025%2C478" alt="photo credit: Peter Slutsky" class="size-full wp-image-22370" /></a><p class="wp-caption-text">photo credit: <a href="http://peterslutsky.com/2013/05/14/pics-touring-automattics-new-office/">Peter Slutsky</a></p></div>
<p>WordPress currently powers <a href="http://w3techs.com/technologies/overview/content_management/all" target="_blank">22% of all websites</a>, up from 18% in 2013, with a CMS market share of 59.8%. The success of WordPress.com, Automattic&#8217;s flagship product, is part of the reason that number continues to rise steadily. WordPress.com makes it easy for anyone to create a WordPress site without the burden of setting up hosting to install the software.</p>
<p>This morning Automattic&#8217;s founder, Matt Mullenweg, <a href="http://ma.tt/2014/05/new-funding-for-automattic/" target="_blank">announced</a> that the company is raising $160M in new funding. After taking the helm as CEO <a href="http://wptavern.com/matt-mullenweg-takes-on-new-role-as-ceo-of-automattic" target="_blank">earlier this year</a>, Mullenweg said that he set out on a 100-day plan to pursue new funding and find a set of partners who share Automattic&#8217;s vision of an open web.</p>
<p>Although Automattic is healthy and growing, Mullenweg cites recent infrastructure and product investments as part of the reason the company will require more cash in order to continue its rapid growth.</p>
<blockquote><p>Things were and are going well, but there was an opportunity cost to how we were managing the company toward break-even, and we realized we could invest more into WordPress and our products to grow faster.</p></blockquote>
<p>This is the first time the company has raised money since 2008 when it pulled in $12 million. Automattic is now valued at $1.16 billion for this round of $160 million in new funding. <strong>&#8220;This is obviously a lot of money, especially considering everything we&#8217;ve done so far has been built on only about $12M of outside capital over the past 8 years,&#8221;</strong> Mullenweg said.</p>
<p>The new funding opens a window of opportunity for Automattic and enables the company to launch new products and hire more employees to support its rapid growth. Mullenweg, who is also the co-founder of the open source WordPress project, closes his announcement post with a reaffirmation of Automattic&#8217;s commitment to support the community behind WordPress.</p>
<blockquote><p>I believe WordPress will win, first and foremost, because of its community — the hundreds of core developers and large commercial companies, the tens of thousands of plugin and theme developers, and the millions of people who build beautiful things with WordPress every day. Automattic is here to support that community and invest the full strength of our resources to making WordPress a better product every day, bringing us closer to our shared mission of democratizing publishing.</p></blockquote>
<p>With this round of fundraising finishing shortly, it&#8217;s clear that Automattic&#8217;s investors are ready to support its guiding mission, and they&#8217;re betting firmly on the community behind WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 May 2014 17:25:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Matt: New Funding for Automattic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43810";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ma.tt/2014/05/new-funding-for-automattic/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3237:"<p>I&#8217;ll start with the big stuff: <a href="http://automattic.com/">Automattic</a> is raising $160M, all primary, and it&#8217;s the first investment into the company since 2008. This is obviously a lot of money, especially considering everything we&#8217;ve done so far has been built on only about $12M of outside capital over the past 8 years. It was also <a href="http://ma.tt/2013/05/automattic-secondary/">only a year ago I said</a> &#8220;Automattic is healthy, generating cash, and already growing as fast as it can so there’s no need for the company to raise money directly — we’re not capital constrained.&#8221;</p>
<p>I was wrong, but I didn&#8217;t realize it until <a href="http://ma.tt/2014/01/toni-automattic-ceo/">I took on the CEO role in January</a>. Things were and are going well, but there was an opportunity cost to how we were managing the company toward break-even, and we realized we could invest more into WordPress and our products to grow faster. Also our cash position wasn&#8217;t going to be terribly strong especially after a number of infrastructure and product investments this and last year. So part of my 100-day plan as CEO was to figure out what new funding could look like and we found a great set of partners who believe in our vision for how the web should be and how we can scale into the opportunity ahead of us, though it ended up taking 110 days until the first close. (Our other main areas of focus have been improving mobile, a new version of WP.com, and <a href="http://jetpack.me/">Jetpack</a>.)</p>
<p>This Series C round was led by Deven Parekh of Insight Venture Partners, and included new investors Chris Sacca, Endurance, and a special vehicle True Ventures created to step up their investment, alongside our existing secondary investors from last year, Tiger and Iconiq. (There is a second close soon so this list might change a bit.) There was interest significantly above what we raised, but we focused in on finding the best partners and scaled it back to be the right amount of capital at the right valuation. Deven and Insight share our long term vision and are focused on building an enduring business, one that will thrive for decades to come.</p>
<p>WordPress is in a market as competitive as it has ever been, especially on the proprietary and closed side. I believe WordPress will win, first and foremost, because of its community &#8212; the hundreds of core developers and large commercial companies, the tens of thousands of plugin and theme developers, and the millions of people who build beautiful things with WordPress every day. Automattic is here to support that community and invest the full strength of our resources to making WordPress a better product every day, bringing us closer to our shared mission of democratizing publishing. But a majority of the web isn&#8217;t on an open platform yet, and we have a lot of work ahead of us. Back to it!</p>
<p>You can read more about the news by Kara and Liz on Recode: <a href="http://recode.net/2014/05/05/wordpress-parent-automattic-has-raised-160-million-now-valued-at-1-16-billion-post-money/">WordPress.com Parent Automattic Has Raised $160 Million, Now Valued at $1.16 Billion Post-Money</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 May 2014 15:04:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Panel Discussion: Commercial WordPress Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34454";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wordpress.tv/2014/05/04/panel-discussion-commercial-wordpress-products/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-RHhsoJGg-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34454/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34454/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34454&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/04/panel-discussion-commercial-wordpress-products/"><img alt="Panel Discussion: Commercial WordPress Products" src="http://videos.videopress.com/RHhsoJGg/video-7c7577a0e5_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 May 2014 18:23:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress.tv: Heather Acton: Stop Giving Stuff Away For Free and Start Feeding Your Family!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34452";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://wordpress.tv/2014/05/04/heather-acton-stop-giving-s-away-for-free-and-start-feeding-your-family/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:730:"<div id="v-5UPOSUY0-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34452/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34452/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34452&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/04/heather-acton-stop-giving-s-away-for-free-and-start-feeding-your-family/"><img alt="Heather Acton: Stop Giving S** Away For Free and Start Feeding Your Family!" src="http://videos.videopress.com/5UPOSUY0/video-a9b5eca4fc_scruberthumbnail_3.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 May 2014 18:08:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Dave West &amp; Amy Abt: Where’s My Maserati?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34450";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.tv/2014/05/03/dave-west-amy-abt-wheres-my-maserati/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:657:"<div id="v-sM44W6og-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34450/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34450/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34450&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/03/dave-west-amy-abt-wheres-my-maserati/"><img alt="Dave West & Amy Abt: Where’s My Maserati?" src="http://videos.videopress.com/sM44W6og/video-0152f3f8f3_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 03 May 2014 18:37:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress.tv: Lindsey Guajardo: Remote Project Management";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34448";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2014/05/03/lindsey-guajardo-remote-project-management/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:669:"<div id="v-Iz6XMFii-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34448/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34448/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34448&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/03/lindsey-guajardo-remote-project-management/"><img alt="Lindsey Guajardo: Remote Project Management" src="http://videos.videopress.com/Iz6XMFii/video-2b88c73170_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 03 May 2014 18:17:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Mark Jaquith: Ask Mark Anything";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:40:"http://markjaquith.wordpress.com/?p=5113";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://markjaquith.wordpress.com/2014/05/03/ask-mark-anything/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1337:"<p>People ask me a lot of questions. About WordPress and web development for sure, but also about other topics. I&#8217;ve decided to try a little experiment: <a href="https://github.com/markjaquith/feedback/">a public way to ask me questions</a>. Zach Holman from GitHub had the idea to use a GitHub issue tracker for this very purpose, and I think it looks like a splendid idea.</p>
<p>Benefits:</p>
<ul>
<li>Allows for more in-depth discussions than Twitter (but you can still <a href="https://twitter.com/markjaquith">talk to me on Twitter</a> for quick questions).</li>
<li>Is public (as opposed to e-mail).</li>
<li>Forces me to deal with questions.</li>
</ul>
<p>Now, note that this doesn&#8217;t mean I want you to treat me like your personal Google-searcher or WordPress code grepper! But if you think there is a WordPress (or other) topic that I am uniquely qualified to address, <a href="https://github.com/markjaquith/feedback/">just ask</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/markjaquith.wordpress.com/5113/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/markjaquith.wordpress.com/5113/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=markjaquith.wordpress.com&blog=316&post=5113&subd=markjaquith&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 03 May 2014 05:21:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: GoDaddy Removes Ticketing and Email Support In Favor Of Phone and Live Chat";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22168";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/godaddy-removes-ticketing-and-email-support-in-favor-of-phone-and-live-chat?utm_source=rss&utm_medium=rss&utm_campaign=godaddy-removes-ticketing-and-email-support-in-favor-of-phone-and-live-chat";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8349:"<p>A few days ago, GoDaddy quietly removed the ability to submit a trouble ticket or an email to receive support. This was verified through the <a title="https://twitter.com/GoDaddyHelp" href="https://twitter.com/GoDaddyHelp">GoDaddy Help</a> twitter account.</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/mistical">@mistical</a> We did discontinue our email support. However, we do offer live chat now. It can be accessed here: <a href="http://t.co/HFw77fAJTh">http://t.co/HFw77fAJTh</a> ^KJ</p>
<p>&mdash; GoDaddy Help (@GoDaddyHelp) <a href="https://twitter.com/GoDaddyHelp/statuses/461695002520072192">May 1, 2014</a></p></blockquote>
<p></p>
<p>Both support methods were removed in favor of live chat and phone support. I reached out to GoDaddy&#8217;s media representatives and asked why the options were removed and why they weren&#8217;t more forthcoming about the changes. Nick Fuller, a GoDaddy representative explained that email consistently finished last as far as their customers&#8217; preferred method of help.</p>
<blockquote><p>After reviewing customer behavior and satisfaction scores we decided we could better serve people in ways they were telling us work better for them.</p>
<p>Customers love the ‘real time’ support experience. Email is not instantaneous and in fact many in the industry are putting an end to their email service as well because fewer than half of tech customers believe their problem can be solved by email – it’s sort of going the way of the cassette tape.</p></blockquote>
<p>Former GoDaddy employee Brad Cook, was one of the first to <a title="http://www.clicknowmarketing.com/domains/godaddy-ends-email-support/" href="http://www.clicknowmarketing.com/domains/godaddy-ends-email-support/">report on the loss of email and ticket support</a>. Cook <a title="https://www.youtube.com/watch?v=Vosu4bTUJ4Y" href="https://www.youtube.com/watch?v=Vosu4bTUJ4Y">documented his effort</a> in a YouTube video showing the drawbacks of the live support option. He ended up having to wait 1.5 hours for help. Unfortunately, his wait was for nothing, &#8220;I had to rush into the other room as my son was getting sick right around the time my turn in line came up and I ended up missing my opportunity to chat after this long wait.&#8221;</p>
<h3>Which Is A Quicker Means Of Support, Phone Or Live Chat?</h3>
<p>On the afternoon of March 30th, I performed an experiment. I wanted to find out which method of support was quicker and whether or not the support representatives would try to upsell me on other services. I explained to both parties that I wanted to know when my domain was up for renewal.</p>
<p><strong>Phone Support</strong>: The wait time on the phone was only nine minutes. Once on the line, the gentleman spoke English, was to the point, and politely asked how he could help. I asked when my domain was up for renewal. He told me the exact date while also explaining how I could find that information out myself via the GoDaddy control panel. He said they could renew it for me on the phone or I could do it myself. I chose to do it myself.</p>
<p>He asked how else he could help and I told him that was the only question I had. He thanked me and said have a good day. <strong>At no point</strong> during the phone call did he try to sell me services such as webhosting to go with my domain. In fact, the experience was better than I expected.</p>
<p><strong>Live Chat</strong>:</p>
<p>I started the Live Chat session at the same time I called GoDaddy. As you can see from the image below, I had to <strong>wait 35 minutes</strong>. While Cook experienced inaccurate waiting times, I found mine to be relatively accurate.</p>
<div id="attachment_22318" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/GoDaddyLiveChat.png" rel="prettyphoto[22168]"><img class="size-full wp-image-22318" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/GoDaddyLiveChat.png?resize=720%2C582" alt="GoDaddy Live Chat" /></a><p class="wp-caption-text">Waiting In A Virtual Line</p></div>
<p>After waiting on the live chat for 10 minutes, I already had my problem solved via phone support. When I eventually got the chance to speak with a tech support representative, I was able to verify a couple of problems outlined by Cook.</p>
<ul>
<li>There is no audible or visual cue that indicates it&#8217;s my turn to talk</li>
<li>If the chat window is minimized, it doesn&#8217;t blink in the taskbar when a message has been received</li>
</ul>
<p>I asked the chat rep when my domain would need to be renewed. They responded in a few minutes with the correct answer and told me they could renew it for me, or I could do it manually. I told them I&#8217;d do it manually. I thanked the rep for helping me. After the usual <em>you&#8217;re welcome message</em>, my chat session was closed. <strong>At no point</strong> during the chat session did they try to sell me services such as webhosting to go with my domain.</p>
<h3>GoDaddy Is Addressing Growing Pains With Live Chat</h3>
<p>Phone support at GoDaddy was a superior experience compared to live chat. Because of the problems mentioned earlier, it&#8217;s too easy to miss your opportunity to chat with a representative. Once you&#8217;ve lost your chance, you have to go to the end of the line. I shared Cook&#8217;s post to GoDaddy and Fuller admits there is work to be done to improve the experience.</p>
<blockquote><p>There’s work to be done and we’re just in the beginning phases of the transition. As of today, we’ve expanded our live chat support team by 20 representatives in order to better meet the demand in the general customer care chat. We’re also expanding the team for live chat support on the hosting side and we’re working with our live chat tool provider to provide an audio notification when a chat session is ready to go.</p></blockquote>
<p>It&#8217;s a good thing GoDaddy has added more representatives to address demand because waiting for 30 minutes is unacceptable. I&#8217;ve used the live chat for HostGator and other service providers and the wait times have generally been under 10 minutes. Most of the time, I can reach someone without any wait at all.</p>
<p>I prefer live chat over speaking with someone on the phone because it&#8217;s a more natural means of communication for me. It&#8217;s also easier to send URL&#8217;s through chat than over the phone. However, I&#8217;m glad that each support method didn&#8217;t try to upsell me on additional products and services. Such a practice during a time of need is slimy at best.</p>
<h3>Aligning With Customer Needs</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2009/08/gravitylogo.png" rel="prettyphoto[22168]"><img class="alignright size-full wp-image-2322" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2009/08/gravitylogo.png?resize=108%2C109" alt="gravityforms logo" /></a>I certainly don&#8217;t fault GoDaddy for doing away with email and ticket based support. Since their data supports the reasoning for getting rid of them, it makes sense. In mid 2013, <a title="http://www.gravityhelp.com/gravity-forms-standard-support-change-announcement/" href="http://www.gravityhelp.com/gravity-forms-standard-support-change-announcement/">GravityForms changed their standard support structure</a> to remove forums. The move was inspired by the explosive growth of their product and the forum had become unmanageable.</p>
<p>I like support forums since they give me an opportunity to help myself but for successful companies, they can easily become unmanageable. But the move was made to <em>better serve the needs of their customers</em>.</p>
<p>As a company, it makes sense to do whatever is best for the customer. If you&#8217;d like advice on hiring support staff for your WordPress business, <a title="http://wptavern.com/wordpress-commercial-theme-businesses-offer-advice-on-hiring-support-staff" href="http://wptavern.com/wordpress-commercial-theme-businesses-offer-advice-on-hiring-support-staff">check out this post</a> which contains advice from some of the most successful commercial WordPress theme companies.</p>
<p>When it comes to support, what is your preferred method? Tickets, FAQ&#8217;s, Forums, Email, or something else?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 03 May 2014 03:20:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"BuddyPress: BuddyPress 2.0.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://buddypress.org/?p=182380";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://buddypress.org/2014/05/buddypress-2-0-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1049:"<p>BuddyPress 2.0.1 is now available. Download from <a href="http://wordpress.org/plugins/buddypress/">the wordpress.org plugin repository</a>, as a <a href="http://downloads.wordpress.org/plugin/buddypress.2.0.1.zip">zip file</a>, or through WordPress via Dashboard &gt; Plugins.</p>
<p>This maintenance release includes a number of important fixes, including:</p>
<ul>
<li>Improvements to some 1.9.x-2.0.x upgrade routines, including the creation of the <code>wp_signups</code> table and the migration of <code>last_activity</code> data</li>
<li>Fixes for a handful of regressions related to group querying and creation</li>
<li>Backward compatibility improvements for plugins that extend the xprofile component</li>
</ul>
<p>For a complete list of changes made for this release, visit the <a href="http://codex.buddypress.org/developer/releases/version-2-0-1/">2.0.1 changelog</a>.</p>
<p>Questions or comments? Visit out <a href="https://buddypress.org/support">support forums</a> or <a href="https://buddypress.trac.wordpress.org">Trac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 03 May 2014 01:22:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Boone Gorges";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: Steve Jobs in 1983";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43806";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2014/05/steve-jobs-in-1983/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:572:"<p></p>
<p>I really enjoyed listening to this <a href="http://lifelibertytech.com/2012/10/02/the-lost-steve-jobs-speech-from-1983-foreshadowing-wireless-networking-the-ipad-and-the-app-store/">&#8220;Lost&#8221; Steve Jobs Speech from 1983; Foreshadowing Wireless Networking, the iPad, and the App Store</a>. In the beginning he asks who is over 36 years old, and says those are the people who were born before the computer. He also perfectly describes Google Street Maps as an early MIT experiment in Aspen. Really fascinating from end to end, including the Q&#038;A.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 03 May 2014 01:05:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: WordPress Query Monitor Plugin Crosses 10,000 Downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22219";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/wordpress-query-monitor-plugin-crosses-10000-downloads?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-query-monitor-plugin-crosses-10000-downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2436:"<p>The <a href="http://wordpress.org/plugins/query-monitor/" target="_blank">Query Monitor</a> plugin was released by <a href="https://twitter.com/johnbillion/" target="_blank">John Blackbourn</a> in late November of 2013 and became an instant hit with WordPress developers. It&#8217;s racked up 25 five-star reviews on WordPress.org and today crossed the 10,000 download mark, which doesn&#8217;t even factor in the number of times the <a href="https://github.com/johnbillion/query-monitor" target="_blank">Github</a> repo has been cloned.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/reviews.jpg" rel="prettyphoto[22219]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/reviews.jpg?resize=810%2C269" alt="reviews" class="aligncenter size-full wp-image-22295" /></a></p>
<p>Query Monitor is without a doubt the most comprehensive debugging plugin for WordPress, often replacing multiple plugins developers previously combined to try to get the same tools. Its features are too long to list, but suffice it to say that it offers a solid overview of database queries, hooks that are being fired, theme template information, HTTP Requests, Redirects and much more.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2013/11/qm.jpg" rel="prettyphoto[22219]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2013/11/qm.jpg?resize=572%2C368" alt="qm" class="aligncenter size-full wp-image-11776" /></a></p>
<p>If you use it on a community site, there&#8217;s a separate <a href="http://wptavern.com/new-plugin-adds-bbpress-and-buddypress-conditionals-to-query-monitor" target="_blank">extension</a> that will add bbPress and BuddyPress conditionals to Query Monitor&#8217;s output.</p>
<p>The plugin is updated quite often and the most recent 2.6.6 release adds more robust support for alternative database drivers (including mysqli in core). Nearly every topic in the plugin&#8217;s support queue is marked as resolved and John Blackbourn is very responsive to issues and questions on Github. It&#8217;s easy to see why Query Monitor has so quickly become a must-have debugging plugin for WordPress developers.</p>
<p>If you haven&#8217;t yet tried it, you can <a href="http://wordpress.org/plugins/query-monitor/" target="_blank">download</a> Query Monitor from WordPress.org. Site admins and multisite super admins will have access to its output in the admin bar.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 23:06:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Akismet: A Custom Measure of Akismet Performance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1484";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://blog.akismet.com/2014/05/02/a-custom-measure-of-akismet-performance/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1212:"<p>Just a little something for the weekend.</p>
<p>Chris Hemedinger, a technical architect at <a href="http://www.sas.com/en_us/home.html/">SAS</a>, recently published a <a href="http://blogs.sas.com/content/sasdummy/2014/05/01/blog-spam-akismet/">great post</a> on his personal analysis of Akismet&#8217;s effectiveness across an entire network of company blogs.</p>
<p>He uses his own company&#8217;s software to connect to his WordPress database and aggregate data from all Akismet-protected sites on the network. He then produces some really interesting charts and graphs for the purpose of analyzing spam activity and Akismet&#8217;s performance. Chris also makes it clear that having to manually deal with all that spam can be quite time-consuming. </p>
<p>And we tend to agree. <span class="wp-smiley emoji emoji-smile" title=":)">:)</span></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1484/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1484/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1484&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 20:57:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WordPress for Android 2.8 Released, New Beta Testers Needed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22207";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/wordpress-for-android-2-8-released-new-beta-testers-needed?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-for-android-2-8-released-new-beta-testers-needed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2357:"<div id="attachment_22273" class="wp-caption alignright"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-for-android.png" rel="prettyphoto[22207]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-for-android.png?resize=1025%2C442" alt="WordPress for Android" class="size-full wp-image-22273" /></a><p class="wp-caption-text">WordPress for Android</p></div>
<p><a href="http://android.wordpress.org/" target="_blank">WordPress for Android</a> shipped its <a href="http://android.wordpress.org/2014/05/01/wordpress-for-android-2-8/" target="_blank">2.8 release</a> late last night. This milestone includes <a href="https://github.com/wordpress-mobile/WordPress-Android/issues?milestone=11&page=1&state=closed" target="_blank">55 closed issues</a>. This release is packed full of many small bug fixes, better language support, and performance improvements. Here are the highlights:</p>
<ul>
<li>App startup time has been reduced, and the Statistics screen will load faster.</li>
<li>The app is now available in Turkish, English (UK), and offers improved support for Traditional Chinese.</li>
<li>Samsung users will now be able to use the app in multi-window.</li>
<li>Notification and Comment screens have been reworked to enhance the user experience on small tablets.</li>
</ul>
<p>Version 2.7, released last month, introduced pull-to-refresh for loading up fresh content and optimized Stats to load and scroll faster. Stats addicts will be happy to know that latest 2.8 release delivers even more dramatic speed improvements, making Stats easier to navigate. If your Android device hasn&#8217;t already prompted you to update, you can visit <a href="https://play.google.com/store/apps/details?id=org.wordpress.android" target="_blank">Google Play</a> on your device to trigger the update.</p>
<h3>Call for Beta Testers</h3>
<p>If you&#8217;re a serious WordPress for Android user and want to help out as a beta tester, you can request to join the <a href="https://plus.google.com/communities/108813167297661427043" target="_blank">Google+ community</a> dedicated to testing the app. Beta testers will have access to beta versions with beta updates shipped directly through Google Play. The beta versions may have new features, new fixes, and possibly new bugs, so testers should be available to provide feedback.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 20:49:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: WordPress Cheat Sheet For Commonly Used Template Functions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22214";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/wordpress-cheat-sheet-for-commonly-used-template-functions?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-cheat-sheet-for-commonly-used-template-functions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2648:"<p>If you find yourself constantly referring to the <a title="http://codex.wordpress.org/" href="http://codex.wordpress.org/">Codex</a> or searching for a commonly used template function, consider bookmarking this <a title="http://wp-cheatsheet.com/" href="http://wp-cheatsheet.com/">WordPress Cheat Sheet </a>created by Trevor Niemi. Launched in February of this year, Niemi created the site after seeing a pixelated image of the same information published to Reddit. When asked how often the site is updated, Niemi says he&#8217;s &#8220;actively updating it when Codex changes occur and when a good suggestion is submitted by a user.&#8221;</p>
<p>The cheat sheet has a listing of functions you can copy and paste into your work. Several of the functions are linked to their corresponding Codex pages for more information and general usage. There&#8217;s also a <a title="http://wp-cheatsheet.com/wp-cheatsheet.com.pdf" href="http://wp-cheatsheet.com/wp-cheatsheet.com.pdf">PDF link</a> making it easy to save and view the information offline.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wpfunctioncheatsheet2.png" rel="prettyphoto[22214]"><img class="aligncenter size-full wp-image-22240" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wpfunctioncheatsheet2.png?resize=647%2C414" alt="WP Cheat Sheet In Action" /></a></p>
<p>When asked whether the site would expand to cover more information, Niemi responded, &#8220;future thinking, or expanding, is tricky. I really don&#8217;t want to alienate the user base by trying to churn a profit or anything like that because of how fickle developers are in general when things change and the nature of what a simple cheat sheet should provide a user.&#8221; Although he has some ideas, he hasn&#8217;t been able to dedicate time or attention to the site.</p>
<p>Since the site launched, WP-Cheatsheet has received 15,000 total visits with an average of 100 per day. Niemi says, &#8220;the site has become a fun, no stress project that I think people actually use which makes me happy&#8221;.</p>
<p>If you&#8217;re looking for more code resources, we <a title="http://wptavern.com/wordpress-code-reference-is-now-live" href="http://wptavern.com/wordpress-code-reference-is-now-live">recently wrote about</a> the launch of the official WordPress code reference site. Also take a look at <a title="http://wptavern.com/introducing-hookr-io-a-new-resource-for-wordpress-developers" href="http://wptavern.com/introducing-hookr-io-a-new-resource-for-wordpress-developers">Hookr.io</a> to see an alternative approach to viewing the code that powers WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 18:48:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: The Mina Olen Free WordPress Theme Experiment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22210";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/the-mina-olen-free-wordpress-theme-experiment?utm_source=rss&utm_medium=rss&utm_campaign=the-mina-olen-free-wordpress-theme-experiment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4526:"<div id="attachment_22252" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/experiment.jpg" rel="prettyphoto[22210]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/experiment.jpg?resize=1025%2C484" alt="photo credit: CIMMYT - cc" class="size-full wp-image-22252" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/cimmyt/6801601408/">CIMMYT</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a></p></div>
<p>Sami Keijonen, founder of <a href="https://foxnet-themes.fi/" target="_blank">Foxnet Themes</a>, is not happy with his theme sales, which total $1400 since early 2013. His <a href="https://foxnet-themes.fi/downloads/kultalusikka/" target="_blank">Kultalusikka</a> theme is the sales leader, with just 15 purchases. Keijonen has one theme for sale on WordPress.com, which was added in March of this year and has so far <a href="https://twitter.com/samikeijonen/status/461927487422095360" target="_blank">netted him $147.64</a>.</p>
<p>In a recent <a href="https://foxnet-themes.fi/experiment-commercial-theme-for-free/" target="_blank">post</a> that frankly details his disappointment with the sales, Keijonen announced a new theme experiment wherein he will be releasing some of his commercial themes on github, starting with his latest Mina Olen theme. This is the same theme that is available for sale on <a href="http://theme.wordpress.com/themes/mina-olen/" target="_blank">WordPress.com</a> for $75 and on <a href="https://foxnet-themes.fi/downloads/mina-olen/" target="_blank">Foxnet</a> for 39.00€.</p>
<p>Mina Olen is based on Justin Tadlock&#8217;s <a href="http://themehybrid.com/hybrid-core" target="_blank">Hybrid Core</a>. All of its options can be found in WordPress&#8217; customizer. The theme includes support for many major plugins in order to provide additional functionality, including <a href="http://wordpress.org/plugins/bbpress/" target="_blank">bbPress</a>, <a href="http://wordpress.org/extend/plugins/easy-digital-downloads/" target="_blank">Easy Digital Downloads</a>, <a href="http://wordpress.org/extend/plugins/custom-content-portfolio/" target="_blank">Custom Content Portfolio</a>, <a href="http://wordpress.org/plugins/testimonials-by-woothemes/" target="_blank">Testimonials</a>, <a href="http://wordpress.org/plugins/custom-header-extended/" target="_blank">Custom Header Extended</a>, and more.</p>
<div id="attachment_22232" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/mina-olen.jpg" rel="prettyphoto[22210]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/mina-olen.jpg?resize=880%2C660" alt="Mina Olen WordPress Theme" class="size-full wp-image-22232" /></a><p class="wp-caption-text">Mina Olen WordPress Theme</p></div>
<p>Keijonen emphasizes that he is still referring to the theme as a commercial product, because he will not be offering support or automatic updates for free. Since it&#8217;s just an experiment, he retains the option to make the Github repo private at any time in the future.</p>
<p>Keijonen is watching the results of the experiment to see if it affects the popularity of his theme, as well as the sales for support. He&#8217;s hoping that if people can test drive the theme before they make a decision, they will be more inclined to purchase support. &#8220;I can show off my code, it’s pretty solid,&#8221; he said. &#8220;That way I can build more trust.&#8221;</p>
<p>Having the theme&#8217;s code publicly available on Github will enable developers to contribute improvements to it. Mina Olen is one of his go-to themes that allows him to create custom child themes in no time, such as the <a href="http://tarkkanen.fi/" target="_blank">jewelry site</a> he recently launched. He&#8217;s hoping that people will be able to more easily use it in their projects, especially those who build on top of the Theme Hybrid framework.</p>
<p>The <a href="http://foxnet-themes.fi/demo/mina-olen/" target="_blank">live demo</a> for the theme shows all of the post formats in action, along with the many layouts and color schemes. If you want to participate in the experiment, you can <a href="https://github.com/samikeijonen/mina-olen" target="_blank">download the Mina Olen WordPress theme</a> for free from Github. Does access to the theme for free make you more inclined to pay for support or more likely to purchase another theme in Foxnet collection?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 18:23:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WordPress.tv: Interview de Cédric Motte, orateur de “Sans contenu, WordPress n’est rien”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34467";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2014/05/02/interview-de-cedric-motte-orateur-de-sans-contenu-wordpress-nest-rien/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:690:"<div id="v-yRTlnUbC-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34467/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34467/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34467&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/02/interview-de-cedric-motte-orateur-de-sans-contenu-wordpress-nest-rien/"><img alt="13 &#8211; Cedric Motte-Itw-WCParis2014.mp4" src="http://videos.videopress.com/yRTlnUbC/video-ffc44b5e49_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 16:32:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress.tv: Patrick Rauland: How to Build A Sustainable Business Using The Freemium Model";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34446";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:110:"http://wordpress.tv/2014/05/02/patrick-rauland-how-to-build-a-sustainable-business-using-the-freemium-model-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:739:"<div id="v-AS01R6wG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34446/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34446/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34446&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/02/patrick-rauland-how-to-build-a-sustainable-business-using-the-freemium-model-2/"><img alt="Patrick Rauland: How to Build A Sustainable Business Using The Freemium Model" src="http://videos.videopress.com/AS01R6wG/video-05a025c611_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 12:23:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Alison Barrett: Avoid Breaking All The Things: How to Develop Safely";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34444";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2014/05/02/alison-barrett-avoid-breaking-all-the-things-how-to-develop-safely/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:718:"<div id="v-XRTVnlcp-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34444/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34444/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34444&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/02/alison-barrett-avoid-breaking-all-the-things-how-to-develop-safely/"><img alt="Alison Barrett: Avoid Breaking All The Things: How to Develop Safely" src="http://videos.videopress.com/XRTVnlcp/video-db2348d109_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 11:48:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"WP Android: WordPress for Android 2.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://android.wordpress.org/?p=1017";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://android.wordpress.org/2014/05/01/wordpress-for-android-2-8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1913:"<p>We&#8217;re pleased to bring you WordPress for Android Version 2.8, which offers the following improvements: </p>
<h2><a class="anchor" href="http://android.wordpress.org/feed/#whats-new" name="user-content-whats-new"></a>What&#8217;s new</h2>
<ul>
<li>App startup time has been reduced, and the Statistics screen will load faster.</li>
<li>The app is now available in Turkish, English (UK), and offers improved support for Traditional Chinese.</li>
<li>Samsung users will now be able to use the app in multi-window.</li>
<li>Notification and Comment screens have been reworked to enhance the user experience on small tablets.</li>
</ul>
<p>Check out the <a href="https://github.com/wordpress-mobile/WordPress-Android/issues?milestone=11&page=1&state=closed">GitHub milestone</a> for more info.</p>
<h2><a class="anchor" href="http://android.wordpress.org/feed/#download" name="user-content-download"></a>Download</h2>
<p>Download it now from <a href="https://play.google.com/store/apps/details?id=org.wordpress.android">Google Play</a>.</p>
<h2><a class="anchor" href="http://android.wordpress.org/feed/#thanks" name="user-content-thanks"></a>Thanks</h2>
<p>A huge thank you to the contributors who helped make this release happen:<br />
<a href="https://github.com/anirudh24seven">@anirudh24seven</a>, <a href="https://github.com/daniloercoli">@daniloercoli</a>, <a href="https://github.com/maxme">@maxme</a>, <a href="https://github.com/mixpanelsteve">@mixpanelsteve</a>, <a href="https://github.com/nbradbury">@nbradbury</a>, <a href="https://github.com/roundhill">@roundhill</a>, <a href="https://github.com/sendhil">@sendhil</a></p>
<p>Be sure to follow <a href="https://twitter.com/wpandroid">WPAndroid</a> for all of the latest updates.</p><img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=android.wordpress.org&blog=9426921&post=1017&subd=wpandroid&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 May 2014 07:06:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Maxime";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: WP Rocket Launches Commercial Caching Plugin for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22171";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:180:"http://wptavern.com/wp-rocket-launches-commercial-caching-plugin-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=wp-rocket-launches-commercial-caching-plugin-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5830:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket.jpg" rel="prettyphoto[22171]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket.jpg?resize=237%2C300" alt="wp-rocket" class="alignright size-medium wp-image-22175" /></a><a href="http://wp-rocket.me/" target="_blank">WP Rocket</a> is a new commercial caching plugin for WordPress that launched exclusively in the French market eight months ago. It&#8217;s created and supported by Julio Potier, Jonathan Buttigieg, and Jean-Baptiste Marchand-Arvier, a small group of Frenchmen with a passion for website optimization.</p>
<p>WP Rocket is making its international debut this month in a market that is currently dominated by free WordPress caching solutions. Aside from a couple of Codecanyon items, WP Rocket is the first caching plugin to launch with a completely commercial model. Prices start at $39 for a single site ranging to $199 for unlimited sites with a year of updates and support.</p>
<h3>WP Rocket Aims to Stand Out Among Established Competitors</h3>
<p>The founding trio is banking on their top-notch support and the user-friendliness of the plugin to set them apart from those using the freemium model.</p>
<p>The plugin is now at version 2.1, following rigorous testing and improvement prior to its international launch. It currently powers performance and optimization for more than 3000 sites. When it comes to features, you&#8217;ll find your standard caching functionality makes up the backbone of the plugin:</p>
<ul>
<li>Static Cache</li>
<li>Minification and concatenation of HTML, JS  and CSS</li>
<li>Browser optimization (expired headers, gzip compression, etc.)</li>
<li>Compatibility with various server software (Apache, Nginx, Lightspeed, etc)</li>
<li>CDN integration</li>
</ul>
<p>The team at WP Rocket knew they were launching among serious, established competitors, such as <a href="https://wordpress.org/plugins/w3-total-cache/" target="_blank">W3 Total Cache</a> and <a href="https://wordpress.org/plugins/wp-super-cache/" target="_blank">WP Super Cache</a>. Jean-Baptiste Marchand-Arvier, speaking on behalf of the others, articulated their strategy in setting WP Rocket apart as a commercial plugin. &#8220;We are a bit different thanks to exclusive functionality, a complete compatibility with WPML (no other plugin is fully compatible), premium support, an automatic cache preload and constant R&amp;D for frequent updates,&#8221; he said. Three people work full-time to support the plugin, and Marchand-Arvier notes that this wouldn&#8217;t be possible if it were free.</p>
<p>WP Rocket boasts a few exclusive features for further optimization that are not common to other popular caching plugins:</p>
<ul>
<li>Lazy Loading &#8211; loads only visible images on the page, as seen in the standalone <a href="http://wordpress.org/plugins/rocket-lazy-load/" target="_blank">Rocket Lazy Load</a> plugin</li>
<li>Cache Preloading using WP Rocket servers on demand and automatically (on content creation and update).</li>
<li>DNS prefetching- (preloads DNS requests for websites added in the options)</li>
<li>Deferred JS Loading</li>
<li>Approximately 40 hooks</li>
<li>Image height and width are automatically added to avoid unnecessary browser calculations</li>
<li>A white label system to change the name and description of the plugin to remove any mention on WP Rocket</li>
<li>7/7 Support</li>
</ul>
<h3>WP Rocket was Designed with Simplicity in Mind</h3>
<p>Marchand-Arvier said the team has been pleasantly surprised by the great feedback they have received from the community and customers, despite launching without a real business plan. One common complaint about caching plugins is that they are difficult to configure, with too many confusing options. &#8220;For a novice or developer, you can be easily lost,&#8221; Marchand-Arvier said. &#8220;Users are also afraid to break their sites and not have quick access to help in case of trouble.&#8221; WP Rocket aims to solve this problem.</p>
<p>I took the plugin for a test drive to see if it lives up to their claims. The settings page is very basic and I was able to configure it for a small blogging site in under a minute. More advanced settings are available, but those are mostly for DNS prefetching and file exclusions.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket-settings.png" rel="prettyphoto[22171]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket-settings.png?resize=1025%2C939" alt="wp-rocket-settings" class="aligncenter size-full wp-image-22192" /></a></p>
<p>I performed a quick test on a small site with no caching, which originally rang in at 5.88s load time, according to <a href="http://gtmetrix.com/" target="_blank">GTmetrix</a>, with a page speed grade of E (59%) and 1.82MB total page size. With WP Rocket turned on and basic setting activated, the page load time was reduced to 2.88s with 1.00MB page size and a page speed grade B (83%). The plugin shaved three seconds off the load time, which is a fairly significant return for the one minute I spent configuring it.</p>
<p>Marchand-Arvier said that their customers have been attracted by their support, ease of use, and the all-in-one system, which allows them to replace several optimization plugins with WP Rocket. The simple setup is a refreshing change from many of the major caching plugins that require moving and editing files as well as configuring half a dozen screens full of options. But will this commercial caching plugin be able to compete against all of the free, robust options available? Thus far, it seems as though <a href="http://wp-rocket.me/" target="_blank">WP Rocket</a> customers are willing to pay for a faster and simpler solution to site optimization.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2014 23:28:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Alex King: Write locally, mirror globally";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:48:"http://pinboard-ab7979d7a6297d99db088e204013dd49";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://www.manton.org/2014/04/write_locally_mirror.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:651:"<p>I&#8217;m obviously a fan of this type of thinking. Want to have your cake and eat it too? <a href="http://crowdfavorite.com/blog/2014/01/own-your-online-identity/">Try owning your data</a> and and still mixing it up on Facebook and Twitter with our <a href="http://crowdfavorite.com/favepersonal/">free FavePersonal WordPress theme</a> (as seen on this site).</p>
<p class="threads-post-notice">This post is part of the project: <a href="http://alexking.org/project/favepersonal">FavePersonal</a>. View the project timeline for more context on this post.</p>
<p><a href="http://alexking.org/blog/2014/05/01/write-locally-mirror-globally">#</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2014 21:10:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: Pagely To Host BuddyPress Hangout With Boone Gorges";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22138";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:166:"http://wptavern.com/pagely-to-host-buddypress-hangout-with-boone-gorges?utm_source=rss&utm_medium=rss&utm_campaign=pagely-to-host-buddypress-hangout-with-boone-gorges";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1527:"<p>Managed WordPress hosting company Pagely, <a title="http://blog.pagely.com/2014/04/pagely-buddypress-hangout/" href="http://blog.pagely.com/2014/04/pagely-buddypress-hangout/">will be hosting</a> a BuddyPress hangout tomorrow at <strong>11AM Pacific, 2PM Eastern</strong>. Pagely&#8217;s CTO Josh Eichorn will be interviewing BuddyPress lead developer <a title="http://boone.gorg.es/" href="http://boone.gorg.es/">Boone Gorges</a>.</p>
<p>The pair will discuss the differences between BuddyPress 1.9 and 2.0 as well as details surrounding the major performance improvements. Pagely CEO Joshua Strebel will moderate the discussion. If you can&#8217;t make the live showing, the video will be published on the Pagely blog sometime next week.</p>
<p>Last month, Gorges was interviewed by Brad Williams and Dre Armeda <a title="http://dradcast.com/shows/episode-038-boone-hat/" href="http://dradcast.com/shows/episode-038-boone-hat/">on Dradcast</a> where he discussed the development of <a title="http://buddypress.org/2014/04/buddypress-2-0-juliana/" href="http://buddypress.org/2014/04/buddypress-2-0-juliana/">BuddyPress 2.0</a>, the <a title="http://commons.gc.cuny.edu/" href="http://commons.gc.cuny.edu/">CUNY Academic Commons project</a>, and the <a title="http://wptavern.com/buddypress-2-0-ramps-up-performance-reduces-footprint-by-up-to-75" href="http://wptavern.com/buddypress-2-0-ramps-up-performance-reduces-footprint-by-up-to-75">performance improvements in 2.0</a>.</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2014 17:12:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: WP-SCSS Plugin Adds Sass CSS Preprocessor to WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/wp-scss-plugin-adds-sass-css-preprocessor-to-wordpress-themes?utm_source=rss&utm_medium=rss&utm_campaign=wp-scss-plugin-adds-sass-css-preprocessor-to-wordpress-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3541:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/sass.png" rel="prettyphoto[22082]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/sass.png?resize=772%2C250" alt="sass" class="aligncenter size-full wp-image-22129" /></a></p>
<p>Last week we <a href="http://wptavern.com/new-plugin-adds-less-css-preprocessor-to-wordpress-themes" target="_blank">featured</a> a plugin that adds the <a href="http://lesscss.org/" target="_blank">Less</a> CSS preprocessor to WordPress themes. Several of our readers were wondering if there was a <a href="http://sass-lang.com/" target="_blank">Sass</a> equivalent to the plugin.</p>
<p>Although not structured entirely the same as the Less Theme Support plugin, which uses <a href="http://codex.wordpress.org/Function_Reference/add_theme_support" target="_blank">add_theme_support</a>, the WP-SCSS plugin provides a decent Sass counterpart.</p>
<p><a href="http://wordpress.org/plugins/wp-scss/" target="_blank">WP-SCSS</a> compiles Sass using <a href="https://github.com/leafo/scssphp" target="_blank">scssphp</a>, a compiler script written in PHP. When changes are made to the SCSS files, the plugin compiles them to the matching CSS file. If a matching CSS file doesn&#8217;t exist, the plugin will create one.</p>
<p>Paths to the SCSS and CSS files can be configured in the plugin&#8217;s settings page (defined relative to your theme folder), along with error reporting, compiling options, and auto enqueuing.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-scss-settings.png" rel="prettyphoto[22082]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-scss-settings.png?resize=1025%2C964" alt="wp-scss-settings" class="aligncenter size-full wp-image-22133" /></a></p>
<p>The best way to ensure the most accurate compiling is to have separate SCSS and CSS directories in your theme&#8217;s folder, i.e.:</p>
<p><strong>Theme Directory:</strong><br />
|-css<br />
|  &#8211;style.css<br />
|  &#8211;ie.css<br />
|-scss<br />
|  &#8211;style.scss<br />
|  &#8211;ie.scss</p>
<p>You&#8217;ll have three different modes as options for compiling when using the plugin:</p>
<ul>
<li><strong>Expanded</strong> &#8211; Full open CSS. One line per property. Brackets close on their own line.</li>
<li><strong>Nested</strong> &#8211; Lightly compressed CSS. Brackets close with CSS block. Indents to match SCSS nesting.</li>
<li><strong>Compressed</strong> &#8211; Fully compressed CSS.</li>
</ul>
<p>The auto enqueuing should be used with care, because if you ever disable the plugin your CSS files will no longer be enqueued. By default, the automatic enqueuing will enqueue all the files found in the CSS directory that you define in the plugin&#8217;s settings, including any non-compiled CSS files that you may have in play. Obviously, if you utilize the plugin&#8217;s auto enqueuing feature, you should make sure that you&#8217;re not reenqueing them somewhere else.</p>
<p>The <a href="http://wordpress.org/plugins/wp-scss/" target="_blank">WP-SCSS</a> plugin makes using Sass in your WordPress themes a more convenient possibility. It provides limited <a href="http://compass-style.org/" target="_blank">Compass</a> and/or <a href="http://bourbon.io/" target="_blank">Bourbon</a> support as well as a way to use @import subfiles. Refer to the <a href="http://wordpress.org/plugins/wp-scss/faq/" target="_blank">FAQ tab</a> on the plugin&#8217;s WordPress.org homepage for more information and troubleshooting tips.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2014 16:42:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Akismet: April Stats Roundup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1401";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://blog.akismet.com/2014/05/01/april-stats-roundup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3119:"<p>This is the first in a series of monthly posts rounding up some basic stats and figures from the prior month. Because we thought that you may like to know how we&#8217;ve been doing and also get a better perspective of spam activity across the web.</p>
<p>This was a special month, as April 12 marked the 20-year anniversary of commercialized spam, which is attributed to <a href="http://en.wikipedia.org/wiki/Laurence_Canter_and_Martha_Siegel">two US immigration lawyers</a>. Happy Birthday, I guess?</p>
<p>Akismet caught <strong>6,284,116,547</strong> pieces of spam content (comments, forum posts, contact form submissions, etc.). That&#8217;s down around 6% since last month and up around 103% over April 2013. The peak of spam activity was Tuesday April 15 (the same day that <a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/" title="Akismet 3.0 Launch Post">Akismet 3.0</a> was released, coincidentally), when our service blocked over <strong>252 million</strong> pieces of spam content. The daily breakdown goes a little something like this:</p>
<p><a href="http://akismet.files.wordpress.com/2014/05/akismet-spam-stats-april-2014-001.png"><img src="http://akismet.files.wordpress.com/2014/05/akismet-spam-stats-april-2014-001.png?w=640&h=401" alt="Akismet Spam Stats, April 2014" width="640" height="401" class="alignnone size-large wp-image-1449" /></a></p>
<p>There was a bit of an interesting lull at the end of the first week, though nothing much of note to discuss. You may have certainly noticed some corresponding trends on your own site. We experienced no downtime or service interruptions throughout the month, so any dips in the chart simply manifest lower periods of general spam activity.</p>
<p>We missed only about 1 in every 6,904 pieces of spam content (0.0145%).</p>
<p><strong>So, what does over 6 billion pieces of spam content really look like?</strong> If you assigned each piece of spam content its own seat, you could fill nearly 125,000 Yankee Stadiums.</p>
<p><strong>Some reads from the month that we recommend:</strong><br />
+ <a href="http://www.smh.com.au/digital-life/digital-life-news/happy-20th-birthday-spam-you-devil-20140429-zqyy0.html">A reluctant &#8216;happy birthday&#8217; to spam</a><br />
+ <a href="http://www.csoonline.com/article/2149570/mobile-security/bad-bots-on-the-rise-a-look-at-mobile-social-porn-and-spam-bots.html">The rise of bad bots</a><br />
+ <a href="http://money.cnn.com/2014/04/29/technology/security/aol-hack-spam/">Zombie spam!</a><br />
+ <a href="http://www.cnn.com/2014/04/09/world/americas/cuba-twitter-spam/">Is spam the latest weapon of the US government?</a><br />
+ <a href="http://metro.co.uk/2014/04/03/spam-sushi-its-a-thing-4687542/">Spam sushi is real</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1401/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1401/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1401&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2014 12:47:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: WordPress Commercial Theme Businesses Offer Advice On Hiring Support Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22072";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:212:"http://wptavern.com/wordpress-commercial-theme-businesses-offer-advice-on-hiring-support-staff?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-commercial-theme-businesses-offer-advice-on-hiring-support-staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11541:"<p>Support is one of the most difficult and expensive aspects of a business. At the same time, it&#8217;s often a determining factor on whether a company sticks around for one or several years. One thing I&#8217;ve noticed most of the established WordPress commercial theme businesses have in common is their reputation for providing good support. But how did they find the individuals to support their products? How much are they paid? How are they trained?</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/ChurchThemesLogoBig.png" rel="prettyphoto[22072]"><img class="aligncenter size-full wp-image-22120" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/ChurchThemesLogoBig.png?resize=650%2C200" alt="Big ChurchThemes Logo" /></a></p>
<p>Those questions and more were answered in a recent survey conducted by Steven Gliebe of <a title="http://churchthemes.com/" href="http://churchthemes.com/">ChurchThemes.com</a>. He reached out to several large and small commercial theme companies to determine how they built their support infrastructure. Gliebe has graciously donated the survey results to WP Tavern with the hope other commercial theme business owners will learn some valuable lessons to apply to their business.</p>
<h3>How Do You Find Applicants?</h3>
<p>Companies such as WooThemes have a <a title="http://www.woothemes.com/careers/" href="http://www.woothemes.com/careers/">dedicated page</a> highlighting new job openings while others hire from within. Cory Miller of <a title="http://www.ithemes.com" href="http://www.ithemes.com">iThemes</a> said some of their best support people started out as customers first, &#8220;<span class="pullquote alignright">The best long-term support agents / techs we&#8217;ve seen have come as customers first. They love the product and they want to help other people get better. In fact, our support team lead came as a customer first.</span>&#8221;</p>
<p><a title="http://www.studiopress.com" href="http://www.studiopress.com">StudioPress</a> has such a large community of customers and developers, they look within before advertising a job opportunity. In fact, the company has never externally <em>advertised</em> for a position to join Copyblogger’s support team.</p>
<p>Other responses included the use of job boards or hiring someone they already know through networking. The last time ThemeFuse advertised an open position, they glued a poster on the campus of one of their local universities.</p>
<div id="attachment_22117" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OfficialWordPressJobsBoard.png" rel="prettyphoto[22072]"><img class="size-full wp-image-22117" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OfficialWordPressJobsBoard.png?resize=1008%2C614" alt="Official WordPress Jobs Board" /></a><p class="wp-caption-text">Official WordPress Jobs Board</p></div>
<p>Bryan Hadaway of <a title="http://cyberchimps.com/" href="http://cyberchimps.com/">CyberChimps</a> recommends not using premium job boards as they didn&#8217;t yield better applicants than the free ones. When it comes to interviews, education means nothing to Hadaway. Instead, he&#8217;s more interested in experience and performance:</p>
<blockquote><p>Education means nothing to me, experience and performance means everything to me. It all starts with the first email. I would say 90%+ of all applicants are immediately filtered out for sending incomprehensible, all-blue-text and otherwise unprofessional emails. Presentation says a lot about someone&#8217;s attention to detail, work ethic and overall professionalism.</p></blockquote>
<h3>How Are New Hires Trained and Is There A Trial Period?</h3>
<p>A common answer amongst all of the respondents is that training is a never-ending process. Most have a trial period lasting three months while others don&#8217;t have a trial period. Those that hired a customer or looked within their product community to hire support representatives discovered they were almost fully trained.</p>
<p>Many of the respondents with a trial period explained that it&#8217;s used to determine whether the company is a good fit for the individual and vice versa. The only way to determine if an employee is a good fit within an existing culture is to work with them.</p>
<h3>Do You Hire Employees Or Work With Independent Contractors (Is An Agreement Signed)?</h3>
<p>Answers to this question varied largely due to the location of the company and the employee. For example, WooThemes is registered in South Africa and all of their staff in South Africa are paid as employees. WooThemes works with a payroll company in the US to handle payments to staff living in the US. Staff members outside of South Africa and the US are paid as independent contractors.</p>
<p>David Morgan of <a title="http://organicthemes.com/" href="http://organicthemes.com/">Organic Themes</a> has a unique approach. They have a deal where support contractors are paid at a monthly rate for a couple of hours of their time per day. In addition to the payments, they are able to accept as much customization work from the forums as they desire. Morgan said &#8220;the deal worked out so well for two individuals, they went on to create their own WordPress theme customization site, <a title="http://werkpress.com/" href="http://werkpress.com/">WerkPress</a>.&#8221;</p>
<p>CyberChimps hires employees directly but requires them to sign an NDA contract.</p>
<h3>How Much Are Support Staff Paid?</h3>
<p>The average range from the responses is between $10-$35/hour. The amount of pay appears to be highly influenced by the location of the employee. $20 to $30/hour seems typical for a Western Hemisphere. Those with more experience and responsibilities or in locations with an especially high cost of living may see $35/hour. The range for support staff in developing countries due to the lower cost of living might range from $10 to $20/hour.</p>
<p>iThemes didn&#8217;t provide an amount but responded they don&#8217;t pay their support staff enough.</p>
<p>WooThemes uses a slight variation of the <a title="http://open.bufferapp.com/introducing-open-salaries-at-buffer-including-our-transparent-formula-and-all-individual-salaries/" href="http://open.bufferapp.com/introducing-open-salaries-at-buffer-including-our-transparent-formula-and-all-individual-salaries/">Open Salaries formula for location</a> by Buffer to determine pay rates.</p>
<h3>Advice On Hiring Support Staff</h3>
<p>Hire slowly. WooThemes hired too quickly and discovered that many were not fit for the support role after a few months. Conduct several interviews and chats with the individual to make sure you are hiring a person that is committed.</p>
<p>Say thank you as often as you can to your support team. They are the front line of your products, even more so than the actual developers. Miller hires for passion and commitment to the customer, the product, and their mission. For retaining good support people, Miller says &#8220;ensuring they feel appreciated and listened to is the absolute key.&#8221; Saying thank you goes a very long way.</p>
<div id="attachment_22121" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/SayThankYou.png" rel="prettyphoto[22072]"><img class="size-full wp-image-22121" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/SayThankYou.png?resize=637%2C247" alt="Just Say Thank You" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/nateone/3768979925/">nateOne</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a></p></div>
<p>Kim Clark, VP of Customer Experience at CopyBlogger Media says to &#8220;follow your gut and trust your instincts.&#8221; While part of the equation is to find people with the required skills, the other is determining whether their personality matches with the company culture. As an example, if you provide a flexible hours environment and you find that the person you interview is asking about a rigid schedule, you will find yourself constantly answering questions about how they should structure their time.</p>
<p>Seek out individuals that are long time customers or who have reached out to you in the past. According to Morgan, &#8220;those individuals will likely be loyal to your brand, and often become more than contractors, but friends as well.&#8221; WordCamps are an excellent place to find candidates to become members of your support staff. Morgan believes, &#8220;one fantastic support member is worth more than several mediocre support members.&#8221;</p>
<p>Since the support staff are usually the first people a customer will speak with in your company, make sure they are as passionate and enthusiastic as you are. David Perel of <a title="http://oboxthemes.com/" href="http://oboxthemes.com/">Obox Themes</a> says, &#8220;support staff need a huge amount of patience and they need to be comfortable interacting with people from all walks of life.&#8221;</p>
<p>You&#8217;ll never know if an applicant is right for the job until you put them into the field and stress test them. Hadaway says to &#8220;care about and nurture the fact that those who make the cut have a say and their ideas matter.&#8221; Hadaway believes that &#8220;besides just caring for their team at the human-level and wanting everyone to achieve success, it&#8217;s just better for CyberChimps in the purely business sense to have happy workers.&#8221;</p>
<h3>The Benefits Of Keeping Support In-house</h3>
<p>Drew Stojny of <a title="https://thethemefoundry.com/" href="https://thethemefoundry.com/">The Theme Foundry</a> and Chris Wallace of <a title="https://upthemes.com/" href="https://upthemes.com/">UpThemes</a> have an approach to hiring and providing support that were different enough from the other responses to warrant their own section. Both companies keep support in-house where each member of their team contributes to the support load. Strojny outlines some of the benefits of providing support in this manner.</p>
<ul>
<li>Customers get first class service from the team that built their theme.</li>
<li>We get a first hand look at customer problems and can react quickly with bug fixes and improvements.</li>
<li>We get valuable insight into what our customers want, which helps us when designing new themes</li>
</ul>
<p>UpThemes does support in this manner to prevent the burden from falling onto one or a few individuals. They&#8217;ve recently hired a customer support advocate to keep a pulse on the needs of their customers. This will help them prioritize pain points and to build better products. By having the entire work force contributing to support, it helps them learn how customers are using their products in detailed fashion.</p>
<h3>Support Can Make or Break A Company</h3>
<p>The results from the survey prove just how important a good support infrastructure is. Support can make or break a company as we saw with the <a title="https://upthemes.com/open-letter/" href="https://upthemes.com/open-letter/">open letter by UpThemes</a>. It&#8217;s one of the most important aspects of a business and is imperative to its long-term success. There are so many companies providing terrible customer service, customers excitedly share their experience when they are treated right. Whether it&#8217;s a theme, plugin, or service, a business should be striving to provide the most satisfying customer service possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2014 01:09:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: Rocket Galleries: An Intuitive Gallery Manager for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22052";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/rocket-galleries-an-intuitive-gallery-manager-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=rocket-galleries-an-intuitive-gallery-manager-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4757:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/rocket-galleries.jpg" rel="prettyphoto[22052]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/rocket-galleries.jpg?resize=772%2C250" alt="rocket-galleries" class="aligncenter size-full wp-image-22054" /></a></p>
<p>Rocket Galleries is a new gallery plugin that claims to be &#8220;the gallery manager WordPress never had.&#8221; Ordinarily, gallery plugins are a dime a dozen and most of them insert themselves into WordPress with awkward interfaces that promote the plugin author. However, this one is different.</p>
<p><a href="http://wordpress.org/plugins/rocket-galleries/" target="_blank">Rocket Galleries</a> was built to feel like native WordPress functionality, not a plugin. Matthew Ruddy, the plugin author, said that he created it as an alternative to other popular gallery plugins. &#8220;I built it to alleviate problems I was having when showing clients how to use NextGen gallery,&#8221; he said. <strong>&#8220;For a majority of what my clients required, it was too complicated &#8211; which prompted me to build something simpler.&#8221;</strong></p>
<p>The gallery management panel looks like a natural part of WordPress:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/gallery-panel.jpg" rel="prettyphoto[22052]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/gallery-panel.jpg?resize=1025%2C628" alt="gallery-panel" class="aligncenter size-full wp-image-22092" /></a></p>
<p>Rocket Galleries features all the basics for a gallery that uses the WordPress media library:</p>
<ul>
<li>Lightweight, with no Javascript needed and minimal CSS at less than 0.3kb!</li>
<li>Bulk image uploading, integrated with new WordPress Media Library</li>
<li>A built-in template loader, allowing you to create your own gallery templates for your theme</li>
<li>Developer friendly, with huge scope for customization using built-in actions and filters</li>
<li>Ability to easily duplicate galleries</li>
<li>Option to load scripts in the page header or footer</li>
</ul>
<p>Creating new galleries and adding images to exiting galleries is a very straightforward process for anyone who knows how to add images to the WordPress media library.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/create-gallery.jpg" rel="prettyphoto[22052]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/create-gallery.jpg?resize=1003%2C494" alt="create-gallery" class="aligncenter size-full wp-image-22096" /></a></p>
<p>Galleries can be inserted from a modal window in the post/page editor or via a shortcode:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/insert-gallery.jpg" rel="prettyphoto[22052]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/insert-gallery.jpg?resize=1025%2C541" alt="insert-gallery" class="aligncenter size-full wp-image-22099" /></a></p>
<p>Gallery images are displayed in a nice block of thumbnails on the frontend:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/gallery-frontend.jpg" rel="prettyphoto[22052]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/gallery-frontend.jpg?resize=1025%2C706" alt="gallery-frontend" class="aligncenter size-full wp-image-22100" /></a></p>
<h3>More Functionality to Come in the Form of Extensions</h3>
<p>Ruddy built the plugin to be developer friendly with lots of actions and filters, so there are many possibilities for extending it. Themes can customize the display via the plugin&#8217;s template loader, a method used by many popular plugins to give users the ability to add their own templates.</p>
<p>Currently, images in the gallery link to the attachment page, rather than a lightbox. Ruddy said that he intends to release a lightbox extension, among others, once the plugin has received some downloads to demonstrate that people are actually using it. He plans to keep the Rocket Galleries plugin light and clutter-free and add functionality in the form of extensions, similar to the way that plugins like Easy Digital Downloads offer an array of additional add-ons.</p>
<p>I tested Rocket Galleries and found it to be the simplest WordPress gallery manager plugin that I&#8217;ve ever used. It truly feels like a natural part of WordPress and, as such, has the potential to gain a strong following. You can <a href="http://wordpress.org/plugins/rocket-galleries/" target="_blank">download the plugin</a> from the WordPress Plugin Directory. If you like how nicely it integrates with WordPress, make sure to leave a good review and let the author know that you are using it. User feedback will be the basis for future extensions.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 30 Apr 2014 21:11:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: WordPress 4.0 Kicks Off Development Today, Helen Hou-Sandí to Lead Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21988";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:210:"http://wptavern.com/wordpress-4-0-kicks-off-development-today-helen-hou-sandi-to-lead-release?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-4-0-kicks-off-development-today-helen-hou-sandi-to-lead-release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3440:"<p>Andrew Nacin <a href="http://make.wordpress.org/core/2014/04/30/helen-is-the-wordpress-4-0-release-lead/" target="_blank">announced</a> today that <a href="http://profiles.wordpress.org/helen" target="_blank">Helen Hou-Sandí</a> will be the release lead for WordPress 4.0, which kicks off development today during the regularly scheduled meeting in the #wordpress-dev IRC channel. Two guest committers, Dominik Schilling (<a href="http://profiles.wordpress.org/ocean90" target="_blank">@ocean90</a>) and Sergey Biryukov (<a href="http://profiles.wordpress.org/SergeyBiryukov" target="_blank">@SergeyBiryukov</a>) have both been granted permanent commit access.</p>
<p>An important development meeting was held yesterday, where Samuel Sidler<a href="http://make.wordpress.org/core/2014/04/28/feature-plugin-chat-tomorrow/" target="_blank"> put out a roll call</a> for feature plugins currently in the works, some of which may be considered for the 4.0 release. Feature plugin team leaders submitted overviews of their plugin proposals, teams and current development status. While some of the plugins are still in the idea and planning stage, there are a few that may be ready in time to coincide with the next major release.</p>
<h3>JSON REST API Plugin</h3>
<p>The <a href="https://github.com/WP-API/WP-API" target="_blank">JSON REST API plugin</a> is targeting 4.0 for inclusion in WordPress. Rachel Baker, representing the plugin at the meeting, reported that there are just a couple of development-related items: removal of basic auth, in favor of Oauth, and addition of meta handling. Many developers are looking forward to this API being added to core, as it will greatly expand WordPress&#8217; capabilities for being used as an application framework.</p>
<h3>Media Grid Project</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/media-grid.png" rel="prettyphoto[21988]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/media-grid.png?resize=772%2C250" alt="media-grid" class="aligncenter size-full wp-image-22074" /></a></p>
<p>A small group of contributors is currently working on a Media Grid project, originally proposed during the 3.7/3.8 development cycle. Shaun Andrews is looking to form a focused team to work together on preparing it for an upcoming release. &#8220;I think we could have something ready for 4.0, but 4.1 is a possibility as well,&#8221; he said in a recent <a href="https://make.wordpress.org/core/2014/04/22/remember-the-media-grid-project-it-was-original/" target="_blank">update</a>. &#8220;I’m looking for any-and-all help, but specifically 1-2 backbone-capable developers with familiarity with the Media Modal would be a huge help.&#8221; Development for the Media Grid project is currently happening on <a href="https://github.com/helenhousandi/wp-media-grid-view" target="_blank">Github</a>, with a corresponding <a href="http://wordpress.org/plugins/media-grid/" target="_blank">plugin</a> in the directory.</p>
<p>Other notable <a href="http://make.wordpress.org/core/2014/04/28/feature-plugin-chat-tomorrow/" target="_blank">projects currently in the idea and planning stages</a> include the Admin Help initiative focused on making the admin easier, and the possibility of redesigning and overhauling the &#8220;Press This&#8221; feature. Both are not likely to be ready for 4.0 but have teams currently active in researching future improvements.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 30 Apr 2014 18:35:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 09 May 2014 04:39:28 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"185020";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Fri, 09 May 2014 04:15:13 GMT";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (428, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1399653569', 'no') ; 
INSERT INTO `wp_options` VALUES (429, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1399610369', 'no') ; 
INSERT INTO `wp_options` VALUES (430, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1399653569', 'no') ; 
INSERT INTO `wp_options` VALUES (431, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 May 2014 04:17:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 9 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-Optimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/wp-optimize/#post-8691";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 21 Jan 2009 04:28:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8691@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Simple but effective plugin allows you to extensively clean up your WordPress database and optimize it without doing manual queries.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"ruhanirabin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 09 May 2014 04:39:29 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Fri, 09 May 2014 04:52:51 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Fri, 09 May 2014 04:17:51 +0000";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (432, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1399653569', 'no') ; 
INSERT INTO `wp_options` VALUES (433, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1399610369', 'no') ; 
INSERT INTO `wp_options` VALUES (434, '_transient_timeout_plugin_slugs', '1399733848', 'no') ; 
INSERT INTO `wp_options` VALUES (435, '_transient_plugin_slugs', 'a:6:{i:0;s:19:"akismet/akismet.php";i:1;s:36:"awesome-filterable-portfolio/afp.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:24:"wordpress-seo/wp-seo.php";i:5;s:27:"wp-filebase/wp-filebase.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (436, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1399653569', 'no') ; 
INSERT INTO `wp_options` VALUES (437, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/05/wordpress-3-9-1/\'>WordPress 3.9.1 Maintenance Release</a> <span class="rss-date">May 8, 2014</span><div class="rssSummary">After three weeks and more than 9 million downloads of WordPress 3.9, we’re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We’ve also made some improvements to the new audio/vi</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/help-test-the-buddypress-attachments-plugin?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=help-test-the-buddypress-attachments-plugin\' title=\'After shipping BuddyPress 2.0, the plugin’s core contributors decided to adopt WordPress’ features-as-plugins development model for working on the possibility of a new media component. Mathieu Viet, better known as @imath, has been working on an Attachments API that will allow BuddyPress to store media as attachments. Plugin developers will also be able to m\'>WPTavern: Help Test the BuddyPress Attachments Plugin</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordpress-contributors-move-toward-automating-accessibility-testing?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordpress-contributors-move-toward-automating-accessibility-testing\' title=\'Accessibility is one of those areas of WordPress contribution that hardly ever ends up in the spotlight. Much of the work that goes on in this area is invisible to the vast majority of users. Accessibility experts are generally in shorter supply than other types of contributors as well. Why aren’t more people involved in this important aspect of the web? Dav\'>WPTavern: WordPress Contributors Move Toward Automating Accessibility Testing</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/05/08/john-james-jacoby-wordpresss-role-based-access-control-wprbacomgbbq/\' title=\'\'>WordPress.tv: John James Jacoby: WordPress’s Role Based Access Control – WPRBACOMGBBQ</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/woocommerce/\' class=\'dashboard-news-plugin-link\'>WooCommerce - excelling eCommerce</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=woocommerce&amp;_wpnonce=27c70bc703&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WooCommerce - excelling eCommerce\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (457, 'wpfilebase', 'a:84:{s:11:"upload_path";s:27:"wp-content/uploads/filebase";s:14:"thumbnail_size";i:120;s:14:"thumbnail_path";s:0:"";s:15:"base_auto_thumb";b:1;s:14:"fext_blacklist";s:6:"db,tmp";s:10:"attach_pos";i:1;s:11:"attach_loop";b:0;s:17:"auto_attach_files";b:1;s:16:"filelist_sorting";s:17:"file_display_name";s:20:"filelist_sorting_dir";i:0;s:12:"filelist_num";i:0;s:16:"file_date_format";s:6:"F j, Y";s:20:"bitrate_unregistered";i:0;s:18:"bitrate_registered";i:0;s:11:"traffic_day";i:0;s:13:"traffic_month";i:0;s:20:"traffic_exceeded_msg";s:47:"Traffic limit exceeded! Please try again later.";s:16:"file_offline_msg";s:31:"This file is currently offline.";s:17:"daily_user_limits";b:0;s:22:"daily_limit_subscriber";i:5;s:23:"daily_limit_contributor";i:10;s:18:"daily_limit_author";i:15;s:18:"daily_limit_editor";i:20;s:24:"daily_limit_exceeded_msg";s:39:"You can only download %d files per day.";s:18:"disable_permalinks";b:0;s:13:"download_base";s:8:"download";s:20:"file_browser_post_id";s:0:"";s:24:"file_browser_cat_sort_by";s:8:"cat_name";s:25:"file_browser_cat_sort_dir";i:0;s:25:"file_browser_file_sort_by";s:17:"file_display_name";s:26:"file_browser_file_sort_dir";i:0;s:16:"file_browser_fbc";b:0;s:11:"folder_icon";s:60:"/plugins/wp-filebase/images/folder-icons/folder_orange48.png";s:15:"small_icon_size";i:32;s:13:"cat_drop_down";b:0;s:14:"force_download";b:0;s:14:"range_download";b:1;s:10:"hide_links";b:0;s:16:"ignore_admin_dls";b:1;s:17:"hide_inaccessible";b:1;s:16:"inaccessible_msg";s:40:"You are not allowed to access this file!";s:21:"inaccessible_redirect";b:0;s:20:"cat_inaccessible_msg";s:26:"Access to category denied!";s:18:"login_redirect_src";b:0;s:12:"http_nocache";b:0;s:14:"parse_tags_rss";b:1;s:23:"allow_srv_script_upload";b:0;s:19:"protect_upload_path";b:1;s:13:"private_files";b:0;s:15:"frontend_upload";b:0;s:21:"accept_empty_referers";b:0;s:16:"allowed_referers";s:0:"";s:13:"use_fpassthru";b:0;s:19:"decimal_size_format";b:0;s:9:"admin_bar";b:1;s:9:"cron_sync";b:0;s:20:"remove_missing_files";b:0;s:18:"search_integration";b:1;s:17:"search_result_tpl";s:7:"default";s:11:"disable_id3";b:0;s:10:"search_id3";b:1;s:13:"use_path_tags";b:0;s:18:"no_name_formatting";b:0;s:8:"fake_md5";b:0;s:22:"disable_footer_credits";b:1;s:20:"footer_credits_style";s:58:"margin:0 auto 2px auto; text-align:center; font-size:11px;";s:19:"late_script_loading";b:0;s:14:"default_author";s:0:"";s:13:"default_roles";a:0:{}s:11:"default_cat";i:0;s:9:"languages";s:21:"English|en
Deutsch|de";s:9:"platforms";s:55:"Windows 7|win7
*Windows 8|win8
Linux|linux
Mac OS X|mac";s:8:"licenses";s:197:"*Freeware|free
Shareware|share
GNU General Public License|gpl|http://www.gnu.org/copyleft/gpl.html
CC Attribution-NonCommercial-ShareAlike|ccbyncsa|http://creativecommons.org/licenses/by-nc-sa/3.0/";s:12:"requirements";s:345:"PDF Reader|pdfread|http://www.foxitsoftware.com/pdf/reader/addons.php
Java|java|http://www.java.com/download/
Flash|flash|http://get.adobe.com/flashplayer/
Open Office|ooffice|http://www.openoffice.org/download/index.html
.NET Framework 3.5|.net35|http://www.microsoft.com/downloads/details.aspx?FamilyID=333325fd-ae52-4e35-b531-508d977d32a6";s:22:"default_direct_linking";i:1;s:13:"custom_fields";s:25:"Custom 1|cf1
Custom 2|cf2";s:13:"template_file";s:1945:"<div class="wpfilebase-file-default" onclick="if(\'undefined\' == typeof event.target.href) document.getElementById(\'wpfb-file-link-%uid%\').click();">
  <div class="icon"><a href="%file_url%" target="_blank" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" alt="%file_display_name%" /></a></div>
  <div class="filetitle">
    <a href="%file_url%" title="Download %file_display_name%" target="_blank" id="wpfb-file-link-%uid%">%file_display_name%</a>
    <!-- IF %file_post_id% AND %post_id% != %file_post_id% --><a href="%file_post_url%" class="postlink">&raquo; %\'Post\'%</a><!-- ENDIF -->
    <br />
    %file_name%<br />
    <!-- IF %file_version% -->%\'Version:\'% %file_version%<br /><!-- ENDIF -->
  </div>
  <div class="info">
    %file_size%<br />
    %file_hits% %\'Downloads\'%<br />
    <a href="#" onclick="return wpfilebase_filedetails(%uid%);">%\'Details\'%</a>
  </div>
  <div class="details" id="wpfilebase-filedetails%uid%" style="display: none;">
  <!-- IF %file_description% --><p>%file_description%</p><!-- ENDIF -->
  <table border="0">
   <!-- IF %file_languages% --><tr><td><strong>%\'Languages\'%:</strong></td><td>%file_languages%</td></tr><!-- ENDIF -->
   <!-- IF %file_author% --><tr><td><strong>%\'Author\'%:</strong></td><td>%file_author%</td></tr><!-- ENDIF -->
   <!-- IF %file_platforms% --><tr><td><strong>%\'Platforms\'%:</strong></td><td>%file_platforms%</td></tr><!-- ENDIF -->
   <!-- IF %file_requirements% --><tr><td><strong>%\'Requirements\'%:</strong></td><td>%file_requirements%</td></tr><!-- ENDIF -->
   <!-- IF %file_category% --><tr><td><strong>%\'Category:\'%</strong></td><td>%file_category%</td></tr><!-- ENDIF -->
   <!-- IF %file_license% --><tr><td><strong>%\'License\'%:</strong></td><td>%file_license%</td></tr><!-- ENDIF -->
   <tr><td><strong>%\'Date\'%:</strong></td><td>%file_date%</td></tr>
  </table>
  </div>
 <div style="clear: both;"></div>
</div>";s:12:"template_cat";s:308:"<div class="wpfilebase-cat-default">
  <h3>
    <!-- IF %cat_has_icon% || true -->%cat_small_icon%<!-- ENDIF -->
    <a href="%cat_url%" title="Go to category %cat_name%">%cat_name%</a>
    <span>%cat_num_files% <!-- IF %cat_num_files% == 1 -->file<!-- ELSE -->files<!-- ENDIF --></span>
  </h3>
</div>";s:10:"dlclick_js";s:317:"if(typeof pageTracker == \'object\') {
	pageTracker._trackPageview(file_url); // new google analytics tracker
} else if(typeof urchinTracker == \'function\') {	
	urchinTracker(file_url); // old google analytics tracker
} else if(typeof ga == \'function\') {
	ga(\'send\', \'pageview\', file_url); // universal analytics
}";s:6:"widget";a:0:{}s:7:"version";s:8:"0.3.0.06";s:7:"tag_ver";i:2;s:20:"template_file_parsed";s:2751:"\'<div class="wpfilebase-file-default" onclick="if(\\\'undefined\\\' == typeof event.target.href) document.getElementById(\\\'wpfb-file-link-\'.$f->get_tpl_var(\'uid\').\'\\\').click();">
  <div class="icon"><a href="\'.$f->get_tpl_var(\'file_url\').\'" target="_blank" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'"><img align="middle" src="\'.$f->get_tpl_var(\'file_icon_url\').\'" alt="\'.$f->get_tpl_var(\'file_display_name\').\'" /></a></div>
  <div class="filetitle">
    <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'" target="_blank" id="wpfb-file-link-\'.$f->get_tpl_var(\'uid\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a>
    \'.((($f->get_tpl_var(\'file_post_id\')) && get_the_ID() != ($f->get_tpl_var(\'file_post_id\')))?(\'<a href="\'.$f->get_tpl_var(\'file_post_url\').\'" class="postlink">&raquo; \'.__(__(\'Post\', WPFB)).\'</a>\'):(\'\')).\'
    <br />
    \'.$f->get_tpl_var(\'file_name\').\'<br />
    \'.((($f->get_tpl_var(\'file_version\')))?(\'\'.__(__(\'Version:\', WPFB)).\' \'.$f->get_tpl_var(\'file_version\').\'<br />\'):(\'\')).\'
  </div>
  <div class="info">
    \'.$f->get_tpl_var(\'file_size\').\'<br />
    \'.$f->get_tpl_var(\'file_hits\').\' \'.__(__(\'Downloads\', WPFB)).\'<br />
    <a href="#" onclick="return wpfilebase_filedetails(\'.$f->get_tpl_var(\'uid\').\');">\'.__(__(\'Details\', WPFB)).\'</a>
  </div>
  <div class="details" id="wpfilebase-filedetails\'.$f->get_tpl_var(\'uid\').\'" style="display: none;">
  \'.((($f->get_tpl_var(\'file_description\')))?(\'<p>\'.$f->get_tpl_var(\'file_description\').\'</p>\'):(\'\')).\'
  <table border="0">
   \'.((($f->get_tpl_var(\'file_languages\')))?(\'<tr><td><strong>\'.__(__(\'Languages\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_languages\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_author\')))?(\'<tr><td><strong>\'.__(__(\'Author\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_author\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_platforms\')))?(\'<tr><td><strong>\'.__(__(\'Platforms\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_platforms\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_requirements\')))?(\'<tr><td><strong>\'.__(__(\'Requirements\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_requirements\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_category\')))?(\'<tr><td><strong>\'.__(__(\'Category:\', WPFB)).\'</strong></td><td>\'.$f->get_tpl_var(\'file_category\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_license\')))?(\'<tr><td><strong>\'.__(__(\'License\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_license\').\'</td></tr>\'):(\'\')).\'
   <tr><td><strong>\'.__(__(\'Date\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_date\').\'</td></tr>
  </table>
  </div>
 <div style="clear: both;"></div>
</div>\'";s:19:"template_cat_parsed";s:424:"\'<div class="wpfilebase-cat-default">
  <h3>
    \'.((($f->get_tpl_var(\'cat_has_icon\')) || true)?(\'\'.$f->get_tpl_var(\'cat_small_icon\').\'\'):(\'\')).\'
    <a href="\'.$f->get_tpl_var(\'cat_url\').\'" title="Go to category \'.$f->get_tpl_var(\'cat_name\').\'">\'.$f->get_tpl_var(\'cat_name\').\'</a>
    <span>\'.$f->get_tpl_var(\'cat_num_files\').\' \'.((($f->get_tpl_var(\'cat_num_files\')) == 1)?(\'file\'):(\'files\')).\'</span>
  </h3>
</div>\'";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (458, 'wpfilebase_ftags', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (459, 'wpfb_css', 'http://localhost:8888/wp-content/plugins/wp-filebase/wp-filebase.css', 'yes') ; 
INSERT INTO `wp_options` VALUES (460, 'wpfilebase_tpls_file', 'a:9:{s:11:"filebrowser";s:113:"%file_small_icon% <a href="%file_url%" title="Download %file_display_name%">%file_display_name%</a> (%file_size%)";s:15:"download-button";s:199:"<div style="text-align:center; width:250px; margin: auto; font-size:smaller;"><a href="%file_url%" class="wpfb-dlbtn"><div></div></a>
%file_display_name% (%file_size%, %file_hits% downloads)
</div>";s:9:"image_320";s:284:"[caption id="file_%file_id%" align="alignnone" width="320" caption="<!-- IF %file_description% -->%file_description%<!-- ELSE -->%file_display_name%<!-- ENDIF -->"]<img class="size-full" title="%file_display_name%" src="%file_url%" alt="%file_display_name%" width="320" />[/caption]

";s:9:"thumbnail";s:146:"<div class="wpfilebase-fileicon"><a href="%file_url%" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" /></a></div>
";s:6:"simple";s:175:"<p><img src="%file_icon_url%" style="height:20px;vertical-align:middle;" /> <a href="%file_url%" title="Download %file_display_name%">%file_display_name%</a> (%file_size%)</p>";s:9:"3-col-row";s:102:"<tr><td><a href="%file_url%">%file_display_name%</a></td><td>%file_size%</td><td>%file_hits%</td></tr>";s:3:"mp3";s:845:"<div class="wpfilebase-attachment">
 <div class="wpfilebase-fileicon"><a href="%file_url%" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" alt="%file_display_name%" height="80"/></a></div>
 <div class="wpfilebase-rightcol">
  <div class="wpfilebase-filetitle">
   <a href="%file_url%" title="Download %file_display_name%">%file_info/tags/id3v2/title%</a><br />
%file_info/tags/id3v2/artist%<br />
%file_info/tags/id3v2/album%<br />
   <!-- IF %file_post_id% AND %post_id% != %file_post_id% --><a href="%file_post_url%" class="wpfilebase-postlink">%\'View post\'%</a><!-- ENDIF -->
  </div>
 </div>
 <div class="wpfilebase-fileinfo">
  %file_info/playtime_string%<br />
  %file_info/bitrate%<br />
  %file_size%<br />
  %file_hits% %\'Downloads\'%<br />
 </div>
 <div style="clear: both;"></div>
</div>";s:10:"flv-player";s:894:"<!-- the player only works when permalinks are enabled!!! -->
 <object width=\'%file_info/video/resolution_x%\' height=\'%file_info/video/resolution_y%\' id=\'flvPlayer%uid%\'>
  <param name=\'allowFullScreen\' value=\'true\'>
   <param name=\'allowScriptAccess\' value=\'always\'> 
  <param name=\'movie\' value=\'%wpfb_url%extras/flvplayer/OSplayer.swf?movie=%file_url_encoded%&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=%file_display_name%&showTitle=yes\'>
  <embed src=\'%wpfb_url%extras/flvplayer/OSplayer.swf?movie=%file_url_encoded%&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=%file_display_name%&showTitle=yes\' width=\'%file_info/video/resolution_x%\' height=\'%file_info/video/resolution_y%\' allowFullScreen=\'true\' type=\'application/x-shockwave-flash\' allowScriptAccess=\'always\'>
 </object>";s:10:"data-table";s:102:"<tr><td><a href="%file_url%">%file_display_name%</a></td><td>%file_size%</td><td>%file_hits%</td></tr>";}', 'no') ; 
INSERT INTO `wp_options` VALUES (461, 'wpfilebase_tpls_cat', 'a:3:{s:11:"filebrowser";s:75:"%cat_small_icon% <a href="%cat_url%" onclick="return false;">%cat_name%</a>";s:9:"3-col-row";s:82:"<tr><td colspan="3" style="text-align:center;font-size:120%;">%cat_name%</td></tr>";s:10:"data-table";s:61:"<!-- EMPTY: categories should not be listed in DataTables -->";}', 'no') ; 
INSERT INTO `wp_options` VALUES (462, 'wpfilebase_ptpls_file', 'a:9:{s:11:"filebrowser";s:220:"\'\'.$f->get_tpl_var(\'file_small_icon\').\' <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a> (\'.$f->get_tpl_var(\'file_size\').\')\'";s:15:"download-button";s:285:"\'<div style="text-align:center; width:250px; margin: auto; font-size:smaller;"><a href="\'.$f->get_tpl_var(\'file_url\').\'" class="wpfb-dlbtn"><div></div></a>
\'.$f->get_tpl_var(\'file_display_name\').\' (\'.$f->get_tpl_var(\'file_size\').\', \'.$f->get_tpl_var(\'file_hits\').\' downloads)
</div>\'";s:9:"image_320";s:410:"\'[caption id="file_\'.$f->get_tpl_var(\'file_id\').\'" align="alignnone" width="320" caption="\'.((($f->get_tpl_var(\'file_description\')))?(\'\'.$f->get_tpl_var(\'file_description\').\'\'):(\'\'.$f->get_tpl_var(\'file_display_name\').\'\')).\'"]<img class="size-full" title="\'.$f->get_tpl_var(\'file_display_name\').\'" src="\'.$f->get_tpl_var(\'file_url\').\'" alt="\'.$f->get_tpl_var(\'file_display_name\').\'" width="320" />[/caption]

\'";s:9:"thumbnail";s:211:"\'<div class="wpfilebase-fileicon"><a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'"><img align="middle" src="\'.$f->get_tpl_var(\'file_icon_url\').\'" /></a></div>
\'";s:6:"simple";s:282:"\'<p><img src="\'.$f->get_tpl_var(\'file_icon_url\').\'" style="height:20px;vertical-align:middle;" /> <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a> (\'.$f->get_tpl_var(\'file_size\').\')</p>\'";s:9:"3-col-row";s:188:"\'<tr><td><a href="\'.$f->get_tpl_var(\'file_url\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a></td><td>\'.$f->get_tpl_var(\'file_size\').\'</td><td>\'.$f->get_tpl_var(\'file_hits\').\'</td></tr>\'";s:3:"mp3";s:1205:"\'<div class="wpfilebase-attachment">
 <div class="wpfilebase-fileicon"><a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'"><img align="middle" src="\'.$f->get_tpl_var(\'file_icon_url\').\'" alt="\'.$f->get_tpl_var(\'file_display_name\').\'" height="80"/></a></div>
 <div class="wpfilebase-rightcol">
  <div class="wpfilebase-filetitle">
   <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'">\'.$f->get_tpl_var(\'file_info/tags/id3v2/title\').\'</a><br />
\'.$f->get_tpl_var(\'file_info/tags/id3v2/artist\').\'<br />
\'.$f->get_tpl_var(\'file_info/tags/id3v2/album\').\'<br />
   \'.((($f->get_tpl_var(\'file_post_id\')) && get_the_ID() != ($f->get_tpl_var(\'file_post_id\')))?(\'<a href="\'.$f->get_tpl_var(\'file_post_url\').\'" class="wpfilebase-postlink">\'.__(__(\'View post\', WPFB)).\'</a>\'):(\'\')).\'
  </div>
 </div>
 <div class="wpfilebase-fileinfo">
  \'.$f->get_tpl_var(\'file_info/playtime_string\').\'<br />
  \'.$f->get_tpl_var(\'file_info/bitrate\').\'<br />
  \'.$f->get_tpl_var(\'file_size\').\'<br />
  \'.$f->get_tpl_var(\'file_hits\').\' \'.__(__(\'Downloads\', WPFB)).\'<br />
 </div>
 <div style="clear: both;"></div>
</div>\'";s:10:"flv-player";s:1137:"\'<!-- the player only works when permalinks are enabled!!! -->
 <object width=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_x\').\'\\\' height=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_y\').\'\\\' id=\\\'flvPlayer\'.$f->get_tpl_var(\'uid\').\'\\\'>
  <param name=\\\'allowFullScreen\\\' value=\\\'true\\\'>
   <param name=\\\'allowScriptAccess\\\' value=\\\'always\\\'> 
  <param name=\\\'movie\\\' value=\\\'\'.(WPFB_PLUGIN_URI).\'extras/flvplayer/OSplayer.swf?movie=\'.$f->get_tpl_var(\'file_url_encoded\').\'&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=\'.$f->get_tpl_var(\'file_display_name\').\'&showTitle=yes\\\'>
  <embed src=\\\'\'.(WPFB_PLUGIN_URI).\'extras/flvplayer/OSplayer.swf?movie=\'.$f->get_tpl_var(\'file_url_encoded\').\'&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=\'.$f->get_tpl_var(\'file_display_name\').\'&showTitle=yes\\\' width=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_x\').\'\\\' height=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_y\').\'\\\' allowFullScreen=\\\'true\\\' type=\\\'application/x-shockwave-flash\\\' allowScriptAccess=\\\'always\\\'>
 </object>\'";s:10:"data-table";s:188:"\'<tr><td><a href="\'.$f->get_tpl_var(\'file_url\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a></td><td>\'.$f->get_tpl_var(\'file_size\').\'</td><td>\'.$f->get_tpl_var(\'file_hits\').\'</td></tr>\'";}', 'no') ; 
INSERT INTO `wp_options` VALUES (463, 'wpfilebase_ptpls_cat', 'a:3:{s:11:"filebrowser";s:140:"\'\'.$f->get_tpl_var(\'cat_small_icon\').\' <a href="\'.$f->get_tpl_var(\'cat_url\').\'" onclick="return false;">\'.$f->get_tpl_var(\'cat_name\').\'</a>\'";s:9:"3-col-row";s:105:"\'<tr><td colspan="3" style="text-align:center;font-size:120%;">\'.$f->get_tpl_var(\'cat_name\').\'</td></tr>\'";s:10:"data-table";s:63:"\'<!-- EMPTY: categories should not be listed in DataTables -->\'";}', 'no') ; 
INSERT INTO `wp_options` VALUES (464, 'wpfilebase_list_tpls', 'a:4:{s:7:"default";a:4:{s:6:"header";s:0:"";s:6:"footer";s:0:"";s:12:"file_tpl_tag";s:7:"default";s:11:"cat_tpl_tag";s:7:"default";}s:5:"table";a:4:{s:6:"header";s:453:"%search_form%
<table>
<thead>
	<tr><th scope="col"><a href="%sortlink:file_name%">Name</a></th><th scope="col"><a href="%sortlink:file_size%">Size</a></th><th scope="col"><a href="%sortlink:file_hits%">Hits</a></th></tr>
</thead>
<tfoot>
	<tr><th scope="col"><a href="%sortlink:file_name%">Name</a></th><th scope="col"><a href="%sortlink:file_size%">Size</a></th><th scope="col"><a href="%sortlink:file_hits%">Hits</a></th></tr>
</tfoot>
<tbody>";s:6:"footer";s:64:"</tbody>
</table>
<div class="tablenav-pages">%page_nav%</div>";s:12:"file_tpl_tag";s:9:"3-col-row";s:11:"cat_tpl_tag";s:9:"3-col-row";}s:8:"mp3-list";a:4:{s:6:"header";s:0:"";s:6:"footer";s:0:"";s:12:"file_tpl_tag";s:3:"mp3";s:11:"cat_tpl_tag";s:7:"default";}s:10:"data-table";a:4:{s:6:"header";s:216:"%print_script:jquery-dataTables%
%print_style:jquery-dataTables%
<table id="wpfb-data-table-%uid%">
<thead>
	<tr><th scope="col">Name</th><th scope="col">Size</th><th scope="col">Hits</th></tr>
</thead>
<tbody>";s:6:"footer";s:172:"</tbody>
</table>
<script type="text/javascript" charset="utf-8">
	jQuery(document).ready(function() {
		jQuery(\'#wpfb-data-table-%uid%\').dataTable();
	} );
</script>";s:12:"file_tpl_tag";s:10:"data-table";s:11:"cat_tpl_tag";s:10:"data-table";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (466, 'wpfb_install_time', '1399647380', 'no') ; 
INSERT INTO `wp_options` VALUES (469, 'rewrite_rules', 'a:89:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:43:"work/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:38:"work/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:31:"work/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:13:"work/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:37:"portfolio/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"portfolio/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"portfolio/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"portfolio/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"portfolio/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"portfolio/([^/]+)/trackback/?$";s:36:"index.php?portfolio=$matches[1]&tb=1";s:38:"portfolio/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?portfolio=$matches[1]&paged=$matches[2]";s:45:"portfolio/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?portfolio=$matches[1]&cpage=$matches[2]";s:30:"portfolio/([^/]+)(/[0-9]+)?/?$";s:48:"index.php?portfolio=$matches[1]&page=$matches[2]";s:26:"portfolio/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"portfolio/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"portfolio/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"portfolio/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"portfolio/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:59:"portfolio-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?portfolio_cats=$matches[1]&feed=$matches[2]";s:54:"portfolio-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?portfolio_cats=$matches[1]&feed=$matches[2]";s:47:"portfolio-category/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?portfolio_cats=$matches[1]&paged=$matches[2]";s:29:"portfolio-category/([^/]+)/?$";s:36:"index.php?portfolio_cats=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (471, '_site_transient_timeout_theme_roots', '1399649261', 'yes') ; 
INSERT INTO `wp_options` VALUES (472, '_site_transient_theme_roots', 'a:2:{s:13:"stanley-child";s:7:"/themes";s:9:"stanleywp";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (473, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1399647465;s:7:"checked";a:6:{s:19:"akismet/akismet.php";s:5:"3.0.0";s:36:"awesome-filterable-portfolio/afp.php";s:3:"1.8";s:35:"backupwordpress/backupwordpress.php";s:5:"2.6.2";s:36:"contact-form-7/wp-contact-form-7.php";s:3:"3.8";s:24:"wordpress-seo/wp-seo.php";s:7:"1.5.2.8";s:27:"wp-filebase/wp-filebase.php";s:8:"0.3.0.06";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (474, 'hmbkp_default_path', '/Users/eponce_420/Website/www.lizponce.com/wp-content/backupwordpress-9013187ce7-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (475, 'hmbkp_path', '/Users/eponce_420/Website/www.lizponce.com/wp-content/backupwordpress-9013187ce7-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (476, '_transient_doing_cron', '1399647475.1677689552307128906250', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=687 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (407 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (3, 4, '_edit_lock', '1399343163:1') ; 
INSERT INTO `wp_postmeta` VALUES (4, 6, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 6, '_edit_lock', '1399610387:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 8, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (7, 8, '_edit_lock', '1399512854:1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 10, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 10, '_edit_lock', '1398572111:1') ; 
INSERT INTO `wp_postmeta` VALUES (10, 12, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (11, 12, '_edit_lock', '1398572131:1') ; 
INSERT INTO `wp_postmeta` VALUES (12, 14, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13, 14, '_edit_lock', '1398894188:1') ; 
INSERT INTO `wp_postmeta` VALUES (16, 17, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (17, 17, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (18, 17, '_menu_item_object_id', '17') ; 
INSERT INTO `wp_postmeta` VALUES (19, 17, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (20, 17, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (21, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (22, 17, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (23, 17, '_menu_item_url', 'http://localhost:8888/') ; 
INSERT INTO `wp_postmeta` VALUES (24, 17, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (25, 18, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (26, 18, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (27, 18, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (28, 18, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (29, 18, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (30, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (31, 18, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 18, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (33, 18, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (34, 19, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (35, 19, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (36, 19, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (37, 19, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (38, 19, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (39, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (40, 19, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (41, 19, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (42, 19, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (43, 20, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (44, 20, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (45, 20, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (46, 20, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (47, 20, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (48, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (49, 20, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (50, 20, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (51, 20, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (52, 21, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (53, 21, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (54, 21, '_menu_item_object_id', '8') ; 
INSERT INTO `wp_postmeta` VALUES (55, 21, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (56, 21, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (57, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (58, 21, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (59, 21, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (60, 21, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (61, 22, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (62, 22, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (63, 22, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (64, 22, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (65, 22, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (66, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (67, 22, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (68, 22, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (69, 22, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (70, 23, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (71, 23, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (72, 23, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (73, 23, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (74, 23, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (75, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (76, 23, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (77, 23, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (78, 23, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (79, 24, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (80, 24, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (81, 24, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (82, 24, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (83, 24, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (84, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (85, 24, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (86, 24, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (87, 24, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (88, 25, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (89, 25, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (90, 25, '_menu_item_object_id', '25') ; 
INSERT INTO `wp_postmeta` VALUES (91, 25, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (92, 25, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (93, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (94, 25, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (95, 25, '_menu_item_url', 'http://localhost:8888/') ; 
INSERT INTO `wp_postmeta` VALUES (97, 26, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (98, 26, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (99, 26, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (100, 26, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (101, 26, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (102, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (103, 26, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (104, 26, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (106, 27, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (107, 27, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (108, 27, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (109, 27, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (110, 27, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (111, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (112, 27, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (113, 27, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (115, 28, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (116, 28, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (117, 28, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (118, 28, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (119, 28, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (120, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (121, 28, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (122, 28, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (123, 28, '_menu_item_orphaned', '1398893994') ; 
INSERT INTO `wp_postmeta` VALUES (142, 31, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (143, 31, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (144, 31, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (145, 31, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (146, 31, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (147, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (148, 31, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (149, 31, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (150, 31, '_menu_item_orphaned', '1398893994') ; 
INSERT INTO `wp_postmeta` VALUES (160, 4, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (161, 4, 'wtf_about_title', '<h1>About Stanley!</h1>') ; 
INSERT INTO `wp_postmeta` VALUES (162, 4, 'wtf_about_left_txt', '<h4>THE THINKING</h4>
				<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p>') ; 
INSERT INTO `wp_postmeta` VALUES (163, 4, 'wtf_about_right_txt', '<h4>THE SKILLS</h4>
				Wordpress
				<div class="progress">
					<div class="progress-bar progress-bar-theme" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
						<span class="sr-only">60% Complete</span>
					</div>
				</div>

				Photoshop
				<div class="progress">
					<div class="progress-bar progress-bar-theme" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
						<span class="sr-only">80% Complete</span>
					</div>
				</div>
				
				HTML + CSS
				<div class="progress">
					<div class="progress-bar progress-bar-theme" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
						<span class="sr-only">95% Complete</span>
					</div>
				</div>') ; 
INSERT INTO `wp_postmeta` VALUES (164, 4, 'wtf_about_col', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (165, 4, 'wtf_portfolio_title', '<h3>LATEST WORKS</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (179, 40, '_wp_attached_file', '2014/05/Hexagon.png') ; 
INSERT INTO `wp_postmeta` VALUES (180, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:93;s:4:"file";s:19:"2014/05/Hexagon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Hexagon-150x93.png";s:5:"width";i:150;s:6:"height";i:93;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (181, 41, '_wp_attached_file', '2014/05/LizPonce_WebLogo.png') ; 
INSERT INTO `wp_postmeta` VALUES (182, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:120;s:4:"file";s:28:"2014/05/LizPonce_WebLogo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"LizPonce_WebLogo-150x120.png";s:5:"width";i:150;s:6:"height";i:120;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (195, 48, '_wp_attached_file', '2014/05/WebDesign_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (196, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:26:"2014/05/WebDesign_Icon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"WebDesign_Icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (197, 49, '_wp_attached_file', '2014/05/Geometric_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (198, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:26:"2014/05/Geometric_Icon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Geometric_Icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (199, 50, '_wp_attached_file', '2014/05/Shutter_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (200, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:24:"2014/05/Shutter_Icon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Shutter_Icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (201, 51, '_wp_attached_file', '2014/05/Twitter_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (202, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:25;s:6:"height";i:25;s:4:"file";s:24:"2014/05/Twitter_Icon.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (203, 52, '_wp_attached_file', '2014/05/LinkedIn_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (204, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:25;s:6:"height";i:25;s:4:"file";s:25:"2014/05/LinkedIn_Icon.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (205, 59, '_form', '<p>Your Name*<br />
    [text* your-name] </p>

<p>Your Email*<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Write Some Words<br />
    [textarea your-message] </p>

<p>[submit "Give Me a Shout"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (206, 59, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:168:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)";s:9:"recipient";s:16:"liz@lizponce.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (207, 59, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:110:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (208, 59, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (209, 59, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (210, 59, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (211, 6, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (212, 8, '_wp_page_template', 'template-child-graphic-design.php') ; 
INSERT INTO `wp_postmeta` VALUES (213, 12, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (214, 12, '_wp_trash_meta_time', '1399382440') ; 
INSERT INTO `wp_postmeta` VALUES (215, 10, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (216, 10, '_wp_trash_meta_time', '1399382440') ; 
INSERT INTO `wp_postmeta` VALUES (219, 67, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (220, 67, 'wtf_portfolio_top_title', '<h3>Brookline College Flyers</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (221, 67, '_edit_lock', '1399429495:1') ; 
INSERT INTO `wp_postmeta` VALUES (223, 8, 'wtf_portfolio_title', '<h3>LATEST WORKS</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (224, 67, 'wtf_port_cats', 'value2') ; 
INSERT INTO `wp_postmeta` VALUES (225, 71, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (226, 71, '_edit_lock', '1399429517:1') ; 
INSERT INTO `wp_postmeta` VALUES (228, 71, 'wtf_portfolio_top_title', '<h3>PROJECT NAME</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (229, 73, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (230, 73, '_edit_lock', '1399430416:1') ; 
INSERT INTO `wp_postmeta` VALUES (232, 73, 'wtf_portfolio_top_title', '<h3>PROJECT NAME</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (233, 75, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (234, 75, '_edit_lock', '1399431211:1') ; 
INSERT INTO `wp_postmeta` VALUES (238, 75, 'wtf_portfolio_top_title', '<h3>PROJECT NAME</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (239, 75, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (240, 75, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (241, 73, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (242, 73, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (243, 71, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (244, 71, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (245, 67, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (246, 67, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (247, 1, '_edit_lock', '1399609058:1') ; 
INSERT INTO `wp_postmeta` VALUES (249, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (252, 85, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (253, 85, '_edit_lock', '1399432695:1') ; 
INSERT INTO `wp_postmeta` VALUES (254, 85, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (255, 87, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (256, 87, '_edit_lock', '1399432721:1') ; 
INSERT INTO `wp_postmeta` VALUES (257, 87, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (276, 91, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (277, 91, '_edit_lock', '1399432947:1') ; 
INSERT INTO `wp_postmeta` VALUES (278, 91, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (315, 99, '_wp_attached_file', '2014/05/BC_Flyers.png') ; 
INSERT INTO `wp_postmeta` VALUES (316, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:21:"2014/05/BC_Flyers.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"BC_Flyers-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"BC_Flyers-300x198.png";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (317, 100, '_wp_attached_file', '2014/05/BC_Poster.png') ; 
INSERT INTO `wp_postmeta` VALUES (318, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1384;s:4:"file";s:21:"2014/05/BC_Poster.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"BC_Poster-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"BC_Poster-216x300.png";s:5:"width";i:216;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:22:"BC_Poster-739x1024.png";s:5:"width";i:739;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (319, 101, '_wp_attached_file', '2014/05/BC_Homepage.png') ; 
INSERT INTO `wp_postmeta` VALUES (320, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:992;s:6:"height";i:410;s:4:"file";s:23:"2014/05/BC_Homepage.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"BC_Homepage-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"BC_Homepage-300x123.png";s:5:"width";i:300;s:6:"height";i:123;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (321, 102, '_wp_attached_file', '2014/05/BC_NewsAds.png') ; 
INSERT INTO `wp_postmeta` VALUES (322, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:580;s:6:"height";i:486;s:4:"file";s:22:"2014/05/BC_NewsAds.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"BC_NewsAds-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"BC_NewsAds-300x251.png";s:5:"width";i:300;s:6:"height";i:251;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (323, 103, '_wp_attached_file', '2014/05/NG_Seminar.png') ; 
INSERT INTO `wp_postmeta` VALUES (324, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:581;s:4:"file";s:22:"2014/05/NG_Seminar.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"NG_Seminar-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"NG_Seminar-300x174.png";s:5:"width";i:300;s:6:"height";i:174;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (325, 104, '_wp_attached_file', '2014/05/NG_Web.png') ; 
INSERT INTO `wp_postmeta` VALUES (326, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:691;s:4:"file";s:18:"2014/05/NG_Web.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"NG_Web-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"NG_Web-300x207.png";s:5:"width";i:300;s:6:"height";i:207;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (327, 105, '_wp_attached_file', '2014/05/CS_Billboard.png') ; 
INSERT INTO `wp_postmeta` VALUES (328, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:24:"2014/05/CS_Billboard.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"CS_Billboard-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"CS_Billboard-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (329, 106, '_wp_attached_file', '2014/05/CS_Mag.png') ; 
INSERT INTO `wp_postmeta` VALUES (330, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:682;s:4:"file";s:18:"2014/05/CS_Mag.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"CS_Mag-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"CS_Mag-300x204.png";s:5:"width";i:300;s:6:"height";i:204;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (331, 107, '_wp_attached_file', '2014/05/HC_Flyer.png') ; 
INSERT INTO `wp_postmeta` VALUES (332, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:597;s:4:"file";s:20:"2014/05/HC_Flyer.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"HC_Flyer-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"HC_Flyer-300x179.png";s:5:"width";i:300;s:6:"height";i:179;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (333, 108, '_wp_attached_file', '2014/05/LilWayne_Poster.png') ; 
INSERT INTO `wp_postmeta` VALUES (334, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1187;s:4:"file";s:27:"2014/05/LilWayne_Poster.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"LilWayne_Poster-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"LilWayne_Poster-252x300.png";s:5:"width";i:252;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"LilWayne_Poster-862x1024.png";s:5:"width";i:862;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (335, 109, '_wp_attached_file', '2014/05/HC_Homepage.png') ; 
INSERT INTO `wp_postmeta` VALUES (336, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:594;s:4:"file";s:23:"2014/05/HC_Homepage.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"HC_Homepage-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"HC_Homepage-300x178.png";s:5:"width";i:300;s:6:"height";i:178;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (337, 110, '_wp_attached_file', '2014/05/Label_MeatPackaging.png') ; 
INSERT INTO `wp_postmeta` VALUES (338, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:862;s:6:"height";i:750;s:4:"file";s:31:"2014/05/Label_MeatPackaging.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Label_MeatPackaging-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:31:"Label_MeatPackaging-300x261.png";s:5:"width";i:300;s:6:"height";i:261;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (339, 111, '_wp_attached_file', '2014/05/Shirt_Millenium.png') ; 
INSERT INTO `wp_postmeta` VALUES (340, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:675;s:6:"height";i:882;s:4:"file";s:27:"2014/05/Shirt_Millenium.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Shirt_Millenium-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Shirt_Millenium-229x300.png";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (341, 112, '_wp_attached_file', '2014/05/Wine_TerraNova.png') ; 
INSERT INTO `wp_postmeta` VALUES (342, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1191;s:4:"file";s:26:"2014/05/Wine_TerraNova.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Wine_TerraNova-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"Wine_TerraNova-251x300.png";s:5:"width";i:251;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:27:"Wine_TerraNova-859x1024.png";s:5:"width";i:859;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (343, 113, '_wp_attached_file', '2014/05/Wayfinding_Cart.png') ; 
INSERT INTO `wp_postmeta` VALUES (344, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:780;s:6:"height";i:587;s:4:"file";s:27:"2014/05/Wayfinding_Cart.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Wayfinding_Cart-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Wayfinding_Cart-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (345, 114, '_wp_attached_file', '2014/05/TypeChronology.png') ; 
INSERT INTO `wp_postmeta` VALUES (346, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:564;s:4:"file";s:26:"2014/05/TypeChronology.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"TypeChronology-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"TypeChronology-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (347, 115, '_wp_attached_file', '2014/05/Wayfinding_App.png') ; 
INSERT INTO `wp_postmeta` VALUES (348, 115, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1152;s:4:"file";s:26:"2014/05/Wayfinding_App.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Wayfinding_App-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"Wayfinding_App-260x300.png";s:5:"width";i:260;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:27:"Wayfinding_App-888x1024.png";s:5:"width";i:888;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (349, 116, '_wp_attached_file', '2014/05/Windstar_Logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (350, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:868;s:6:"height";i:569;s:4:"file";s:25:"2014/05/Windstar_Logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Windstar_Logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"Windstar_Logo-300x196.png";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (351, 117, '_wp_attached_file', '2014/05/BC_Homepage_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (352, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:26:"2014/05/BC_Homepage_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"BC_Homepage_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"BC_Homepage_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (353, 118, '_wp_attached_file', '2014/05/BC_Flyers_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (354, 118, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:24:"2014/05/BC_Flyers_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"BC_Flyers_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"BC_Flyers_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (355, 119, '_wp_attached_file', '2014/05/BC_NewsAds_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (356, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:25:"2014/05/BC_NewsAds_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BC_NewsAds_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"BC_NewsAds_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (357, 120, '_wp_attached_file', '2014/05/BC_Poster_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (358, 120, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:24:"2014/05/BC_Poster_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"BC_Poster_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"BC_Poster_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (359, 121, '_wp_attached_file', '2014/05/NG_Seminar_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (360, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:25:"2014/05/NG_Seminar_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"NG_Seminar_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"NG_Seminar_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (361, 122, '_wp_attached_file', '2014/05/CS_Mag_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (362, 122, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:21:"2014/05/CS_Mag_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"CS_Mag_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"CS_Mag_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (363, 123, '_wp_attached_file', '2014/05/CS_Billboard_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (364, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:27:"2014/05/CS_Billboard_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"CS_Billboard_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"CS_Billboard_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (365, 124, '_wp_attached_file', '2014/05/NG_Web_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (366, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:21:"2014/05/NG_Web_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"NG_Web_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"NG_Web_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (367, 125, '_wp_attached_file', '2014/05/HC_Flyer_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (368, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:23:"2014/05/HC_Flyer_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"HC_Flyer_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"HC_Flyer_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (369, 126, '_wp_attached_file', '2014/05/HC_Homepage_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (370, 126, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:26:"2014/05/HC_Homepage_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"HC_Homepage_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"HC_Homepage_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (371, 127, '_wp_attached_file', '2014/05/LilWayne_Poster_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (372, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:30:"2014/05/LilWayne_Poster_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"LilWayne_Poster_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"LilWayne_Poster_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (373, 128, '_wp_attached_file', '2014/05/Label_MeatPackaging_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (374, 128, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:34:"2014/05/Label_MeatPackaging_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"Label_MeatPackaging_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:34:"Label_MeatPackaging_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (375, 129, '_wp_attached_file', '2014/05/Shirt_Millenium_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (376, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:30:"2014/05/Shirt_Millenium_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Shirt_Millenium_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"Shirt_Millenium_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (377, 130, '_wp_attached_file', '2014/05/Wine_TerraNova_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (378, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:29:"2014/05/Wine_TerraNova_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"Wine_TerraNova_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"Wine_TerraNova_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (379, 131, '_wp_attached_file', '2014/05/TypeChronology_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (380, 131, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:29:"2014/05/TypeChronology_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"TypeChronology_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"TypeChronology_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (381, 132, '_wp_attached_file', '2014/05/Wayfinding_Cart_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (382, 132, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:30:"2014/05/Wayfinding_Cart_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Wayfinding_Cart_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"Wayfinding_Cart_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (383, 133, '_wp_attached_file', '2014/05/Wayfinding_App_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (384, 133, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:29:"2014/05/Wayfinding_App_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"Wayfinding_App_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"Wayfinding_App_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (385, 134, '_wp_attached_file', '2014/05/Windstar_Logo_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (386, 134, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/Windstar_Logo_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Windstar_Logo_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:28:"Windstar_Logo_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (387, 1, '_thumbnail_id', '118') ; 
INSERT INTO `wp_postmeta` VALUES (390, 1, '_wp_old_slug', 'hello-world') ; 
INSERT INTO `wp_postmeta` VALUES (397, 141, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (398, 141, '_edit_lock', '1399609054:1') ; 
INSERT INTO `wp_postmeta` VALUES (399, 141, '_thumbnail_id', '120') ; 
INSERT INTO `wp_postmeta` VALUES (404, 143, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (405, 143, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (406, 143, '_menu_item_object_id', '3') ; 
INSERT INTO `wp_postmeta` VALUES (407, 143, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (408, 143, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (409, 143, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (410, 143, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (411, 143, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (413, 8, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (414, 8, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (415, 91, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (416, 91, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (417, 87, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (418, 87, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (419, 85, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (420, 85, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (421, 144, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (422, 144, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (423, 144, '_menu_item_object_id', '5') ; 
INSERT INTO `wp_postmeta` VALUES (424, 144, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (425, 144, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (426, 144, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (427, 144, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (428, 144, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (430, 145, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (431, 145, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (432, 145, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (433, 145, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (434, 145, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (435, 145, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (436, 145, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (437, 145, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (439, 146, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (440, 146, '_edit_lock', '1399609042:1') ; 
INSERT INTO `wp_postmeta` VALUES (441, 146, '_thumbnail_id', '119') ; 
INSERT INTO `wp_postmeta` VALUES (444, 148, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (445, 148, '_edit_lock', '1399608782:1') ; 
INSERT INTO `wp_postmeta` VALUES (446, 148, '_thumbnail_id', '117') ; 
INSERT INTO `wp_postmeta` VALUES (457, 154, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (458, 154, '_edit_lock', '1399609020:1') ; 
INSERT INTO `wp_postmeta` VALUES (459, 154, '_thumbnail_id', '121') ; 
INSERT INTO `wp_postmeta` VALUES (462, 156, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (463, 156, '_edit_lock', '1399608800:1') ; 
INSERT INTO `wp_postmeta` VALUES (464, 156, '_thumbnail_id', '124') ; 
INSERT INTO `wp_postmeta` VALUES (467, 158, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (468, 158, '_edit_lock', '1399609012:1') ; 
INSERT INTO `wp_postmeta` VALUES (469, 158, '_thumbnail_id', '123') ; 
INSERT INTO `wp_postmeta` VALUES (472, 160, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (473, 160, '_edit_lock', '1399609003:1') ; 
INSERT INTO `wp_postmeta` VALUES (474, 160, '_thumbnail_id', '122') ; 
INSERT INTO `wp_postmeta` VALUES (477, 162, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (478, 162, '_edit_lock', '1399608963:1') ; 
INSERT INTO `wp_postmeta` VALUES (479, 162, '_thumbnail_id', '125') ; 
INSERT INTO `wp_postmeta` VALUES (482, 164, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (483, 164, '_edit_lock', '1399608949:1') ; 
INSERT INTO `wp_postmeta` VALUES (484, 164, '_thumbnail_id', '127') ; 
INSERT INTO `wp_postmeta` VALUES (487, 166, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (488, 166, '_edit_lock', '1399608602:1') ; 
INSERT INTO `wp_postmeta` VALUES (489, 166, '_thumbnail_id', '126') ; 
INSERT INTO `wp_postmeta` VALUES (492, 168, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (493, 168, '_edit_lock', '1399608935:1') ; 
INSERT INTO `wp_postmeta` VALUES (494, 168, '_thumbnail_id', '128') ; 
INSERT INTO `wp_postmeta` VALUES (497, 170, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (498, 170, '_edit_lock', '1399608917:1') ; 
INSERT INTO `wp_postmeta` VALUES (499, 170, '_thumbnail_id', '129') ; 
INSERT INTO `wp_postmeta` VALUES (502, 172, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (503, 172, '_edit_lock', '1399608897:1') ; 
INSERT INTO `wp_postmeta` VALUES (504, 172, '_thumbnail_id', '130') ; 
INSERT INTO `wp_postmeta` VALUES (507, 174, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (508, 174, '_edit_lock', '1399608882:1') ; 
INSERT INTO `wp_postmeta` VALUES (509, 174, '_thumbnail_id', '132') ; 
INSERT INTO `wp_postmeta` VALUES (512, 176, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (513, 176, '_edit_lock', '1399608869:1') ; 
INSERT INTO `wp_postmeta` VALUES (514, 176, '_thumbnail_id', '131') ; 
INSERT INTO `wp_postmeta` VALUES (517, 178, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (518, 178, '_edit_lock', '1399608529:1') ; 
INSERT INTO `wp_postmeta` VALUES (519, 178, '_thumbnail_id', '133') ; 
INSERT INTO `wp_postmeta` VALUES (522, 180, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (523, 180, '_edit_lock', '1399643029:1') ; 
INSERT INTO `wp_postmeta` VALUES (524, 180, '_thumbnail_id', '134') ; 
INSERT INTO `wp_postmeta` VALUES (605, 224, '_wp_attached_file', '2014/05/Maintenance.png') ; 
INSERT INTO `wp_postmeta` VALUES (606, 224, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:440;s:6:"height";i:350;s:4:"file";s:23:"2014/05/Maintenance.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"Maintenance-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"Maintenance-300x238.png";s:5:"width";i:300;s:6:"height";i:238;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (607, 226, '_wp_attached_file', '2014/05/Arch.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (608, 226, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:16:"2014/05/Arch.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"Arch-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"Arch-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (609, 227, '_wp_attached_file', '2014/05/BraylonKeira1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (610, 227, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:25:"2014/05/BraylonKeira1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira1-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (611, 225, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (612, 225, '_edit_lock', '1399643498:1') ; 
INSERT INTO `wp_postmeta` VALUES (613, 228, '_wp_attached_file', '2014/05/Water.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (614, 228, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:17:"2014/05/Water.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Water-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"Water-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (615, 229, '_wp_attached_file', '2014/05/LightRail.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (616, 229, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:21:"2014/05/LightRail.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"LightRail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"LightRail-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (617, 230, '_wp_attached_file', '2014/05/Cactus.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (618, 230, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1333;s:4:"file";s:18:"2014/05/Cactus.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Cactus-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"Cactus-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"Cactus-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (619, 231, '_wp_attached_file', '2014/05/BraylonKeira4.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (620, 231, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:25:"2014/05/BraylonKeira4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira4-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (621, 232, '_wp_attached_file', '2014/05/BraylonKeira3.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (622, 232, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1510;s:4:"file";s:25:"2014/05/BraylonKeira3.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira3-198x300.jpg";s:5:"width";i:198;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"BraylonKeira3-678x1024.jpg";s:5:"width";i:678;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (623, 233, '_wp_attached_file', '2014/05/BraylonKeira2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (624, 233, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:25:"2014/05/BraylonKeira2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira2-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (625, 234, '_wp_attached_file', '2014/05/Water_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (626, 234, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:20:"2014/05/Water_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"Water_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"Water_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (627, 235, '_wp_attached_file', '2014/05/LightRail_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (628, 235, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:24:"2014/05/LightRail_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"LightRail_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"LightRail_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (629, 236, '_wp_attached_file', '2014/05/Cactus_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (630, 236, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:21:"2014/05/Cactus_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"Cactus_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Cactus_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (631, 237, '_wp_attached_file', '2014/05/Arch_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (632, 237, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:19:"2014/05/Arch_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"Arch_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"Arch_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (633, 238, '_wp_attached_file', '2014/05/BraylonKeira4_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (634, 238, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira4_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira4_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira4_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (635, 239, '_wp_attached_file', '2014/05/BraylonKeira3_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (636, 239, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira3_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira3_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira3_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (637, 240, '_wp_attached_file', '2014/05/BraylonKeira2_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (638, 240, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira2_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira2_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira2_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (639, 241, '_wp_attached_file', '2014/05/BraylonKeira1_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (640, 241, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira1_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira1_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira1_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (643, 225, '_thumbnail_id', '241') ; 
INSERT INTO `wp_postmeta` VALUES (646, 243, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (647, 243, '_edit_lock', '1399643470:1') ; 
INSERT INTO `wp_postmeta` VALUES (648, 243, '_thumbnail_id', '240') ; 
INSERT INTO `wp_postmeta` VALUES (655, 247, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (656, 247, '_edit_lock', '1399643550:1') ; 
INSERT INTO `wp_postmeta` VALUES (657, 247, '_thumbnail_id', '239') ; 
INSERT INTO `wp_postmeta` VALUES (660, 249, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (661, 249, '_edit_lock', '1399643947:1') ; 
INSERT INTO `wp_postmeta` VALUES (664, 251, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (665, 251, '_edit_lock', '1399643652:1') ; 
INSERT INTO `wp_postmeta` VALUES (666, 251, '_thumbnail_id', '237') ; 
INSERT INTO `wp_postmeta` VALUES (669, 253, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (670, 253, '_edit_lock', '1399643750:1') ; 
INSERT INTO `wp_postmeta` VALUES (671, 253, '_thumbnail_id', '234') ; 
INSERT INTO `wp_postmeta` VALUES (674, 255, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (675, 255, '_edit_lock', '1399643797:1') ; 
INSERT INTO `wp_postmeta` VALUES (676, 255, '_thumbnail_id', '236') ; 
INSERT INTO `wp_postmeta` VALUES (679, 257, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (680, 257, '_edit_lock', '1399643855:1') ; 
INSERT INTO `wp_postmeta` VALUES (681, 257, '_thumbnail_id', '235') ; 
INSERT INTO `wp_postmeta` VALUES (684, 249, '_thumbnail_id', '238') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (232 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-04-27 04:13:11', '2014-04-27 04:13:11', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Brookline College Flyers</h1>
<hr class="content-title-rule">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'publish', 'open', 'open', '', 'bc-flyers', '', '', '2014-05-09 04:15:59', '2014-05-09 04:15:59', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-04-27 04:13:11', '2014-04-27 04:13:11', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-04-27 04:13:11', '2014-04-27 04:13:11', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2014-04-27 04:16:32', '2014-04-27 04:16:32', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life.
<br>
<br>
After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status.
<br>
<br>
Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads/2014-05/LizPonce_Resume/pdf">here</a>.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-05-06 02:23:13', '2014-05-06 02:23:13', '', 0, 'http://localhost:8888/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-04-27 04:16:32', '2014-04-27 04:16:32', 'Hi! Here is the section about yours truly!', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-04-27 04:16:32', '2014-04-27 04:16:32', '', 4, 'http://localhost:8888/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-04-27 04:16:52', '2014-04-27 04:16:52', 'Follow/Tweet Me - <a style="color: #005bad;" href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a style="color: #005bad;" href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-05-06 13:02:44', '2014-05-06 13:02:44', '', 0, 'http://localhost:8888/?page_id=6', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-04-27 04:16:52', '2014-04-27 04:16:52', 'Contact me!', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-04-27 04:16:52', '2014-04-27 04:16:52', '', 6, 'http://localhost:8888/?p=7', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-04-27 04:17:14', '2014-04-27 04:17:14', '', 'Graphic Design', '', 'trash', 'open', 'open', '', 'graphic-design', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 0, 'http://localhost:8888/?page_id=8', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-04-27 04:17:14', '2014-04-27 04:17:14', 'Here are my super cool graphics!', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-04-27 04:17:14', '2014-04-27 04:17:14', '', 8, 'http://localhost:8888/?p=9', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-04-27 04:17:33', '2014-04-27 04:17:33', 'Your CSS expert reporting here!', 'Web Design', '', 'trash', 'open', 'open', '', 'web-design', '', '', '2014-05-06 13:20:40', '2014-05-06 13:20:40', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-04-27 04:17:33', '2014-04-27 04:17:33', 'Your CSS expert reporting here!', 'Web Design', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-04-27 04:17:33', '2014-04-27 04:17:33', '', 10, 'http://localhost:8888/?p=11', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-04-27 04:17:53', '2014-04-27 04:17:53', 'What!? Pictures too??', 'Photography', '', 'trash', 'open', 'open', '', 'photography', '', '', '2014-05-06 13:20:40', '2014-05-06 13:20:40', '', 0, 'http://localhost:8888/?page_id=12', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-04-27 04:17:53', '2014-04-27 04:17:53', 'What!? Pictures too??', 'Photography', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-04-27 04:17:53', '2014-04-27 04:17:53', '', 12, 'http://localhost:8888/?p=13', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 'Downloadable Pictures', '', 'publish', 'open', 'open', 'showmethemoney!', 'downloadable-pictures', '', '', '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 0, 'http://localhost:8888/?page_id=14', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 'Downloadable Pictures', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 14, 'http://localhost:8888/?p=15', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=17', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=18', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=19', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=20', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=21', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=22', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=23', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=24', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-04-30 21:40:41', '2014-04-30 21:40:41', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-05-08 01:41:43', '2014-05-08 01:41:43', '', 0, 'http://localhost:8888/?p=25', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2014-04-30 21:40:41', '2014-04-30 21:40:41', ' ', '', '', 'publish', 'open', 'open', '', '26', '', '', '2014-05-08 01:41:43', '2014-05-08 01:41:43', '', 0, 'http://localhost:8888/?p=26', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-04-30 21:40:41', '2014-04-30 21:40:41', ' ', '', '', 'publish', 'open', 'open', '', '27', '', '', '2014-05-08 01:41:44', '2014-05-08 01:41:44', '', 0, 'http://localhost:8888/?p=27', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2014-04-30 21:39:54', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=28', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-04-30 21:39:54', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=31', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2014-05-01 01:36:49', '2014-05-01 01:36:49', '', 'Hexagon', '', 'inherit', 'open', 'open', '', 'hexagon', '', '', '2014-05-01 01:36:49', '2014-05-01 01:36:49', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Hexagon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-05-01 01:40:02', '2014-05-01 01:40:02', '', 'LizPonce_WebLogo', '', 'inherit', 'open', 'open', '', 'lizponce_weblogo', '', '', '2014-05-01 01:40:02', '2014-05-01 01:40:02', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LizPonce_WebLogo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2014-05-01 02:42:56', '2014-05-01 02:42:56', '', 'WebDesign_Icon', '', 'inherit', 'open', 'open', '', 'webdesign_icon', '', '', '2014-05-01 02:42:56', '2014-05-01 02:42:56', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/WebDesign_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-05-01 02:42:57', '2014-05-01 02:42:57', '', 'Geometric_Icon', '', 'inherit', 'open', 'open', '', 'geometric_icon', '', '', '2014-05-01 02:42:57', '2014-05-01 02:42:57', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Geometric_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-05-01 02:42:58', '2014-05-01 02:42:58', '', 'Shutter_Icon', '', 'inherit', 'open', 'open', '', 'shutter_icon', '', '', '2014-05-01 02:42:58', '2014-05-01 02:42:58', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Shutter_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-05-01 03:09:24', '2014-05-01 03:09:24', '', 'Twitter_Icon', '', 'inherit', 'open', 'open', '', 'twitter_icon', '', '', '2014-05-01 03:09:24', '2014-05-01 03:09:24', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Twitter_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2014-05-01 03:09:25', '2014-05-01 03:09:25', '', 'LinkedIn_Icon', '', 'inherit', 'open', 'open', '', 'linkedin_icon', '', '', '2014-05-01 03:09:25', '2014-05-01 03:09:25', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LinkedIn_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-05-01 04:08:58', '2014-05-01 04:08:58', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads">here.', 'About', '', 'inherit', 'open', 'open', '', '4-autosave-v1', '', '', '2014-05-01 04:08:58', '2014-05-01 04:08:58', '', 4, 'http://localhost:8888/4-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-05-01 04:04:23', '2014-05-01 04:04:23', 'Hello! My name is Liz Ponce and I am a Graphic Designer, Web Designer and Photographer. How did I get here you ask? Well, let me explain...

At the tender age of 16, I started took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:04:23', '2014-05-01 04:04:23', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2014-05-01 04:04:56', '2014-05-01 04:04:56', 'Hello! My name is Liz Ponce and I am a Graphic Designer, Web Designer and Photographer. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:04:56', '2014-05-01 04:04:56', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-05-01 04:06:56', '2014-05-01 04:06:56', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:06:56', '2014-05-01 04:06:56', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2014-05-01 04:09:20', '2014-05-01 04:09:20', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads/2014-05/LizPonce_Resume/pdf">here</a>.', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:09:20', '2014-05-01 04:09:20', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2014-05-06 02:23:13', '2014-05-06 02:23:13', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life.
<br>
<br>
After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status.
<br>
<br>
Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads/2014-05/LizPonce_Resume/pdf">here</a>.', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-06 02:23:13', '2014-05-06 02:23:13', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2014-05-06 02:29:00', '2014-05-06 02:29:00', '<p>Your Name*<br />
    [text* your-name] </p>

<p>Your Email*<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Write Some Words<br />
    [textarea your-message] </p>

<p>[submit "Give Me a Shout"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)
liz@lizponce.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2014-05-06 02:32:11', '2014-05-06 02:32:11', '', 0, 'http://localhost:8888/?post_type=wpcf7_contact_form&#038;p=59', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2014-05-06 13:02:34', '2014-05-06 13:02:34', 'Follow/Tweet Me - <a style="color: #005bad;" href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a style="color: #005bad;" href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-autosave-v1', '', '', '2014-05-06 13:02:34', '2014-05-06 13:02:34', '', 6, 'http://localhost:8888/6-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-05-06 02:30:40', '2014-05-06 02:30:40', 'Contact me!
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-05-06 02:30:40', '2014-05-06 02:30:40', '', 6, 'http://localhost:8888/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-05-06 02:34:55', '2014-05-06 02:34:55', 'Follow/Tweet Me - <a href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-05-06 02:34:55', '2014-05-06 02:34:55', '', 6, 'http://localhost:8888/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-05-06 13:02:07', '2014-05-06 13:02:07', 'Follow/Tweet Me - <a style="color: #005bad;" href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a style="color: #005bad;" href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-05-06 13:02:07', '2014-05-06 13:02:07', '', 6, 'http://localhost:8888/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-05-07 04:01:54', '2014-05-07 04:01:54', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-autosave-v1', '', '', '2014-05-07 04:01:54', '2014-05-07 04:01:54', '', 8, 'http://localhost:8888/8-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-05-06 13:19:47', '2014-05-06 13:19:47', '', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-06 13:19:47', '2014-05-06 13:19:47', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-05-06 13:20:52', '2014-05-06 13:20:52', '', 'Work', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-06 13:20:52', '2014-05-06 13:20:52', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-05-06 14:56:56', '2014-05-06 14:56:56', '', 'Brookline College Flyers', '', 'trash', 'open', 'open', '', 'brookline-college-flyers', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=67', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2014-05-06 14:56:56', '2014-05-06 14:56:56', '<img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" />', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '67-revision-v1', '', '', '2014-05-06 14:56:56', '2014-05-06 14:56:56', '', 67, 'http://localhost:8888/67-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2014-05-06 14:57:55', '2014-05-06 14:57:55', '', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '67-revision-v1', '', '', '2014-05-06 14:57:55', '2014-05-06 14:57:55', '', 67, 'http://localhost:8888/67-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-05-07 02:27:37', '2014-05-07 02:27:37', '', 'Flyer', '', 'trash', 'open', 'open', '', 'flyer', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=71', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2014-05-07 02:27:37', '2014-05-07 02:27:37', '', 'Flyer', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-05-07 02:27:37', '2014-05-07 02:27:37', '', 71, 'http://localhost:8888/71-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2014-05-07 02:27:57', '2014-05-07 02:27:57', '<p>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
</p>
<p>
It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
</p>', 'Brookline College', '', 'trash', 'open', 'open', '', 'brookline-college', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=73', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-05-07 02:27:57', '2014-05-07 02:27:57', '', 'Brookline College', '', 'inherit', 'open', 'open', '', '73-revision-v1', '', '', '2014-05-07 02:27:57', '2014-05-07 02:27:57', '', 73, 'http://localhost:8888/73-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-05-07 02:28:43', '2014-05-07 02:28:43', '', 'Identity', '', 'trash', 'open', 'open', '', 'identity', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=75', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2014-05-07 02:28:43', '2014-05-07 02:28:43', '', 'Identity', '', 'inherit', 'open', 'open', '', '75-revision-v1', '', '', '2014-05-07 02:28:43', '2014-05-07 02:28:43', '', 75, 'http://localhost:8888/75-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2014-05-07 02:40:02', '2014-05-07 02:40:02', '<p>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
</p>
<p>
It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
</p>', 'Brookline College', '', 'inherit', 'open', 'open', '', '73-revision-v1', '', '', '2014-05-07 02:40:02', '2014-05-07 02:40:02', '', 73, 'http://localhost:8888/73-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2014-05-07 02:53:12', '2014-05-07 02:53:12', '[af-portfolio]', 'Work', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 02:53:12', '2014-05-07 02:53:12', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2014-05-07 03:08:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-07 03:08:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=80', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2014-05-07 03:10:01', '2014-05-07 03:10:01', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 03:10:01', '2014-05-07 03:10:01', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2014-05-07 03:12:04', '2014-05-07 03:12:04', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-150x150.png" alt="" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:12:04', '2014-05-07 03:12:04', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2014-05-07 03:13:35', '2014-05-07 03:13:35', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x300.png" alt="" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:13:35', '2014-05-07 03:13:35', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2014-05-07 03:14:22', '2014-05-07 03:14:22', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:14:22', '2014-05-07 03:14:22', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2014-05-07 03:14:57', '2014-05-07 03:14:57', '', 'Web Design', '', 'trash', 'open', 'open', '', 'web-design', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 91, 'http://localhost:8888/?page_id=85', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-05-07 03:14:57', '2014-05-07 03:14:57', '', 'Web Design', '', 'inherit', 'open', 'open', '', '85-revision-v1', '', '', '2014-05-07 03:14:57', '2014-05-07 03:14:57', '', 85, 'http://localhost:8888/85-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-05-07 03:15:29', '2014-05-07 03:15:29', '', 'Photography', '', 'trash', 'open', 'open', '', 'photography', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 91, 'http://localhost:8888/?page_id=87', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-05-07 03:15:29', '2014-05-07 03:15:29', '', 'Photography', '', 'inherit', 'open', 'open', '', '87-revision-v1', '', '', '2014-05-07 03:15:29', '2014-05-07 03:15:29', '', 87, 'http://localhost:8888/87-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-05-07 03:19:35', '2014-05-07 03:19:35', '', 'Portfolio', '', 'trash', 'open', 'open', '', 'portfolio', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 0, 'http://localhost:8888/?page_id=91', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-05-07 03:19:35', '2014-05-07 03:19:35', '', 'Portfolio', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2014-05-07 03:19:35', '2014-05-07 03:19:35', '', 91, 'http://localhost:8888/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-05-07 03:56:18', '2014-05-07 03:56:18', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:56:18', '2014-05-07 03:56:18', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-05-07 04:02:57', '2014-05-07 04:02:57', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 04:02:57', '2014-05-07 04:02:57', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-05-07 14:20:25', '2014-05-07 14:20:25', '', 'BC_Flyers', '', 'inherit', 'open', 'open', '', 'bc_flyers', '', '', '2014-05-07 14:20:25', '2014-05-07 14:20:25', '', 1, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-05-07 14:20:26', '2014-05-07 14:20:26', '', 'BC_Poster', '', 'inherit', 'open', 'open', '', 'bc_poster', '', '', '2014-05-07 14:20:26', '2014-05-07 14:20:26', '', 141, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Poster.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-05-07 14:20:29', '2014-05-07 14:20:29', '', 'BC_Homepage', '', 'inherit', 'open', 'open', '', 'bc_homepage', '', '', '2014-05-07 14:20:29', '2014-05-07 14:20:29', '', 148, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Homepage.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-05-07 14:20:30', '2014-05-07 14:20:30', '', 'BC_NewsAds', '', 'inherit', 'open', 'open', '', 'bc_newsads', '', '', '2014-05-07 14:20:30', '2014-05-07 14:20:30', '', 146, 'http://localhost:8888/wp-content/uploads/2014/05/BC_NewsAds.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-05-07 14:20:31', '2014-05-07 14:20:31', '', 'NG_Seminar', '', 'inherit', 'open', 'open', '', 'ng_seminar', '', '', '2014-05-07 14:20:31', '2014-05-07 14:20:31', '', 154, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-05-07 14:20:32', '2014-05-07 14:20:32', '', 'NG_Web', '', 'inherit', 'open', 'open', '', 'ng_web', '', '', '2014-05-07 14:20:32', '2014-05-07 14:20:32', '', 156, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Web.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-05-07 14:20:33', '2014-05-07 14:20:33', '', 'CS_Billboard', '', 'inherit', 'open', 'open', '', 'cs_billboard', '', '', '2014-05-07 14:20:33', '2014-05-07 14:20:33', '', 158, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-05-07 14:20:34', '2014-05-07 14:20:34', '', 'CS_Mag', '', 'inherit', 'open', 'open', '', 'cs_mag', '', '', '2014-05-07 14:20:34', '2014-05-07 14:20:34', '', 160, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Mag.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-05-07 14:20:35', '2014-05-07 14:20:35', '', 'HC_Flyer', '', 'inherit', 'open', 'open', '', 'hc_flyer', '', '', '2014-05-07 14:20:35', '2014-05-07 14:20:35', '', 162, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Flyer.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-05-07 14:20:36', '2014-05-07 14:20:36', '', 'LilWayne_Poster', '', 'inherit', 'open', 'open', '', 'lilwayne_poster', '', '', '2014-05-07 14:20:36', '2014-05-07 14:20:36', '', 164, 'http://localhost:8888/wp-content/uploads/2014/05/LilWayne_Poster.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2014-05-07 14:20:40', '2014-05-07 14:20:40', '', 'HC_Homepage', '', 'inherit', 'open', 'open', '', 'hc_homepage', '', '', '2014-05-07 14:20:40', '2014-05-07 14:20:40', '', 166, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Homepage.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2014-05-07 14:20:41', '2014-05-07 14:20:41', '', 'Label_MeatPackaging', '', 'inherit', 'open', 'open', '', 'label_meatpackaging', '', '', '2014-05-07 14:20:41', '2014-05-07 14:20:41', '', 168, 'http://localhost:8888/wp-content/uploads/2014/05/Label_MeatPackaging.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2014-05-07 14:20:42', '2014-05-07 14:20:42', '', 'Shirt_Millenium', '', 'inherit', 'open', 'open', '', 'shirt_millenium', '', '', '2014-05-07 14:20:42', '2014-05-07 14:20:42', '', 170, 'http://localhost:8888/wp-content/uploads/2014/05/Shirt_Millenium.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2014-05-07 14:20:43', '2014-05-07 14:20:43', '', 'Wine_TerraNova', '', 'inherit', 'open', 'open', '', 'wine_terranova', '', '', '2014-05-07 14:20:43', '2014-05-07 14:20:43', '', 172, 'http://localhost:8888/wp-content/uploads/2014/05/Wine_TerraNova.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2014-05-07 14:20:46', '2014-05-07 14:20:46', '', 'Wayfinding_Cart', '', 'inherit', 'open', 'open', '', 'wayfinding_cart', '', '', '2014-05-07 14:20:46', '2014-05-07 14:20:46', '', 174, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2014-05-07 14:20:47', '2014-05-07 14:20:47', '', 'TypeChronology', '', 'inherit', 'open', 'open', '', 'typechronology', '', '', '2014-05-07 14:20:47', '2014-05-07 14:20:47', '', 176, 'http://localhost:8888/wp-content/uploads/2014/05/TypeChronology.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2014-05-07 14:20:48', '2014-05-07 14:20:48', '', 'Wayfinding_App', '', 'inherit', 'open', 'open', '', 'wayfinding_app', '', '', '2014-05-07 14:20:48', '2014-05-07 14:20:48', '', 178, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_App.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2014-05-07 14:20:51', '2014-05-07 14:20:51', '', 'Windstar_Logo', '', 'inherit', 'open', 'open', '', 'windstar_logo', '', '', '2014-05-07 14:20:51', '2014-05-07 14:20:51', '', 180, 'http://localhost:8888/wp-content/uploads/2014/05/Windstar_Logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-05-07 14:21:07', '2014-05-07 14:21:07', '', 'BC_Homepage_TN', '', 'inherit', 'open', 'open', '', 'bc_homepage_tn', '', '', '2014-05-07 14:21:07', '2014-05-07 14:21:07', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Homepage_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2014-05-07 14:21:08', '2014-05-07 14:21:08', '', 'BC_Flyers_TN', '', 'inherit', 'open', 'open', '', 'bc_flyers_tn', '', '', '2014-05-07 14:21:08', '2014-05-07 14:21:08', '', 8, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-05-07 14:21:09', '2014-05-07 14:21:09', '', 'BC_NewsAds_TN', '', 'inherit', 'open', 'open', '', 'bc_newsads_tn', '', '', '2014-05-07 14:21:09', '2014-05-07 14:21:09', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BC_NewsAds_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2014-05-07 14:21:10', '2014-05-07 14:21:10', '', 'BC_Poster_TN', '', 'inherit', 'open', 'open', '', 'bc_poster_tn', '', '', '2014-05-07 14:21:10', '2014-05-07 14:21:10', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Poster_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-05-07 14:21:11', '2014-05-07 14:21:11', '', 'NG_Seminar_TN', '', 'inherit', 'open', 'open', '', 'ng_seminar_tn', '', '', '2014-05-07 14:21:11', '2014-05-07 14:21:11', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-05-07 14:21:12', '2014-05-07 14:21:12', '', 'CS_Mag_TN', '', 'inherit', 'open', 'open', '', 'cs_mag_tn', '', '', '2014-05-07 14:21:12', '2014-05-07 14:21:12', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Mag_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2014-05-07 14:21:13', '2014-05-07 14:21:13', '', 'CS_Billboard_TN', '', 'inherit', 'open', 'open', '', 'cs_billboard_tn', '', '', '2014-05-07 14:21:13', '2014-05-07 14:21:13', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2014-05-07 14:21:14', '2014-05-07 14:21:14', '', 'NG_Web_TN', '', 'inherit', 'open', 'open', '', 'ng_web_tn', '', '', '2014-05-07 14:21:14', '2014-05-07 14:21:14', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Web_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 'HC_Flyer_TN', '', 'inherit', 'open', 'open', '', 'hc_flyer_tn', '', '', '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Flyer_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 'HC_Homepage_TN', '', 'inherit', 'open', 'open', '', 'hc_homepage_tn', '', '', '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Homepage_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2014-05-07 14:21:16', '2014-05-07 14:21:16', '', 'LilWayne_Poster_TN', '', 'inherit', 'open', 'open', '', 'lilwayne_poster_tn', '', '', '2014-05-07 14:21:16', '2014-05-07 14:21:16', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LilWayne_Poster_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2014-05-07 14:21:17', '2014-05-07 14:21:17', '', 'Label_MeatPackaging_TN', '', 'inherit', 'open', 'open', '', 'label_meatpackaging_tn', '', '', '2014-05-07 14:21:17', '2014-05-07 14:21:17', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Label_MeatPackaging_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2014-05-07 14:21:18', '2014-05-07 14:21:18', '', 'Shirt_Millenium_TN', '', 'inherit', 'open', 'open', '', 'shirt_millenium_tn', '', '', '2014-05-07 14:21:18', '2014-05-07 14:21:18', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Shirt_Millenium_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-05-07 14:21:19', '2014-05-07 14:21:19', '', 'Wine_TerraNova_TN', '', 'inherit', 'open', 'open', '', 'wine_terranova_tn', '', '', '2014-05-07 14:21:19', '2014-05-07 14:21:19', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Wine_TerraNova_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 'TypeChronology_TN', '', 'inherit', 'open', 'open', '', 'typechronology_tn', '', '', '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/TypeChronology_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 'Wayfinding_Cart_TN', '', 'inherit', 'open', 'open', '', 'wayfinding_cart_tn', '', '', '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2014-05-07 14:21:22', '2014-05-07 14:21:22', '', 'Wayfinding_App_TN', '', 'inherit', 'open', 'open', '', 'wayfinding_app_tn', '', '', '2014-05-07 14:21:22', '2014-05-07 14:21:22', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_App_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2014-05-07 14:21:23', '2014-05-07 14:21:23', '', 'Windstar_Logo_TN', '', 'inherit', 'open', 'open', '', 'windstar_logo_tn', '', '', '2014-05-07 14:21:23', '2014-05-07 14:21:23', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Windstar_Logo_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2014-05-08 03:10:29', '2014-05-08 03:10:29', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<di
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-autosave-v1', '', '', '2014-05-08 03:10:29', '2014-05-08 03:10:29', '', 1, 'http://localhost:8888/1-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (136, 1, '2014-05-07 14:25:56', '2014-05-07 14:25:56', '<p>I designed these flyers while working at my internship at Brookline College. They were intended to promote the new programs available to students and once completed were hung around the several campuses around the valley.</p> 

<p>Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 14:25:56', '2014-05-07 14:25:56', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (137, 1, '2014-05-07 14:26:50', '2014-05-07 14:26:50', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers_TN.png" alt="BC_Flyers_TN" width="360" height="360" class="alignnone size-full wp-image-118" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 14:26:50', '2014-05-07 14:26:50', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (138, 1, '2014-05-07 14:31:12', '2014-05-07 14:31:12', '<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p>Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 14:31:12', '2014-05-07 14:31:12', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2014-05-07 14:32:24', '2014-05-07 14:32:24', '<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 14:32:24', '2014-05-07 14:32:24', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2014-05-07 14:38:16', '2014-05-07 14:38:16', '', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 14:38:16', '2014-05-07 14:38:16', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2014-05-08 01:37:20', '2014-05-08 01:37:20', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'publish', 'open', 'open', '', 'brookline-college-poster', '', '', '2014-05-09 04:19:54', '2014-05-09 04:19:54', '', 0, 'http://localhost:8888/?p=141', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (142, 1, '2014-05-08 01:37:20', '2014-05-08 01:37:20', '', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-revision-v1', '', '', '2014-05-08 01:37:20', '2014-05-08 01:37:20', '', 141, 'http://localhost:8888/141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (143, 1, '2014-05-08 01:39:24', '2014-05-08 01:39:24', ' ', '', '', 'publish', 'open', 'open', '', '143', '', '', '2014-05-08 01:41:43', '2014-05-08 01:41:43', '', 0, 'http://localhost:8888/?p=143', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (144, 1, '2014-05-08 01:41:44', '2014-05-08 01:41:44', ' ', '', '', 'publish', 'open', 'open', '', '144', '', '', '2014-05-08 01:41:44', '2014-05-08 01:41:44', '', 0, 'http://localhost:8888/?p=144', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2014-05-08 01:41:44', '2014-05-08 01:41:44', ' ', '', '', 'publish', 'open', 'open', '', '145', '', '', '2014-05-08 01:41:44', '2014-05-08 01:41:44', '', 0, 'http://localhost:8888/?p=145', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2014-05-08 01:45:09', '2014-05-08 01:45:09', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_NewsAds.png" alt="BC_NewsAds" width="580" height="486" class="alignnone size-full wp-image-102" /></div>

<div class="post-description">
<h1>Brookline College Advertisements</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Advertisements', '', 'publish', 'open', 'open', '', 'brookline-college-ads', '', '', '2014-05-09 04:19:43', '2014-05-09 04:19:43', '', 0, 'http://localhost:8888/?p=146', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2014-05-08 01:45:09', '2014-05-08 01:45:09', '', 'Brookline College Ads', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-08 01:45:09', '2014-05-08 01:45:09', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (148, 1, '2014-05-08 02:13:07', '2014-05-08 02:13:07', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Homepage.png" alt="BC_Homepage" width="992" height="410" class="alignnone size-full wp-image-101" /></div>

<div class="post-description">
<h1>Brookline College Graphics</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Brookline College Graphics', '', 'publish', 'open', 'open', '', 'brookline-college-graphics', '', '', '2014-05-09 04:15:23', '2014-05-09 04:15:23', '', 0, 'http://localhost:8888/?p=148', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2014-05-08 02:13:07', '2014-05-08 02:13:07', '', 'Brookline College Graphics', '', 'inherit', 'open', 'open', '', '148-revision-v1', '', '', '2014-05-08 02:13:07', '2014-05-08 02:13:07', '', 148, 'http://localhost:8888/148-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2014-05-08 03:09:26', '2014-05-08 03:09:26', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:09:26', '2014-05-08 03:09:26', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (151, 1, '2014-05-08 03:11:03', '2014-05-08 03:11:03', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:11:03', '2014-05-08 03:11:03', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (152, 1, '2014-05-08 03:11:16', '2014-05-08 03:11:16', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:11:16', '2014-05-08 03:11:16', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (153, 1, '2014-05-08 03:12:10', '2014-05-08 03:12:10', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Brookline College Flyers</h1>
<hr class="content-title-rule">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:12:10', '2014-05-08 03:12:10', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2014-05-08 13:13:35', '2014-05-08 13:13:35', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'publish', 'open', 'open', '', 'next-generation-itinerary', '', '', '2014-05-09 04:19:22', '2014-05-09 04:19:22', '', 0, 'http://localhost:8888/?p=154', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (155, 1, '2014-05-08 13:13:35', '2014-05-08 13:13:35', '', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-05-08 13:13:35', '2014-05-08 13:13:35', '', 154, 'http://localhost:8888/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (156, 1, '2014-05-08 13:17:36', '2014-05-08 13:17:36', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Web.png" alt="NG_Web" width="1000" height="691" class="alignnone size-full wp-image-104" /></div>

<div class="post-description">
<h1>Next Generation<br>Registration Form</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Next Generation Registration Form', '', 'publish', 'open', 'open', '', 'next-generation-registration-form', '', '', '2014-05-09 04:14:26', '2014-05-09 04:14:26', '', 0, 'http://localhost:8888/?p=156', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (157, 1, '2014-05-08 13:17:36', '2014-05-08 13:17:36', '', 'Next Generation Registration Form', '', 'inherit', 'open', 'open', '', '156-revision-v1', '', '', '2014-05-08 13:17:36', '2014-05-08 13:17:36', '', 156, 'http://localhost:8888/156-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (158, 1, '2014-05-08 13:18:28', '2014-05-08 13:18:28', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Billboard', '', 'publish', 'open', 'open', '', 'calsium-billboard', '', '', '2014-05-09 04:19:14', '2014-05-09 04:19:14', '', 0, 'http://localhost:8888/?p=158', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (159, 1, '2014-05-08 13:18:28', '2014-05-08 13:18:28', '', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-08 13:18:28', '2014-05-08 13:18:28', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (160, 1, '2014-05-08 13:18:57', '2014-05-08 13:18:57', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Mag.png" alt="CS_Mag" width="1000" height="682" class="alignnone size-full wp-image-106" /></div>

<div class="post-description">
<h1>calsium Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Advertisement', '', 'publish', 'open', 'open', '', 'calsium-magazine-ad', '', '', '2014-05-09 04:18:41', '2014-05-09 04:18:41', '', 0, 'http://localhost:8888/?p=160', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (161, 1, '2014-05-08 13:18:57', '2014-05-08 13:18:57', '', 'calsium Magazine Ad', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-08 13:18:57', '2014-05-08 13:18:57', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (162, 1, '2014-05-08 13:20:35', '2014-05-08 13:20:35', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Flyer.png" alt="HC_Flyer" width="1000" height="597" class="alignnone size-full wp-image-107" /></div>

<div class="post-description">
<h1>HomeCure Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'HomeCure Advertisement', '', 'publish', 'open', 'open', '', 'homecure-multi-page-advertisement', '', '', '2014-05-09 04:18:24', '2014-05-09 04:18:24', '', 0, 'http://localhost:8888/?p=162', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (163, 1, '2014-05-08 13:20:35', '2014-05-08 13:20:35', '', 'HomeCure Multi-Page Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-08 13:20:35', '2014-05-08 13:20:35', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (164, 1, '2014-05-08 13:21:06', '2014-05-08 13:21:06', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/LilWayne_Poster.png" alt="LilWayne_Poster" width="1000" height="1187" class="alignnone size-full wp-image-108" /></div>

<div class="post-description">
<h1>Concert Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Concert Poster', '', 'publish', 'open', 'open', '', 'concert-poster', '', '', '2014-05-09 04:18:10', '2014-05-09 04:18:10', '', 0, 'http://localhost:8888/?p=164', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (165, 1, '2014-05-08 13:21:06', '2014-05-08 13:21:06', '', 'Concert Poster', '', 'inherit', 'open', 'open', '', '164-revision-v1', '', '', '2014-05-08 13:21:06', '2014-05-08 13:21:06', '', 164, 'http://localhost:8888/164-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (166, 1, '2014-05-08 13:22:16', '2014-05-08 13:22:16', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Homepage.png" alt="HC_Homepage" width="1000" height="594" class="alignnone size-full wp-image-109" /></div>

<div class="post-description">
<h1>HomeCure Website</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'HomeCure Website', '', 'publish', 'open', 'open', '', 'homecure-website', '', '', '2014-05-09 04:12:23', '2014-05-09 04:12:23', '', 0, 'http://localhost:8888/?p=166', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (167, 1, '2014-05-08 13:22:16', '2014-05-08 13:22:16', '', 'HomeCure Website', '', 'inherit', 'open', 'open', '', '166-revision-v1', '', '', '2014-05-08 13:22:16', '2014-05-08 13:22:16', '', 166, 'http://localhost:8888/166-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (168, 1, '2014-05-08 13:22:50', '2014-05-08 13:22:50', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Label_MeatPackaging.png" alt="Label_MeatPackaging" width="862" height="750" class="alignnone size-full wp-image-110" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'publish', 'open', 'open', '', 'meat-package-label', '', '', '2014-05-09 04:17:56', '2014-05-09 04:17:56', '', 0, 'http://localhost:8888/?p=168', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (169, 1, '2014-05-08 13:22:50', '2014-05-08 13:22:50', '', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-08 13:22:50', '2014-05-08 13:22:50', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (170, 1, '2014-05-08 13:23:49', '2014-05-08 13:23:49', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Shirt_Millenium.png" alt="Shirt_Millenium" width="675" height="882" class="alignnone size-full wp-image-111" /></div>

<div class="post-description">
<h1>Millennium Shirt</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Millennium Shirt', '', 'publish', 'open', 'open', '', 'millennium-shirt', '', '', '2014-05-09 04:17:33', '2014-05-09 04:17:33', '', 0, 'http://localhost:8888/?p=170', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (171, 1, '2014-05-08 13:23:49', '2014-05-08 13:23:49', '', 'Millennium Shirt', '', 'inherit', 'open', 'open', '', '170-revision-v1', '', '', '2014-05-08 13:23:49', '2014-05-08 13:23:49', '', 170, 'http://localhost:8888/170-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (172, 1, '2014-05-08 13:24:27', '2014-05-08 13:24:27', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wine_TerraNova.png" alt="Wine_TerraNova" width="1000" height="1191" class="alignnone size-full wp-image-112" /></div>

<div class="post-description">
<h1>Terra Nova Wine Bottle</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Terra Nova Wine Bottle', '', 'publish', 'open', 'open', '', 'terra-nova-wine-bottle', '', '', '2014-05-09 04:17:18', '2014-05-09 04:17:18', '', 0, 'http://localhost:8888/?p=172', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (173, 1, '2014-05-08 13:24:27', '2014-05-08 13:24:27', '', 'Terra Nova Wine Bottle', '', 'inherit', 'open', 'open', '', '172-revision-v1', '', '', '2014-05-08 13:24:27', '2014-05-08 13:24:27', '', 172, 'http://localhost:8888/172-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (174, 1, '2014-05-08 13:24:58', '2014-05-08 13:24:58', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Grocery Store Wayfinding', '', 'publish', 'open', 'open', '', 'grocery-store-wayfinding', '', '', '2014-05-09 04:17:03', '2014-05-09 04:17:03', '', 0, 'http://localhost:8888/?p=174', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (175, 1, '2014-05-08 13:24:58', '2014-05-08 13:24:58', '', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-revision-v1', '', '', '2014-05-08 13:24:58', '2014-05-08 13:24:58', '', 174, 'http://localhost:8888/174-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (176, 1, '2014-05-08 13:25:33', '2014-05-08 13:25:33', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/TypeChronology.png" alt="TypeChronology" width="1000" height="564" class="alignnone size-full wp-image-114" /></div>

<div class="post-description">
<h1>Type Chronology</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Type Chronology', '', 'publish', 'open', 'open', '', 'type-chronology', '', '', '2014-05-09 04:16:49', '2014-05-09 04:16:49', '', 0, 'http://localhost:8888/?p=176', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (177, 1, '2014-05-08 13:25:33', '2014-05-08 13:25:33', '', 'Type Chronology', '', 'inherit', 'open', 'open', '', '176-revision-v1', '', '', '2014-05-08 13:25:33', '2014-05-08 13:25:33', '', 176, 'http://localhost:8888/176-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (178, 1, '2014-05-08 13:26:04', '2014-05-08 13:26:04', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_App.png" alt="Wayfinding_App" width="1000" height="1152" class="alignnone size-full wp-image-115" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding App</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Grocery Store Wayfinding App', '', 'publish', 'open', 'open', '', 'grocery-store-wayfinding-app', '', '', '2014-05-09 04:11:07', '2014-05-09 04:11:07', '', 0, 'http://localhost:8888/?p=178', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (179, 1, '2014-05-08 13:26:04', '2014-05-08 13:26:04', '', 'Grocery Store Wayfinding App', '', 'inherit', 'open', 'open', '', '178-revision-v1', '', '', '2014-05-08 13:26:04', '2014-05-08 13:26:04', '', 178, 'http://localhost:8888/178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (180, 1, '2014-05-08 13:26:28', '2014-05-08 13:26:28', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Windstar_Logo.png" alt="Windstar_Logo" width="868" height="569" class="alignnone size-full wp-image-116" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'publish', 'open', 'open', '', 'windstar-logo', '', '', '2014-05-09 04:16:35', '2014-05-09 04:16:35', '', 0, 'http://localhost:8888/?p=180', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (181, 1, '2014-05-08 13:26:28', '2014-05-08 13:26:28', '', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-08 13:26:28', '2014-05-08 13:26:28', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (182, 1, '2014-05-08 13:27:51', '2014-05-08 13:27:51', '', 'HomeCure Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-08 13:27:51', '2014-05-08 13:27:51', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (183, 1, '2014-05-08 13:28:28', '2014-05-08 13:28:28', '', 'calsium Advertisement', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-08 13:28:28', '2014-05-08 13:28:28', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (184, 1, '2014-05-08 13:29:03', '2014-05-08 13:29:03', '', 'Brookline College Advertisements', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-08 13:29:03', '2014-05-08 13:29:03', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (185, 1, '2014-05-09 03:45:34', '2014-05-09 03:45:34', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-09 03:45:34', '2014-05-09 03:45:34', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (186, 1, '2014-05-09 03:46:38', '2014-05-09 03:46:38', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/TypeChronology.png" alt="TypeChronology" width="1000" height="564" class="alignnone size-full wp-image-114" /></div>

<div class="post-description">
<h1>Type Chronology</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Type Chronology', '', 'inherit', 'open', 'open', '', '176-revision-v1', '', '', '2014-05-09 03:46:38', '2014-05-09 03:46:38', '', 176, 'http://localhost:8888/176-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (187, 1, '2014-05-09 03:47:11', '2014-05-09 03:47:11', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Windstar_Logo.png" alt="Windstar_Logo" width="868" height="569" class="alignnone size-full wp-image-116" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-09 03:47:11', '2014-05-09 03:47:11', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (188, 1, '2014-05-09 03:55:25', '2014-05-09 03:55:25', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-autosave-v1', '', '', '2014-05-09 03:55:25', '2014-05-09 03:55:25', '', 174, 'http://localhost:8888/174-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (189, 1, '2014-05-09 03:55:59', '2014-05-09 03:55:59', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-revision-v1', '', '', '2014-05-09 03:55:59', '2014-05-09 03:55:59', '', 174, 'http://localhost:8888/174-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (190, 1, '2014-05-09 03:57:10', '2014-05-09 03:57:10', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wine_TerraNova.png" alt="Wine_TerraNova" width="1000" height="1191" class="alignnone size-full wp-image-112" /></div>

<div class="post-description">
<h1>Terra Nova Wine Bottle</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Terra Nova Wine Bottle', '', 'inherit', 'open', 'open', '', '172-revision-v1', '', '', '2014-05-09 03:57:10', '2014-05-09 03:57:10', '', 172, 'http://localhost:8888/172-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (191, 1, '2014-05-09 03:58:25', '2014-05-09 03:58:25', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Shirt_Millenium.png" alt="Shirt_Millenium" width="675" height="882" class="alignnone size-full wp-image-111" /></div>

<div class="post-description">
<h1>Millennium Shirt</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Millennium Shirt', '', 'inherit', 'open', 'open', '', '170-revision-v1', '', '', '2014-05-09 03:58:25', '2014-05-09 03:58:25', '', 170, 'http://localhost:8888/170-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (192, 1, '2014-05-09 03:59:29', '2014-05-09 03:59:29', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-09 03:59:29', '2014-05-09 03:59:29', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (193, 1, '2014-05-09 03:59:58', '2014-05-09 03:59:58', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Label_MeatPackaging.png" alt="Label_MeatPackaging" width="862" height="750" class="alignnone size-full wp-image-110" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-09 03:59:58', '2014-05-09 03:59:58', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (194, 1, '2014-05-09 04:01:08', '2014-05-09 04:01:08', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/LilWayne_Poster.png" alt="LilWayne_Poster" width="1000" height="1187" class="alignnone size-full wp-image-108" /></div>

<div class="post-description">
<h1>Concert Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Concert Poster', '', 'inherit', 'open', 'open', '', '164-revision-v1', '', '', '2014-05-09 04:01:08', '2014-05-09 04:01:08', '', 164, 'http://localhost:8888/164-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (195, 1, '2014-05-09 04:02:19', '2014-05-09 04:02:19', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/HC_Flyer.png" alt="HC_Flyer" width="1000" height="597" class="alignnone size-full wp-image-107" /></div>

<div class="post-description">
<h1>HomeCure Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'HomeCure Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-09 04:02:19', '2014-05-09 04:02:19', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (196, 1, '2014-05-09 04:03:26', '2014-05-09 04:03:26', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/CS_Mag.png" alt="CS_Mag" width="1000" height="682" class="alignnone size-full wp-image-106" /></div>

<div class="post-description">
<h1>calsium Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Advertisement', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-09 04:03:26', '2014-05-09 04:03:26', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (197, 1, '2014-05-09 04:04:17', '2014-05-09 04:04:17', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-09 04:04:17', '2014-05-09 04:04:17', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (198, 1, '2014-05-09 04:06:01', '2014-05-09 04:06:01', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-autosave-v1', '', '', '2014-05-09 04:06:01', '2014-05-09 04:06:01', '', 154, 'http://localhost:8888/154-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (199, 1, '2014-05-09 04:06:08', '2014-05-09 04:06:08', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-05-09 04:06:08', '2014-05-09 04:06:08', '', 154, 'http://localhost:8888/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (200, 1, '2014-05-09 04:07:21', '2014-05-09 04:07:21', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-09 04:07:21', '2014-05-09 04:07:21', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (201, 1, '2014-05-09 04:08:44', '2014-05-09 04:08:44', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_NewsAds.png" alt="BC_NewsAds" width="580" height="486" class="alignnone size-full wp-image-102" /></div>

<div class="post-description">
<h1>Brookline College Advertisements</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Advertisements', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-09 04:08:44', '2014-05-09 04:08:44', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (202, 1, '2014-05-09 04:09:47', '2014-05-09 04:09:47', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-revision-v1', '', '', '2014-05-09 04:09:47', '2014-05-09 04:09:47', '', 141, 'http://localhost:8888/141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (203, 1, '2014-05-09 04:10:56', '2014-05-09 04:10:56', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_App.png" alt="Wayfinding_App" width="1000" height="1152" class="alignnone size-full wp-image-115" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding App</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Grocery Store Wayfinding App', '', 'inherit', 'open', 'open', '', '178-revision-v1', '', '', '2014-05-09 04:10:56', '2014-05-09 04:10:56', '', 178, 'http://localhost:8888/178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (204, 1, '2014-05-09 04:11:07', '2014-05-09 04:11:07', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_App.png" alt="Wayfinding_App" width="1000" height="1152" class="alignnone size-full wp-image-115" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding App</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Grocery Store Wayfinding App', '', 'inherit', 'open', 'open', '', '178-revision-v1', '', '', '2014-05-09 04:11:07', '2014-05-09 04:11:07', '', 178, 'http://localhost:8888/178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (205, 1, '2014-05-09 04:12:23', '2014-05-09 04:12:23', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Homepage.png" alt="HC_Homepage" width="1000" height="594" class="alignnone size-full wp-image-109" /></div>

<div class="post-description">
<h1>HomeCure Website</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'HomeCure Website', '', 'inherit', 'open', 'open', '', '166-revision-v1', '', '', '2014-05-09 04:12:23', '2014-05-09 04:12:23', '', 166, 'http://localhost:8888/166-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (206, 1, '2014-05-09 04:14:02', '2014-05-09 04:14:02', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Web.png" alt="NG_Web" width="1000" height="691" class="alignnone size-full wp-image-104" /></div>

<div class="post-description">
<h1>Next Generation Registration Form</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Next Generation Registration Form', '', 'inherit', 'open', 'open', '', '156-revision-v1', '', '', '2014-05-09 04:14:02', '2014-05-09 04:14:02', '', 156, 'http://localhost:8888/156-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (207, 1, '2014-05-09 04:14:26', '2014-05-09 04:14:26', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Web.png" alt="NG_Web" width="1000" height="691" class="alignnone size-full wp-image-104" /></div>

<div class="post-description">
<h1>Next Generation<br>Registration Form</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Next Generation Registration Form', '', 'inherit', 'open', 'open', '', '156-revision-v1', '', '', '2014-05-09 04:14:26', '2014-05-09 04:14:26', '', 156, 'http://localhost:8888/156-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (208, 1, '2014-05-09 04:15:23', '2014-05-09 04:15:23', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Homepage.png" alt="BC_Homepage" width="992" height="410" class="alignnone size-full wp-image-101" /></div>

<div class="post-description">
<h1>Brookline College Graphics</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Brookline College Graphics', '', 'inherit', 'open', 'open', '', '148-revision-v1', '', '', '2014-05-09 04:15:23', '2014-05-09 04:15:23', '', 148, 'http://localhost:8888/148-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (209, 1, '2014-05-09 04:15:59', '2014-05-09 04:15:59', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Brookline College Flyers</h1>
<hr class="content-title-rule">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-09 04:15:59', '2014-05-09 04:15:59', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (210, 1, '2014-05-09 04:16:35', '2014-05-09 04:16:35', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Windstar_Logo.png" alt="Windstar_Logo" width="868" height="569" class="alignnone size-full wp-image-116" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-09 04:16:35', '2014-05-09 04:16:35', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (211, 1, '2014-05-09 04:16:49', '2014-05-09 04:16:49', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/TypeChronology.png" alt="TypeChronology" width="1000" height="564" class="alignnone size-full wp-image-114" /></div>

<div class="post-description">
<h1>Type Chronology</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Type Chronology', '', 'inherit', 'open', 'open', '', '176-revision-v1', '', '', '2014-05-09 04:16:49', '2014-05-09 04:16:49', '', 176, 'http://localhost:8888/176-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (212, 1, '2014-05-09 04:17:03', '2014-05-09 04:17:03', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-revision-v1', '', '', '2014-05-09 04:17:03', '2014-05-09 04:17:03', '', 174, 'http://localhost:8888/174-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (213, 1, '2014-05-09 04:17:18', '2014-05-09 04:17:18', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wine_TerraNova.png" alt="Wine_TerraNova" width="1000" height="1191" class="alignnone size-full wp-image-112" /></div>

<div class="post-description">
<h1>Terra Nova Wine Bottle</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Terra Nova Wine Bottle', '', 'inherit', 'open', 'open', '', '172-revision-v1', '', '', '2014-05-09 04:17:18', '2014-05-09 04:17:18', '', 172, 'http://localhost:8888/172-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (214, 1, '2014-05-09 04:17:33', '2014-05-09 04:17:33', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Shirt_Millenium.png" alt="Shirt_Millenium" width="675" height="882" class="alignnone size-full wp-image-111" /></div>

<div class="post-description">
<h1>Millennium Shirt</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Millennium Shirt', '', 'inherit', 'open', 'open', '', '170-revision-v1', '', '', '2014-05-09 04:17:33', '2014-05-09 04:17:33', '', 170, 'http://localhost:8888/170-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (215, 1, '2014-05-09 04:17:56', '2014-05-09 04:17:56', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Label_MeatPackaging.png" alt="Label_MeatPackaging" width="862" height="750" class="alignnone size-full wp-image-110" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-09 04:17:56', '2014-05-09 04:17:56', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (216, 1, '2014-05-09 04:18:10', '2014-05-09 04:18:10', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/LilWayne_Poster.png" alt="LilWayne_Poster" width="1000" height="1187" class="alignnone size-full wp-image-108" /></div>

<div class="post-description">
<h1>Concert Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Concert Poster', '', 'inherit', 'open', 'open', '', '164-revision-v1', '', '', '2014-05-09 04:18:10', '2014-05-09 04:18:10', '', 164, 'http://localhost:8888/164-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (217, 1, '2014-05-09 04:18:24', '2014-05-09 04:18:24', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Flyer.png" alt="HC_Flyer" width="1000" height="597" class="alignnone size-full wp-image-107" /></div>

<div class="post-description">
<h1>HomeCure Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'HomeCure Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-09 04:18:24', '2014-05-09 04:18:24', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (218, 1, '2014-05-09 04:18:41', '2014-05-09 04:18:41', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Mag.png" alt="CS_Mag" width="1000" height="682" class="alignnone size-full wp-image-106" /></div>

<div class="post-description">
<h1>calsium Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Advertisement', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-09 04:18:41', '2014-05-09 04:18:41', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (219, 1, '2014-05-09 04:19:14', '2014-05-09 04:19:14', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-09 04:19:14', '2014-05-09 04:19:14', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (220, 1, '2014-05-09 04:19:22', '2014-05-09 04:19:22', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-05-09 04:19:22', '2014-05-09 04:19:22', '', 154, 'http://localhost:8888/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (221, 1, '2014-05-09 04:19:43', '2014-05-09 04:19:43', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_NewsAds.png" alt="BC_NewsAds" width="580" height="486" class="alignnone size-full wp-image-102" /></div>

<div class="post-description">
<h1>Brookline College Advertisements</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Advertisements', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-09 04:19:43', '2014-05-09 04:19:43', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (222, 1, '2014-05-09 04:19:54', '2014-05-09 04:19:54', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-revision-v1', '', '', '2014-05-09 04:19:54', '2014-05-09 04:19:54', '', 141, 'http://localhost:8888/141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (223, 1, '2014-05-09 04:39:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-09 04:39:25', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=223', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (224, 1, '2014-05-09 04:39:34', '2014-05-09 04:39:34', '', 'Maintenance', '', 'inherit', 'open', 'open', '', 'maintenance', '', '', '2014-05-09 04:39:34', '2014-05-09 04:39:34', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Maintenance.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (225, 1, '2014-05-09 13:51:21', '2014-05-09 13:51:21', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira1.jpg" alt="BraylonKeira1" width="1000" height="662" class="alignnone size-full wp-image-227" /></div>

<div class="post-description">
<h1>Neworn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn', '', '', '2014-05-09 13:53:57', '2014-05-09 13:53:57', '', 0, 'http://localhost:8888/?p=225', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (226, 1, '2014-05-09 13:47:09', '2014-05-09 13:47:09', '', 'Arch', '', 'inherit', 'open', 'open', '', 'arch', '', '', '2014-05-09 13:47:09', '2014-05-09 13:47:09', '', 251, 'http://localhost:8888/wp-content/uploads/2014/05/Arch.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (227, 1, '2014-05-09 13:47:12', '2014-05-09 13:47:12', '', 'BraylonKeira1', '', 'inherit', 'open', 'open', '', 'braylonkeira1', '', '', '2014-05-09 13:47:12', '2014-05-09 13:47:12', '', 225, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (228, 1, '2014-05-09 13:48:22', '2014-05-09 13:48:22', '', 'Water', '', 'inherit', 'open', 'open', '', 'water', '', '', '2014-05-09 13:48:22', '2014-05-09 13:48:22', '', 253, 'http://localhost:8888/wp-content/uploads/2014/05/Water.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (229, 1, '2014-05-09 13:48:23', '2014-05-09 13:48:23', '', 'LightRail', '', 'inherit', 'open', 'open', '', 'lightrail', '', '', '2014-05-09 13:48:23', '2014-05-09 13:48:23', '', 257, 'http://localhost:8888/wp-content/uploads/2014/05/LightRail.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (230, 1, '2014-05-09 13:48:24', '2014-05-09 13:48:24', '', 'Cactus', '', 'inherit', 'open', 'open', '', 'cactus', '', '', '2014-05-09 13:48:24', '2014-05-09 13:48:24', '', 255, 'http://localhost:8888/wp-content/uploads/2014/05/Cactus.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (231, 1, '2014-05-09 13:48:28', '2014-05-09 13:48:28', '', 'BraylonKeira4', '', 'inherit', 'open', 'open', '', 'braylonkeira4', '', '', '2014-05-09 13:48:28', '2014-05-09 13:48:28', '', 249, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (232, 1, '2014-05-09 13:48:29', '2014-05-09 13:48:29', '', 'BraylonKeira3', '', 'inherit', 'open', 'open', '', 'braylonkeira3', '', '', '2014-05-09 13:48:29', '2014-05-09 13:48:29', '', 247, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (233, 1, '2014-05-09 13:48:31', '2014-05-09 13:48:31', '', 'BraylonKeira2', '', 'inherit', 'open', 'open', '', 'braylonkeira2', '', '', '2014-05-09 13:48:31', '2014-05-09 13:48:31', '', 243, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (234, 1, '2014-05-09 13:49:45', '2014-05-09 13:49:45', '', 'Water_TN', '', 'inherit', 'open', 'open', '', 'water_tn', '', '', '2014-05-09 13:49:45', '2014-05-09 13:49:45', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Water_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (235, 1, '2014-05-09 13:49:46', '2014-05-09 13:49:46', '', 'LightRail_TN', '', 'inherit', 'open', 'open', '', 'lightrail_tn', '', '', '2014-05-09 13:49:46', '2014-05-09 13:49:46', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LightRail_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (236, 1, '2014-05-09 13:49:47', '2014-05-09 13:49:47', '', 'Cactus_TN', '', 'inherit', 'open', 'open', '', 'cactus_tn', '', '', '2014-05-09 13:49:47', '2014-05-09 13:49:47', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Cactus_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (237, 1, '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 'Arch_TN', '', 'inherit', 'open', 'open', '', 'arch_tn', '', '', '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Arch_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (238, 1, '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 'BraylonKeira4_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira4_tn', '', '', '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (239, 1, '2014-05-09 13:49:49', '2014-05-09 13:49:49', '', 'BraylonKeira3_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira3_tn', '', '', '2014-05-09 13:49:49', '2014-05-09 13:49:49', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (240, 1, '2014-05-09 13:49:50', '2014-05-09 13:49:50', '', 'BraylonKeira2_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira2_tn', '', '', '2014-05-09 13:49:50', '2014-05-09 13:49:50', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira2_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (241, 1, '2014-05-09 13:49:51', '2014-05-09 13:49:51', '', 'BraylonKeira1_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira1_tn', '', '', '2014-05-09 13:49:51', '2014-05-09 13:49:51', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira1_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (242, 1, '2014-05-09 13:51:21', '2014-05-09 13:51:21', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira1.jpg" alt="BraylonKeira1" width="1000" height="662" class="alignnone size-full wp-image-227" /></div>

<div class="post-description">
<h1>Neworn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '225-revision-v1', '', '', '2014-05-09 13:51:21', '2014-05-09 13:51:21', '', 225, 'http://localhost:8888/225-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (243, 1, '2014-05-09 13:53:16', '2014-05-09 13:53:16', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira2.jpg" alt="BraylonKeira2" width="1000" height="662" class="alignnone size-full wp-image-233" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn-2', '', '', '2014-05-09 13:53:31', '2014-05-09 13:53:31', '', 0, 'http://localhost:8888/?p=243', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (244, 1, '2014-05-09 13:53:16', '2014-05-09 13:53:16', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira2.jpg" alt="BraylonKeira2" width="1000" height="662" class="alignnone size-full wp-image-233" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '243-revision-v1', '', '', '2014-05-09 13:53:16', '2014-05-09 13:53:16', '', 243, 'http://localhost:8888/243-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (245, 1, '2014-05-09 13:53:31', '2014-05-09 13:53:31', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira2.jpg" alt="BraylonKeira2" width="1000" height="662" class="alignnone size-full wp-image-233" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '243-revision-v1', '', '', '2014-05-09 13:53:31', '2014-05-09 13:53:31', '', 243, 'http://localhost:8888/243-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (246, 1, '2014-05-09 13:53:57', '2014-05-09 13:53:57', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira1.jpg" alt="BraylonKeira1" width="1000" height="662" class="alignnone size-full wp-image-227" /></div>

<div class="post-description">
<h1>Neworn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '225-revision-v1', '', '', '2014-05-09 13:53:57', '2014-05-09 13:53:57', '', 225, 'http://localhost:8888/225-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (247, 1, '2014-05-09 13:54:46', '2014-05-09 13:54:46', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3.jpg" alt="BraylonKeira3" width="1000" height="1510" class="alignnone size-full wp-image-232" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn-3', '', '', '2014-05-09 13:54:46', '2014-05-09 13:54:46', '', 0, 'http://localhost:8888/?p=247', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (248, 1, '2014-05-09 13:54:46', '2014-05-09 13:54:46', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3.jpg" alt="BraylonKeira3" width="1000" height="1510" class="alignnone size-full wp-image-232" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '247-revision-v1', '', '', '2014-05-09 13:54:46', '2014-05-09 13:54:46', '', 247, 'http://localhost:8888/247-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (249, 1, '2014-05-09 13:55:27', '2014-05-09 13:55:27', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4.jpg" alt="BraylonKeira4" width="1000" height="662" class="alignnone size-full wp-image-231" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn-4', '', '', '2014-05-09 14:01:13', '2014-05-09 14:01:13', '', 0, 'http://localhost:8888/?p=249', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (250, 1, '2014-05-09 13:55:27', '2014-05-09 13:55:27', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4.jpg" alt="BraylonKeira4" width="1000" height="662" class="alignnone size-full wp-image-231" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '249-revision-v1', '', '', '2014-05-09 13:55:27', '2014-05-09 13:55:27', '', 249, 'http://localhost:8888/249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (251, 1, '2014-05-09 13:56:31', '2014-05-09 13:56:31', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Arch.jpg" alt="Arch" width="1000" height="750" class="alignnone size-full wp-image-226" /></div>

<div class="post-description">
<h1>Night</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Night', '', 'publish', 'open', 'open', '', 'night', '', '', '2014-05-09 13:56:31', '2014-05-09 13:56:31', '', 0, 'http://localhost:8888/?p=251', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (252, 1, '2014-05-09 13:56:31', '2014-05-09 13:56:31', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Arch.jpg" alt="Arch" width="1000" height="750" class="alignnone size-full wp-image-226" /></div>

<div class="post-description">
<h1>Night</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Night', '', 'inherit', 'open', 'open', '', '251-revision-v1', '', '', '2014-05-09 13:56:31', '2014-05-09 13:56:31', '', 251, 'http://localhost:8888/251-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (253, 1, '2014-05-09 13:58:05', '2014-05-09 13:58:05', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Water.jpg" alt="Water" width="1000" height="750" class="alignnone size-full wp-image-228" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'publish', 'open', 'open', '', 'macro', '', '', '2014-05-09 13:58:05', '2014-05-09 13:58:05', '', 0, 'http://localhost:8888/?p=253', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (254, 1, '2014-05-09 13:58:05', '2014-05-09 13:58:05', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Water.jpg" alt="Water" width="1000" height="750" class="alignnone size-full wp-image-228" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'inherit', 'open', 'open', '', '253-revision-v1', '', '', '2014-05-09 13:58:05', '2014-05-09 13:58:05', '', 253, 'http://localhost:8888/253-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (255, 1, '2014-05-09 13:58:54', '2014-05-09 13:58:54', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Cactus.jpg" alt="Cactus" width="1000" height="1333" class="alignnone size-full wp-image-230" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'publish', 'open', 'open', '', 'macro-2', '', '', '2014-05-09 13:58:54', '2014-05-09 13:58:54', '', 0, 'http://localhost:8888/?p=255', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (256, 1, '2014-05-09 13:58:54', '2014-05-09 13:58:54', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Cactus.jpg" alt="Cactus" width="1000" height="1333" class="alignnone size-full wp-image-230" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'inherit', 'open', 'open', '', '255-revision-v1', '', '', '2014-05-09 13:58:54', '2014-05-09 13:58:54', '', 255, 'http://localhost:8888/255-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (257, 1, '2014-05-09 13:59:53', '2014-05-09 13:59:53', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/LightRail.jpg" alt="LightRail" width="1000" height="750" class="alignnone size-full wp-image-229" /></div>

<div class="post-description">
<h1>Motion Blur</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Motion Blur', '', 'publish', 'open', 'open', '', 'motion-blur', '', '', '2014-05-09 13:59:53', '2014-05-09 13:59:53', '', 0, 'http://localhost:8888/?p=257', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (258, 1, '2014-05-09 13:59:53', '2014-05-09 13:59:53', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/LightRail.jpg" alt="LightRail" width="1000" height="750" class="alignnone size-full wp-image-229" /></div>

<div class="post-description">
<h1>Motion Blur</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Motion Blur', '', 'inherit', 'open', 'open', '', '257-revision-v1', '', '', '2014-05-09 13:59:53', '2014-05-09 13:59:53', '', 257, 'http://localhost:8888/257-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (33 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (27, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (75, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (141, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (143, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (144, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (145, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (146, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (148, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (154, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (156, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (158, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (160, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (162, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (164, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (168, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (170, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (172, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (174, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (176, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (178, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (180, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (225, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (243, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (247, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (249, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (251, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (253, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (255, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (257, 8, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (8 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'portfolio_cats', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'portfolio_cats', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'portfolio_cats', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 3, 'category', '', 0, 14) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 4, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 5, 'category', '', 0, 8) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (5 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Main Navigation', 'main-navigation', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Graphic Design', 'graphic-design', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Web Design', 'web-design', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Photography', 'photography', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (22 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'lizponce') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '223') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, '_yoast_wpseo_profile_updated', '1398893840') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'libraryContent=browse&editor=html&urlbutton=none&imgsize=full&wpfb_adv_uploader=1') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1399647443') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:13:"add-portfolio";i:2;s:12:"add-post_tag";i:3;s:18:"add-portfolio_cats";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'closedpostboxes_toplevel_page_wpcf7', 'a:1:{i:0;s:7:"formdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'metaboxhidden_toplevel_page_wpcf7', 'a:0:{}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'lizponce', '$P$BAqASczPkmitex4zNwkcD6vD8WpFGj1', 'lizponce', 'liz@lizponce.com', '', '2014-04-27 04:13:11', '', 0, 'lizponce') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_cats`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpfb_cats`
#

DROP TABLE IF EXISTS `wp_wpfb_cats`;


#
# Table structure of table `wp_wpfb_cats`
#

CREATE TABLE `wp_wpfb_cats` (
  `cat_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL DEFAULT '',
  `cat_description` text,
  `cat_folder` varchar(300) NOT NULL DEFAULT '',
  `cat_path` varchar(2000) NOT NULL DEFAULT '',
  `cat_parent` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_num_files` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_num_files_total` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_user_roles` text NOT NULL,
  `cat_owner` bigint(20) unsigned DEFAULT NULL,
  `cat_icon` varchar(255) DEFAULT NULL,
  `cat_exclude_browser` enum('0','1') NOT NULL DEFAULT '0',
  `cat_order` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  FULLTEXT KEY `USER_ROLES` (`cat_user_roles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpfb_cats (0 records)
#

#
# End of data contents of table wp_wpfb_cats
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_cats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_files`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpfb_files`
#

DROP TABLE IF EXISTS `wp_wpfb_files`;


#
# Table structure of table `wp_wpfb_files`
#

CREATE TABLE `wp_wpfb_files` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(300) NOT NULL DEFAULT '',
  `file_path` varchar(2000) NOT NULL DEFAULT '',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_mtime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_hash` char(32) NOT NULL,
  `file_remote_uri` varchar(255) NOT NULL DEFAULT '',
  `file_thumbnail` varchar(255) DEFAULT NULL,
  `file_display_name` varchar(255) NOT NULL DEFAULT '',
  `file_description` text,
  `file_tags` varchar(255) NOT NULL DEFAULT '',
  `file_requirement` varchar(255) DEFAULT NULL,
  `file_version` varchar(64) DEFAULT NULL,
  `file_author` varchar(255) DEFAULT NULL,
  `file_language` varchar(255) DEFAULT NULL,
  `file_platform` varchar(255) DEFAULT NULL,
  `file_license` varchar(255) NOT NULL DEFAULT '',
  `file_user_roles` text NOT NULL,
  `file_offline` enum('0','1') NOT NULL DEFAULT '0',
  `file_direct_linking` enum('0','1','2') NOT NULL DEFAULT '0',
  `file_force_download` enum('0','1') NOT NULL DEFAULT '0',
  `file_category` int(8) unsigned NOT NULL DEFAULT '0',
  `file_category_name` varchar(127) NOT NULL DEFAULT '',
  `file_update_of` bigint(20) unsigned DEFAULT NULL,
  `file_post_id` bigint(20) unsigned DEFAULT NULL,
  `file_attach_order` int(8) NOT NULL DEFAULT '0',
  `file_wpattach_id` bigint(20) NOT NULL DEFAULT '0',
  `file_added_by` bigint(20) unsigned DEFAULT NULL,
  `file_hits` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_ratings` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_rating_sum` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_last_dl_ip` varchar(100) NOT NULL DEFAULT '',
  `file_last_dl_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_custom_cf1` text NOT NULL,
  `file_custom_cf2` text NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `DESCRIPTION` (`file_description`),
  FULLTEXT KEY `USER_ROLES` (`file_user_roles`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpfb_files (0 records)
#

#
# End of data contents of table wp_wpfb_files
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Friday 9. May 2014 14:57 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_cats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_files_id3`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpfb_files_id3`
#

DROP TABLE IF EXISTS `wp_wpfb_files_id3`;


#
# Table structure of table `wp_wpfb_files_id3`
#

CREATE TABLE `wp_wpfb_files_id3` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `analyzetime` int(11) NOT NULL DEFAULT '0',
  `value` longtext NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `KEYWORDS` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpfb_files_id3 (0 records)
#

#
# End of data contents of table wp_wpfb_files_id3
# --------------------------------------------------------

