# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------


#
# Delete any existing table `wp_afp_categories`
#

DROP TABLE IF EXISTS `wp_afp_categories`;


#
# Table structure of table `wp_afp_categories`
#

CREATE TABLE `wp_afp_categories` (
  `cat_id` int(5) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) DEFAULT NULL,
  `cat_description` text,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_afp_categories (2 records)
#
 
INSERT INTO `wp_afp_categories` VALUES (1, 'Graphic Design', '') ; 
INSERT INTO `wp_afp_categories` VALUES (2, 'Web Design', '') ;
#
# End of data contents of table wp_afp_categories
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------


#
# Delete any existing table `wp_afp_items`
#

DROP TABLE IF EXISTS `wp_afp_items`;


#
# Table structure of table `wp_afp_items`
#

CREATE TABLE `wp_afp_items` (
  `item_id` int(5) NOT NULL AUTO_INCREMENT,
  `item_title` varchar(100) DEFAULT NULL,
  `item_link` varchar(500) DEFAULT NULL,
  `item_description` text,
  `item_client` varchar(100) DEFAULT NULL,
  `item_date` date DEFAULT NULL,
  `item_thumbnail` varchar(200) DEFAULT NULL,
  `item_image` varchar(200) DEFAULT NULL,
  `item_category` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_afp_items (2 records)
#
 
INSERT INTO `wp_afp_items` VALUES (1, 'School Flyers', '', '', 'Brookline College', '1970-01-01', 'http://localhost:8888/wp-content/uploads/2014/05/LizPonceLogo.png', 'http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png', 'Graphic Design') ; 
INSERT INTO `wp_afp_items` VALUES (2, 'Web Test', '', '', '', '0000-00-00', 'http://localhost:8888/wp-content/uploads/2014/05/LizPonce_WebLogo.png', 'http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png', 'Web Design') ;
#
# End of data contents of table wp_afp_items
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-04-27 04:13:11', '2014-04-27 04:13:11', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=491 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (143 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Liz Ponce', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Designer Extraordinaire', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'liz@lizponce.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '4', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (32, 'active_plugins', 'a:4:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:24:"wordpress-seo/wp-seo.php";i:3;s:27:"wp-filebase/wp-filebase.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'home', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '/work', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', 'a:2:{i:0;s:98:"/Users/eponce_420/Website/www.lizponce.com/wp-content/plugins/awesome-filterable-portfolio/afp.php";i:1;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'stanleywp', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'stanley-child', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:9:{i:1399690580;a:1:{s:9:"wpfb_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1399695194;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1399695218;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1399695263;a:1:{s:14:"yoast_tracking";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1399695338;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1399705260;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1399762800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1399777200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1399666907;s:7:"checked";a:2:{s:13:"stanley-child";s:3:"1.0";s:9:"stanleywp";s:5:"3.0.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (113, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (115, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, 'recently_activated', 'a:1:{s:36:"awesome-filterable-portfolio/afp.php";i:1399431301;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (136, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1398639600;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (137, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1399172400;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, 'wpseo_titles', 'a:72:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:0:"";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:0:"";s:15:"title-404-wpseo";s:0:"";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:17:"noauthorship-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:17:"noauthorship-page";b:1;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:23:"noauthorship-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;s:15:"title-portfolio";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:18:"metadesc-portfolio";s:0:"";s:17:"metakey-portfolio";s:0:"";s:17:"noindex-portfolio";b:0;s:22:"noauthorship-portfolio";b:1;s:18:"showdate-portfolio";b:0;s:21:"hideeditbox-portfolio";b:0;s:24:"title-tax-portfolio_cats";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:27:"metadesc-tax-portfolio_cats";s:0:"";s:26:"metakey-tax-portfolio_cats";s:0:"";s:30:"hideeditbox-tax-portfolio_cats";b:0;s:26:"noindex-tax-portfolio_cats";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'wpseo', 'a:18:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:11:"ignore_tour";b:1;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:19:"tracking_popup_done";b:1;s:7:"version";s:7:"1.5.2.8";s:11:"alexaverify";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:15:"pinterestverify";s:0:"";s:12:"yandexverify";s:0:"";s:14:"yoast_tracking";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (142, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398572065;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (143, 'current_theme', 'stanley-child', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'theme_mods_lp-bootstrap', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398615306;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (149, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2797230562', 'no') ; 
INSERT INTO `wp_options` VALUES (150, '_transient_hmbkp_schedule_default-1_database_filesize', '671744', 'no') ; 
INSERT INTO `wp_options` VALUES (154, '_transient_lp_bootstrap_categories', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (177, 'theme_mods_stanleywp', 'a:7:{i:0;b:0;s:15:"homepage_blocks";a:2:{s:7:"enabled";a:2:{s:7:"placebo";s:7:"placebo";s:16:"home_static_page";s:12:"Page Content";}s:8:"disabled";a:2:{s:7:"placebo";s:7:"placebo";s:14:"home_portfolio";s:9:"Portfolio";}}s:7:"backups";N;s:9:"smof_init";s:31:"Sun, 27 Apr 2014 16:15:08 +0000";s:14:"custom_favicon";s:0:"";s:11:"custom_logo";s:0:"";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398893839;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (178, 'theme_mods_stanley-child', 'a:17:{i:0;b:0;s:15:"homepage_blocks";a:2:{s:7:"enabled";a:2:{s:7:"placebo";s:7:"placebo";s:16:"home_static_page";s:12:"Page Content";}s:8:"disabled";a:2:{s:7:"placebo";s:7:"placebo";s:14:"home_portfolio";s:9:"Portfolio";}}s:7:"backups";N;s:9:"smof_init";s:31:"Sun, 27 Apr 2014 16:27:55 +0000";s:14:"custom_favicon";s:0:"";s:11:"custom_logo";s:48:"/wp-content/uploads/2014/05/LizPonce_WebLogo.png";s:20:"home_portfolio_count";s:1:"3";s:14:"read_more_text";s:9:"Read More";s:19:"enable_disable_tags";s:1:"1";s:13:"project_title";s:1:"1";s:24:"portfolio_post_type_name";s:9:"Portfolio";s:24:"portfolio_post_type_slug";s:9:"portfolio";s:15:"tracking_header";s:0:"";s:15:"tracking_footer";s:0:"";s:14:"custom_css_box";s:0:"";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398893804;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}s:18:"nav_menu_locations";a:1:{s:7:"top-bar";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (209, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, 'wpcf7', 'a:1:{s:7:"version";s:3:"3.8";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (275, 'afpOptions', 'a:7:{s:8:"sort_cat";N;s:10:"sort_items";s:2:"id";s:12:"project_link";s:5:"blank";s:10:"anim_speed";s:3:"600";s:11:"anim_easing";s:2:"on";s:7:"startFX";s:6:"normal";s:7:"hoverFX";s:6:"normal";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (279, 'portfolio_cats_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (312, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (351, '_transient_random_seed', 'ab5030b868d00c4634cf348d65b3f737', 'yes') ; 
INSERT INTO `wp_options` VALUES (420, '_site_transient_timeout_browser_a64afbf86ac7a1ef023e4b1e1f62f178', '1400215165', 'yes') ; 
INSERT INTO `wp_options` VALUES (421, '_site_transient_browser_a64afbf86ac7a1ef023e4b1e1f62f178', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.131";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (434, '_transient_timeout_plugin_slugs', '1399733848', 'no') ; 
INSERT INTO `wp_options` VALUES (435, '_transient_plugin_slugs', 'a:6:{i:0;s:19:"akismet/akismet.php";i:1;s:36:"awesome-filterable-portfolio/afp.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:24:"wordpress-seo/wp-seo.php";i:5;s:27:"wp-filebase/wp-filebase.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (457, 'wpfilebase', 'a:85:{s:11:"upload_path";s:27:"wp-content/uploads/filebase";s:14:"thumbnail_size";i:120;s:14:"thumbnail_path";s:0:"";s:15:"base_auto_thumb";s:1:"1";s:14:"fext_blacklist";s:6:"db,tmp";s:10:"attach_pos";s:1:"1";s:11:"attach_loop";s:0:"";s:17:"auto_attach_files";s:1:"1";s:16:"filelist_sorting";s:17:"file_display_name";s:20:"filelist_sorting_dir";s:1:"0";s:12:"filelist_num";i:0;s:16:"file_date_format";s:6:"F j, Y";s:20:"bitrate_unregistered";i:0;s:18:"bitrate_registered";i:0;s:11:"traffic_day";i:0;s:13:"traffic_month";i:0;s:20:"traffic_exceeded_msg";s:47:"Traffic limit exceeded! Please try again later.";s:16:"file_offline_msg";s:31:"This file is currently offline.";s:17:"daily_user_limits";s:0:"";s:22:"daily_limit_subscriber";i:100;s:23:"daily_limit_contributor";i:100;s:18:"daily_limit_author";i:100;s:18:"daily_limit_editor";i:100;s:24:"daily_limit_exceeded_msg";s:39:"You can only download %d files per day.";s:18:"disable_permalinks";s:0:"";s:13:"download_base";s:8:"download";s:20:"file_browser_post_id";i:14;s:24:"file_browser_cat_sort_by";s:8:"cat_name";s:25:"file_browser_cat_sort_dir";s:1:"0";s:25:"file_browser_file_sort_by";s:17:"file_display_name";s:26:"file_browser_file_sort_dir";s:1:"0";s:16:"file_browser_fbc";s:0:"";s:11:"folder_icon";s:58:"/plugins/wp-filebase/images/folder-icons/folder_grey48.png";s:15:"small_icon_size";i:32;s:13:"cat_drop_down";s:0:"";s:14:"force_download";s:1:"1";s:14:"range_download";s:1:"1";s:10:"hide_links";s:1:"1";s:16:"ignore_admin_dls";s:1:"1";s:17:"hide_inaccessible";s:1:"1";s:16:"inaccessible_msg";s:40:"You are not allowed to access this file!";s:21:"inaccessible_redirect";s:0:"";s:20:"cat_inaccessible_msg";s:26:"Access to category denied!";s:18:"login_redirect_src";s:0:"";s:12:"http_nocache";s:0:"";s:14:"parse_tags_rss";s:0:"";s:23:"allow_srv_script_upload";s:0:"";s:19:"protect_upload_path";s:1:"1";s:13:"private_files";s:0:"";s:15:"frontend_upload";s:0:"";s:21:"accept_empty_referers";s:0:"";s:16:"allowed_referers";s:0:"";s:13:"use_fpassthru";s:0:"";s:19:"decimal_size_format";s:0:"";s:9:"admin_bar";s:1:"1";s:9:"cron_sync";s:0:"";s:20:"remove_missing_files";s:0:"";s:18:"search_integration";s:1:"1";s:17:"search_result_tpl";s:7:"default";s:11:"disable_id3";s:0:"";s:10:"search_id3";s:1:"1";s:13:"use_path_tags";s:0:"";s:18:"no_name_formatting";s:0:"";s:8:"fake_md5";s:0:"";s:22:"disable_footer_credits";s:1:"1";s:20:"footer_credits_style";s:58:"margin:0 auto 2px auto; text-align:center; font-size:11px;";s:19:"late_script_loading";s:0:"";s:14:"default_author";s:0:"";s:13:"default_roles";a:0:{}s:11:"default_cat";i:0;s:9:"languages";s:21:"English|en
Deutsch|de";s:9:"platforms";s:55:"Windows 7|win7
*Windows 8|win8
Linux|linux
Mac OS X|mac";s:8:"licenses";s:197:"*Freeware|free
Shareware|share
GNU General Public License|gpl|http://www.gnu.org/copyleft/gpl.html
CC Attribution-NonCommercial-ShareAlike|ccbyncsa|http://creativecommons.org/licenses/by-nc-sa/3.0/";s:12:"requirements";s:341:"PDF Reader|pdfread|http://www.foxitsoftware.com/pdf/reader/addons.php
Java|java|http://www.java.com/download/
Flash|flash|http://get.adobe.com/flashplayer/
Open Office|ooffice|http://www.openoffice.org/download/index.html
.NET Framework 3.5|.net35|http://www.microsoft.com/downloads/details.aspx?FamilyID=333325fd-ae52-4e35-b531-508d977d32a6";s:22:"default_direct_linking";s:1:"1";s:13:"custom_fields";s:25:"Custom 1|cf1
Custom 2|cf2";s:13:"template_file";s:1940:"<div class="wpfilebase-file-default" onclick="if(\'undefined\' == typeof event.target.href) document.getElementById(\'wpfb-file-link-%uid%\').click();">
  <div class="icon"><a href="%file_url%" target="_blank" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" alt="%file_display_name%" /></a></div>
  <div class="filetitle">
    <a href="%file_url%" title="Download %file_display_name%" target="_blank" id="wpfb-file-link-%uid%">%file_display_name%</a>
    <!-- IF %file_post_id% AND %post_id% != %file_post_id% --><a href="%file_post_url%" class="postlink">» %\'Post\'%</a><!-- ENDIF -->
    <br />
    %file_name%<br />
    <!-- IF %file_version% -->%\'Version:\'% %file_version%<br /><!-- ENDIF -->
  </div>
  <div class="info">
    %file_size%<br />
    %file_hits% %\'Downloads\'%<br />
    <a href="#" onclick="return wpfilebase_filedetails(%uid%);">%\'Details\'%</a>
  </div>
  <div class="details" id="wpfilebase-filedetails%uid%" style="display: none;">
  <!-- IF %file_description% --><p>%file_description%</p><!-- ENDIF -->
  <table border="0">
   <!-- IF %file_languages% --><tr><td><strong>%\'Languages\'%:</strong></td><td>%file_languages%</td></tr><!-- ENDIF -->
   <!-- IF %file_author% --><tr><td><strong>%\'Author\'%:</strong></td><td>%file_author%</td></tr><!-- ENDIF -->
   <!-- IF %file_platforms% --><tr><td><strong>%\'Platforms\'%:</strong></td><td>%file_platforms%</td></tr><!-- ENDIF -->
   <!-- IF %file_requirements% --><tr><td><strong>%\'Requirements\'%:</strong></td><td>%file_requirements%</td></tr><!-- ENDIF -->
   <!-- IF %file_category% --><tr><td><strong>%\'Category:\'%</strong></td><td>%file_category%</td></tr><!-- ENDIF -->
   <!-- IF %file_license% --><tr><td><strong>%\'License\'%:</strong></td><td>%file_license%</td></tr><!-- ENDIF -->
   <tr><td><strong>%\'Date\'%:</strong></td><td>%file_date%</td></tr>
  </table>
  </div>
 <div style="clear: both;"></div>
</div>";s:12:"template_cat";s:308:"<div class="wpfilebase-cat-default">
  <h3>
    <!-- IF %cat_has_icon% || true -->%cat_small_icon%<!-- ENDIF -->
    <a href="%cat_url%" title="Go to category %cat_name%">%cat_name%</a>
    <span>%cat_num_files% <!-- IF %cat_num_files% == 1 -->file<!-- ELSE -->files<!-- ENDIF --></span>
  </h3>
</div>";s:10:"dlclick_js";s:317:"if(typeof pageTracker == \'object\') {
	pageTracker._trackPageview(file_url); // new google analytics tracker
} else if(typeof urchinTracker == \'function\') {	
	urchinTracker(file_url); // old google analytics tracker
} else if(typeof ga == \'function\') {
	ga(\'send\', \'pageview\', file_url); // universal analytics
}";s:6:"widget";a:0:{}s:7:"version";s:8:"0.3.0.06";s:7:"tag_ver";i:2;s:20:"template_file_parsed";s:2746:"\'<div class="wpfilebase-file-default" onclick="if(\\\'undefined\\\' == typeof event.target.href) document.getElementById(\\\'wpfb-file-link-\'.$f->get_tpl_var(\'uid\').\'\\\').click();">
  <div class="icon"><a href="\'.$f->get_tpl_var(\'file_url\').\'" target="_blank" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'"><img align="middle" src="\'.$f->get_tpl_var(\'file_icon_url\').\'" alt="\'.$f->get_tpl_var(\'file_display_name\').\'" /></a></div>
  <div class="filetitle">
    <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'" target="_blank" id="wpfb-file-link-\'.$f->get_tpl_var(\'uid\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a>
    \'.((($f->get_tpl_var(\'file_post_id\')) && get_the_ID() != ($f->get_tpl_var(\'file_post_id\')))?(\'<a href="\'.$f->get_tpl_var(\'file_post_url\').\'" class="postlink">» \'.__(__(\'Post\', WPFB)).\'</a>\'):(\'\')).\'
    <br />
    \'.$f->get_tpl_var(\'file_name\').\'<br />
    \'.((($f->get_tpl_var(\'file_version\')))?(\'\'.__(__(\'Version:\', WPFB)).\' \'.$f->get_tpl_var(\'file_version\').\'<br />\'):(\'\')).\'
  </div>
  <div class="info">
    \'.$f->get_tpl_var(\'file_size\').\'<br />
    \'.$f->get_tpl_var(\'file_hits\').\' \'.__(__(\'Downloads\', WPFB)).\'<br />
    <a href="#" onclick="return wpfilebase_filedetails(\'.$f->get_tpl_var(\'uid\').\');">\'.__(__(\'Details\', WPFB)).\'</a>
  </div>
  <div class="details" id="wpfilebase-filedetails\'.$f->get_tpl_var(\'uid\').\'" style="display: none;">
  \'.((($f->get_tpl_var(\'file_description\')))?(\'<p>\'.$f->get_tpl_var(\'file_description\').\'</p>\'):(\'\')).\'
  <table border="0">
   \'.((($f->get_tpl_var(\'file_languages\')))?(\'<tr><td><strong>\'.__(__(\'Languages\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_languages\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_author\')))?(\'<tr><td><strong>\'.__(__(\'Author\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_author\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_platforms\')))?(\'<tr><td><strong>\'.__(__(\'Platforms\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_platforms\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_requirements\')))?(\'<tr><td><strong>\'.__(__(\'Requirements\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_requirements\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_category\')))?(\'<tr><td><strong>\'.__(__(\'Category:\', WPFB)).\'</strong></td><td>\'.$f->get_tpl_var(\'file_category\').\'</td></tr>\'):(\'\')).\'
   \'.((($f->get_tpl_var(\'file_license\')))?(\'<tr><td><strong>\'.__(__(\'License\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_license\').\'</td></tr>\'):(\'\')).\'
   <tr><td><strong>\'.__(__(\'Date\', WPFB)).\':</strong></td><td>\'.$f->get_tpl_var(\'file_date\').\'</td></tr>
  </table>
  </div>
 <div style="clear: both;"></div>
</div>\'";s:19:"template_cat_parsed";s:424:"\'<div class="wpfilebase-cat-default">
  <h3>
    \'.((($f->get_tpl_var(\'cat_has_icon\')) || true)?(\'\'.$f->get_tpl_var(\'cat_small_icon\').\'\'):(\'\')).\'
    <a href="\'.$f->get_tpl_var(\'cat_url\').\'" title="Go to category \'.$f->get_tpl_var(\'cat_name\').\'">\'.$f->get_tpl_var(\'cat_name\').\'</a>
    <span>\'.$f->get_tpl_var(\'cat_num_files\').\' \'.((($f->get_tpl_var(\'cat_num_files\')) == 1)?(\'file\'):(\'files\')).\'</span>
  </h3>
</div>\'";s:13:"traffic_stats";a:3:{s:5:"month";i:7273079;s:5:"today";i:7273079;s:4:"time";i:1399667554;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (458, 'wpfilebase_ftags', 'a:1:{s:0:"";i:1;}', 'no') ; 
INSERT INTO `wp_options` VALUES (459, 'wpfb_css', 'http://localhost:8888/wp-content/plugins/wp-filebase/wp-filebase.css', 'yes') ; 
INSERT INTO `wp_options` VALUES (460, 'wpfilebase_tpls_file', 'a:9:{s:11:"filebrowser";s:113:"%file_small_icon% <a href="%file_url%" title="Download %file_display_name%">%file_display_name%</a> (%file_size%)";s:15:"download-button";s:199:"<div style="text-align:center; width:250px; margin: auto; font-size:smaller;"><a href="%file_url%" class="wpfb-dlbtn"><div></div></a>
%file_display_name% (%file_size%, %file_hits% downloads)
</div>";s:9:"image_320";s:284:"[caption id="file_%file_id%" align="alignnone" width="320" caption="<!-- IF %file_description% -->%file_description%<!-- ELSE -->%file_display_name%<!-- ENDIF -->"]<img class="size-full" title="%file_display_name%" src="%file_url%" alt="%file_display_name%" width="320" />[/caption]

";s:9:"thumbnail";s:146:"<div class="wpfilebase-fileicon"><a href="%file_url%" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" /></a></div>
";s:6:"simple";s:175:"<p><img src="%file_icon_url%" style="height:20px;vertical-align:middle;" /> <a href="%file_url%" title="Download %file_display_name%">%file_display_name%</a> (%file_size%)</p>";s:9:"3-col-row";s:102:"<tr><td><a href="%file_url%">%file_display_name%</a></td><td>%file_size%</td><td>%file_hits%</td></tr>";s:3:"mp3";s:845:"<div class="wpfilebase-attachment">
 <div class="wpfilebase-fileicon"><a href="%file_url%" title="Download %file_display_name%"><img align="middle" src="%file_icon_url%" alt="%file_display_name%" height="80"/></a></div>
 <div class="wpfilebase-rightcol">
  <div class="wpfilebase-filetitle">
   <a href="%file_url%" title="Download %file_display_name%">%file_info/tags/id3v2/title%</a><br />
%file_info/tags/id3v2/artist%<br />
%file_info/tags/id3v2/album%<br />
   <!-- IF %file_post_id% AND %post_id% != %file_post_id% --><a href="%file_post_url%" class="wpfilebase-postlink">%\'View post\'%</a><!-- ENDIF -->
  </div>
 </div>
 <div class="wpfilebase-fileinfo">
  %file_info/playtime_string%<br />
  %file_info/bitrate%<br />
  %file_size%<br />
  %file_hits% %\'Downloads\'%<br />
 </div>
 <div style="clear: both;"></div>
</div>";s:10:"flv-player";s:894:"<!-- the player only works when permalinks are enabled!!! -->
 <object width=\'%file_info/video/resolution_x%\' height=\'%file_info/video/resolution_y%\' id=\'flvPlayer%uid%\'>
  <param name=\'allowFullScreen\' value=\'true\'>
   <param name=\'allowScriptAccess\' value=\'always\'> 
  <param name=\'movie\' value=\'%wpfb_url%extras/flvplayer/OSplayer.swf?movie=%file_url_encoded%&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=%file_display_name%&showTitle=yes\'>
  <embed src=\'%wpfb_url%extras/flvplayer/OSplayer.swf?movie=%file_url_encoded%&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=%file_display_name%&showTitle=yes\' width=\'%file_info/video/resolution_x%\' height=\'%file_info/video/resolution_y%\' allowFullScreen=\'true\' type=\'application/x-shockwave-flash\' allowScriptAccess=\'always\'>
 </object>";s:10:"data-table";s:102:"<tr><td><a href="%file_url%">%file_display_name%</a></td><td>%file_size%</td><td>%file_hits%</td></tr>";}', 'no') ; 
INSERT INTO `wp_options` VALUES (461, 'wpfilebase_tpls_cat', 'a:3:{s:11:"filebrowser";s:75:"%cat_small_icon% <a href="%cat_url%" onclick="return false;">%cat_name%</a>";s:9:"3-col-row";s:82:"<tr><td colspan="3" style="text-align:center;font-size:120%;">%cat_name%</td></tr>";s:10:"data-table";s:61:"<!-- EMPTY: categories should not be listed in DataTables -->";}', 'no') ; 
INSERT INTO `wp_options` VALUES (462, 'wpfilebase_ptpls_file', 'a:9:{s:11:"filebrowser";s:220:"\'\'.$f->get_tpl_var(\'file_small_icon\').\' <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a> (\'.$f->get_tpl_var(\'file_size\').\')\'";s:15:"download-button";s:285:"\'<div style="text-align:center; width:250px; margin: auto; font-size:smaller;"><a href="\'.$f->get_tpl_var(\'file_url\').\'" class="wpfb-dlbtn"><div></div></a>
\'.$f->get_tpl_var(\'file_display_name\').\' (\'.$f->get_tpl_var(\'file_size\').\', \'.$f->get_tpl_var(\'file_hits\').\' downloads)
</div>\'";s:9:"image_320";s:410:"\'[caption id="file_\'.$f->get_tpl_var(\'file_id\').\'" align="alignnone" width="320" caption="\'.((($f->get_tpl_var(\'file_description\')))?(\'\'.$f->get_tpl_var(\'file_description\').\'\'):(\'\'.$f->get_tpl_var(\'file_display_name\').\'\')).\'"]<img class="size-full" title="\'.$f->get_tpl_var(\'file_display_name\').\'" src="\'.$f->get_tpl_var(\'file_url\').\'" alt="\'.$f->get_tpl_var(\'file_display_name\').\'" width="320" />[/caption]

\'";s:9:"thumbnail";s:211:"\'<div class="wpfilebase-fileicon"><a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'"><img align="middle" src="\'.$f->get_tpl_var(\'file_icon_url\').\'" /></a></div>
\'";s:6:"simple";s:282:"\'<p><img src="\'.$f->get_tpl_var(\'file_icon_url\').\'" style="height:20px;vertical-align:middle;" /> <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a> (\'.$f->get_tpl_var(\'file_size\').\')</p>\'";s:9:"3-col-row";s:188:"\'<tr><td><a href="\'.$f->get_tpl_var(\'file_url\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a></td><td>\'.$f->get_tpl_var(\'file_size\').\'</td><td>\'.$f->get_tpl_var(\'file_hits\').\'</td></tr>\'";s:3:"mp3";s:1205:"\'<div class="wpfilebase-attachment">
 <div class="wpfilebase-fileicon"><a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'"><img align="middle" src="\'.$f->get_tpl_var(\'file_icon_url\').\'" alt="\'.$f->get_tpl_var(\'file_display_name\').\'" height="80"/></a></div>
 <div class="wpfilebase-rightcol">
  <div class="wpfilebase-filetitle">
   <a href="\'.$f->get_tpl_var(\'file_url\').\'" title="Download \'.$f->get_tpl_var(\'file_display_name\').\'">\'.$f->get_tpl_var(\'file_info/tags/id3v2/title\').\'</a><br />
\'.$f->get_tpl_var(\'file_info/tags/id3v2/artist\').\'<br />
\'.$f->get_tpl_var(\'file_info/tags/id3v2/album\').\'<br />
   \'.((($f->get_tpl_var(\'file_post_id\')) && get_the_ID() != ($f->get_tpl_var(\'file_post_id\')))?(\'<a href="\'.$f->get_tpl_var(\'file_post_url\').\'" class="wpfilebase-postlink">\'.__(__(\'View post\', WPFB)).\'</a>\'):(\'\')).\'
  </div>
 </div>
 <div class="wpfilebase-fileinfo">
  \'.$f->get_tpl_var(\'file_info/playtime_string\').\'<br />
  \'.$f->get_tpl_var(\'file_info/bitrate\').\'<br />
  \'.$f->get_tpl_var(\'file_size\').\'<br />
  \'.$f->get_tpl_var(\'file_hits\').\' \'.__(__(\'Downloads\', WPFB)).\'<br />
 </div>
 <div style="clear: both;"></div>
</div>\'";s:10:"flv-player";s:1137:"\'<!-- the player only works when permalinks are enabled!!! -->
 <object width=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_x\').\'\\\' height=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_y\').\'\\\' id=\\\'flvPlayer\'.$f->get_tpl_var(\'uid\').\'\\\'>
  <param name=\\\'allowFullScreen\\\' value=\\\'true\\\'>
   <param name=\\\'allowScriptAccess\\\' value=\\\'always\\\'> 
  <param name=\\\'movie\\\' value=\\\'\'.(WPFB_PLUGIN_URI).\'extras/flvplayer/OSplayer.swf?movie=\'.$f->get_tpl_var(\'file_url_encoded\').\'&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=\'.$f->get_tpl_var(\'file_display_name\').\'&showTitle=yes\\\'>
  <embed src=\\\'\'.(WPFB_PLUGIN_URI).\'extras/flvplayer/OSplayer.swf?movie=\'.$f->get_tpl_var(\'file_url_encoded\').\'&btncolor=0x333333&accentcolor=0x31b8e9&txtcolor=0xdddddd&volume=30&autoload=on&autoplay=off&vTitle=\'.$f->get_tpl_var(\'file_display_name\').\'&showTitle=yes\\\' width=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_x\').\'\\\' height=\\\'\'.$f->get_tpl_var(\'file_info/video/resolution_y\').\'\\\' allowFullScreen=\\\'true\\\' type=\\\'application/x-shockwave-flash\\\' allowScriptAccess=\\\'always\\\'>
 </object>\'";s:10:"data-table";s:188:"\'<tr><td><a href="\'.$f->get_tpl_var(\'file_url\').\'">\'.$f->get_tpl_var(\'file_display_name\').\'</a></td><td>\'.$f->get_tpl_var(\'file_size\').\'</td><td>\'.$f->get_tpl_var(\'file_hits\').\'</td></tr>\'";}', 'no') ; 
INSERT INTO `wp_options` VALUES (463, 'wpfilebase_ptpls_cat', 'a:3:{s:11:"filebrowser";s:140:"\'\'.$f->get_tpl_var(\'cat_small_icon\').\' <a href="\'.$f->get_tpl_var(\'cat_url\').\'" onclick="return false;">\'.$f->get_tpl_var(\'cat_name\').\'</a>\'";s:9:"3-col-row";s:105:"\'<tr><td colspan="3" style="text-align:center;font-size:120%;">\'.$f->get_tpl_var(\'cat_name\').\'</td></tr>\'";s:10:"data-table";s:63:"\'<!-- EMPTY: categories should not be listed in DataTables -->\'";}', 'no') ; 
INSERT INTO `wp_options` VALUES (464, 'wpfilebase_list_tpls', 'a:4:{s:7:"default";a:4:{s:6:"header";s:0:"";s:6:"footer";s:0:"";s:12:"file_tpl_tag";s:7:"default";s:11:"cat_tpl_tag";s:7:"default";}s:5:"table";a:4:{s:6:"header";s:453:"%search_form%
<table>
<thead>
	<tr><th scope="col"><a href="%sortlink:file_name%">Name</a></th><th scope="col"><a href="%sortlink:file_size%">Size</a></th><th scope="col"><a href="%sortlink:file_hits%">Hits</a></th></tr>
</thead>
<tfoot>
	<tr><th scope="col"><a href="%sortlink:file_name%">Name</a></th><th scope="col"><a href="%sortlink:file_size%">Size</a></th><th scope="col"><a href="%sortlink:file_hits%">Hits</a></th></tr>
</tfoot>
<tbody>";s:6:"footer";s:64:"</tbody>
</table>
<div class="tablenav-pages">%page_nav%</div>";s:12:"file_tpl_tag";s:9:"3-col-row";s:11:"cat_tpl_tag";s:9:"3-col-row";}s:8:"mp3-list";a:4:{s:6:"header";s:0:"";s:6:"footer";s:0:"";s:12:"file_tpl_tag";s:3:"mp3";s:11:"cat_tpl_tag";s:7:"default";}s:10:"data-table";a:4:{s:6:"header";s:216:"%print_script:jquery-dataTables%
%print_style:jquery-dataTables%
<table id="wpfb-data-table-%uid%">
<thead>
	<tr><th scope="col">Name</th><th scope="col">Size</th><th scope="col">Hits</th></tr>
</thead>
<tbody>";s:6:"footer";s:172:"</tbody>
</table>
<script type="text/javascript" charset="utf-8">
	jQuery(document).ready(function() {
		jQuery(\'#wpfb-data-table-%uid%\').dataTable();
	} );
</script>";s:12:"file_tpl_tag";s:10:"data-table";s:11:"cat_tpl_tag";s:10:"data-table";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (466, 'wpfb_install_time', '1399647380', 'no') ; 
INSERT INTO `wp_options` VALUES (473, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1399666907;s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (474, 'hmbkp_default_path', '/Users/eponce_420/Website/www.lizponce.com/wp-content/backupwordpress-9013187ce7-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (475, 'hmbkp_path', '/Users/eponce_420/Website/www.lizponce.com/wp-content/backupwordpress-9013187ce7-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (478, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1399666906;s:15:"version_checked";s:5:"3.9.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (480, '_site_transient_timeout_theme_roots', '1399668707', 'yes') ; 
INSERT INTO `wp_options` VALUES (481, '_site_transient_theme_roots', 'a:2:{s:13:"stanley-child";s:7:"/themes";s:9:"stanleywp";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (483, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1399710118', 'no') ; 
INSERT INTO `wp_options` VALUES (484, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: Couldn\'t resolve host \'wordpress.org\'</p></div><div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: Couldn\'t resolve host \'planet.wordpress.org\'</p></div><div class="rss-widget"><ul></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (489, 'rewrite_rules', 'a:90:{s:15:"downloads/(.+)$";s:20:"index.php?page_id=14";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:43:"work/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:38:"work/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:31:"work/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:13:"work/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:37:"portfolio/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"portfolio/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"portfolio/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"portfolio/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"portfolio/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"portfolio/([^/]+)/trackback/?$";s:36:"index.php?portfolio=$matches[1]&tb=1";s:38:"portfolio/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?portfolio=$matches[1]&paged=$matches[2]";s:45:"portfolio/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?portfolio=$matches[1]&cpage=$matches[2]";s:30:"portfolio/([^/]+)(/[0-9]+)?/?$";s:48:"index.php?portfolio=$matches[1]&page=$matches[2]";s:26:"portfolio/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"portfolio/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"portfolio/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"portfolio/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"portfolio/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:59:"portfolio-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?portfolio_cats=$matches[1]&feed=$matches[2]";s:54:"portfolio-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?portfolio_cats=$matches[1]&feed=$matches[2]";s:47:"portfolio-category/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?portfolio_cats=$matches[1]&paged=$matches[2]";s:29:"portfolio-category/([^/]+)/?$";s:36:"index.php?portfolio_cats=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (490, '_transient_doing_cron', '1399687160.9511489868164062500000', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (408 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (3, 4, '_edit_lock', '1399666838:1') ; 
INSERT INTO `wp_postmeta` VALUES (4, 6, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 6, '_edit_lock', '1399610387:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 8, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (7, 8, '_edit_lock', '1399512854:1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 10, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 10, '_edit_lock', '1398572111:1') ; 
INSERT INTO `wp_postmeta` VALUES (10, 12, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (11, 12, '_edit_lock', '1398572131:1') ; 
INSERT INTO `wp_postmeta` VALUES (12, 14, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13, 14, '_edit_lock', '1399667225:1') ; 
INSERT INTO `wp_postmeta` VALUES (16, 17, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (17, 17, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (18, 17, '_menu_item_object_id', '17') ; 
INSERT INTO `wp_postmeta` VALUES (19, 17, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (20, 17, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (21, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (22, 17, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (23, 17, '_menu_item_url', 'http://localhost:8888/') ; 
INSERT INTO `wp_postmeta` VALUES (24, 17, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (25, 18, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (26, 18, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (27, 18, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (28, 18, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (29, 18, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (30, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (31, 18, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 18, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (33, 18, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (34, 19, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (35, 19, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (36, 19, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (37, 19, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (38, 19, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (39, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (40, 19, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (41, 19, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (42, 19, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (43, 20, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (44, 20, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (45, 20, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (46, 20, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (47, 20, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (48, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (49, 20, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (50, 20, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (51, 20, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (52, 21, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (53, 21, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (54, 21, '_menu_item_object_id', '8') ; 
INSERT INTO `wp_postmeta` VALUES (55, 21, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (56, 21, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (57, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (58, 21, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (59, 21, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (60, 21, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (61, 22, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (62, 22, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (63, 22, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (64, 22, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (65, 22, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (66, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (67, 22, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (68, 22, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (69, 22, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (70, 23, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (71, 23, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (72, 23, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (73, 23, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (74, 23, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (75, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (76, 23, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (77, 23, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (78, 23, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (79, 24, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (80, 24, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (81, 24, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (82, 24, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (83, 24, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (84, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (85, 24, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (86, 24, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (87, 24, '_menu_item_orphaned', '1398893958') ; 
INSERT INTO `wp_postmeta` VALUES (88, 25, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (89, 25, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (90, 25, '_menu_item_object_id', '25') ; 
INSERT INTO `wp_postmeta` VALUES (91, 25, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (92, 25, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (93, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (94, 25, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (95, 25, '_menu_item_url', 'http://localhost:8888/') ; 
INSERT INTO `wp_postmeta` VALUES (97, 26, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (98, 26, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (99, 26, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (100, 26, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (101, 26, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (102, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (103, 26, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (104, 26, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (106, 27, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (107, 27, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (108, 27, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (109, 27, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (110, 27, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (111, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (112, 27, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (113, 27, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (115, 28, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (116, 28, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (117, 28, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (118, 28, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (119, 28, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (120, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (121, 28, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (122, 28, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (123, 28, '_menu_item_orphaned', '1398893994') ; 
INSERT INTO `wp_postmeta` VALUES (142, 31, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (143, 31, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (144, 31, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (145, 31, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (146, 31, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (147, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (148, 31, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (149, 31, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (150, 31, '_menu_item_orphaned', '1398893994') ; 
INSERT INTO `wp_postmeta` VALUES (160, 4, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (161, 4, 'wtf_about_title', '<h1>About Stanley!</h1>') ; 
INSERT INTO `wp_postmeta` VALUES (162, 4, 'wtf_about_left_txt', '<h4>THE THINKING</h4>
				<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p>') ; 
INSERT INTO `wp_postmeta` VALUES (163, 4, 'wtf_about_right_txt', '<h4>THE SKILLS</h4>
				Wordpress
				<div class="progress">
					<div class="progress-bar progress-bar-theme" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
						<span class="sr-only">60% Complete</span>
					</div>
				</div>

				Photoshop
				<div class="progress">
					<div class="progress-bar progress-bar-theme" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
						<span class="sr-only">80% Complete</span>
					</div>
				</div>
				
				HTML + CSS
				<div class="progress">
					<div class="progress-bar progress-bar-theme" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
						<span class="sr-only">95% Complete</span>
					</div>
				</div>') ; 
INSERT INTO `wp_postmeta` VALUES (164, 4, 'wtf_about_col', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (165, 4, 'wtf_portfolio_title', '<h3>LATEST WORKS</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (179, 40, '_wp_attached_file', '2014/05/Hexagon.png') ; 
INSERT INTO `wp_postmeta` VALUES (180, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:93;s:4:"file";s:19:"2014/05/Hexagon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Hexagon-150x93.png";s:5:"width";i:150;s:6:"height";i:93;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (181, 41, '_wp_attached_file', '2014/05/LizPonce_WebLogo.png') ; 
INSERT INTO `wp_postmeta` VALUES (182, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:120;s:4:"file";s:28:"2014/05/LizPonce_WebLogo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"LizPonce_WebLogo-150x120.png";s:5:"width";i:150;s:6:"height";i:120;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (195, 48, '_wp_attached_file', '2014/05/WebDesign_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (196, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:26:"2014/05/WebDesign_Icon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"WebDesign_Icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (197, 49, '_wp_attached_file', '2014/05/Geometric_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (198, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:26:"2014/05/Geometric_Icon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Geometric_Icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (199, 50, '_wp_attached_file', '2014/05/Shutter_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (200, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:24:"2014/05/Shutter_Icon.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Shutter_Icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (201, 51, '_wp_attached_file', '2014/05/Twitter_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (202, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:25;s:6:"height";i:25;s:4:"file";s:24:"2014/05/Twitter_Icon.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (203, 52, '_wp_attached_file', '2014/05/LinkedIn_Icon.png') ; 
INSERT INTO `wp_postmeta` VALUES (204, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:25;s:6:"height";i:25;s:4:"file";s:25:"2014/05/LinkedIn_Icon.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (205, 59, '_form', '<p>Your Name*<br />
    [text* your-name] </p>

<p>Your Email*<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Write Some Words<br />
    [textarea your-message] </p>

<p>[submit "Give Me a Shout"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (206, 59, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:168:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)";s:9:"recipient";s:16:"liz@lizponce.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (207, 59, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:110:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (208, 59, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (209, 59, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (210, 59, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (211, 6, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (212, 8, '_wp_page_template', 'template-child-graphic-design.php') ; 
INSERT INTO `wp_postmeta` VALUES (213, 12, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (214, 12, '_wp_trash_meta_time', '1399382440') ; 
INSERT INTO `wp_postmeta` VALUES (215, 10, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (216, 10, '_wp_trash_meta_time', '1399382440') ; 
INSERT INTO `wp_postmeta` VALUES (219, 67, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (220, 67, 'wtf_portfolio_top_title', '<h3>Brookline College Flyers</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (221, 67, '_edit_lock', '1399429495:1') ; 
INSERT INTO `wp_postmeta` VALUES (223, 8, 'wtf_portfolio_title', '<h3>LATEST WORKS</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (224, 67, 'wtf_port_cats', 'value2') ; 
INSERT INTO `wp_postmeta` VALUES (225, 71, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (226, 71, '_edit_lock', '1399429517:1') ; 
INSERT INTO `wp_postmeta` VALUES (228, 71, 'wtf_portfolio_top_title', '<h3>PROJECT NAME</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (229, 73, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (230, 73, '_edit_lock', '1399430416:1') ; 
INSERT INTO `wp_postmeta` VALUES (232, 73, 'wtf_portfolio_top_title', '<h3>PROJECT NAME</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (233, 75, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (234, 75, '_edit_lock', '1399431211:1') ; 
INSERT INTO `wp_postmeta` VALUES (238, 75, 'wtf_portfolio_top_title', '<h3>PROJECT NAME</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (239, 75, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (240, 75, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (241, 73, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (242, 73, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (243, 71, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (244, 71, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (245, 67, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (246, 67, '_wp_trash_meta_time', '1399432066') ; 
INSERT INTO `wp_postmeta` VALUES (247, 1, '_edit_lock', '1399609058:1') ; 
INSERT INTO `wp_postmeta` VALUES (249, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (252, 85, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (253, 85, '_edit_lock', '1399432695:1') ; 
INSERT INTO `wp_postmeta` VALUES (254, 85, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (255, 87, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (256, 87, '_edit_lock', '1399432721:1') ; 
INSERT INTO `wp_postmeta` VALUES (257, 87, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (276, 91, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (277, 91, '_edit_lock', '1399432947:1') ; 
INSERT INTO `wp_postmeta` VALUES (278, 91, '_wp_page_template', 'template-main-child.php') ; 
INSERT INTO `wp_postmeta` VALUES (315, 99, '_wp_attached_file', '2014/05/BC_Flyers.png') ; 
INSERT INTO `wp_postmeta` VALUES (316, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:21:"2014/05/BC_Flyers.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"BC_Flyers-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"BC_Flyers-300x198.png";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (317, 100, '_wp_attached_file', '2014/05/BC_Poster.png') ; 
INSERT INTO `wp_postmeta` VALUES (318, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1384;s:4:"file";s:21:"2014/05/BC_Poster.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"BC_Poster-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"BC_Poster-216x300.png";s:5:"width";i:216;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:22:"BC_Poster-739x1024.png";s:5:"width";i:739;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (319, 101, '_wp_attached_file', '2014/05/BC_Homepage.png') ; 
INSERT INTO `wp_postmeta` VALUES (320, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:992;s:6:"height";i:410;s:4:"file";s:23:"2014/05/BC_Homepage.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"BC_Homepage-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"BC_Homepage-300x123.png";s:5:"width";i:300;s:6:"height";i:123;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (321, 102, '_wp_attached_file', '2014/05/BC_NewsAds.png') ; 
INSERT INTO `wp_postmeta` VALUES (322, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:580;s:6:"height";i:486;s:4:"file";s:22:"2014/05/BC_NewsAds.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"BC_NewsAds-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"BC_NewsAds-300x251.png";s:5:"width";i:300;s:6:"height";i:251;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (323, 103, '_wp_attached_file', '2014/05/NG_Seminar.png') ; 
INSERT INTO `wp_postmeta` VALUES (324, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:581;s:4:"file";s:22:"2014/05/NG_Seminar.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"NG_Seminar-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"NG_Seminar-300x174.png";s:5:"width";i:300;s:6:"height";i:174;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (325, 104, '_wp_attached_file', '2014/05/NG_Web.png') ; 
INSERT INTO `wp_postmeta` VALUES (326, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:691;s:4:"file";s:18:"2014/05/NG_Web.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"NG_Web-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"NG_Web-300x207.png";s:5:"width";i:300;s:6:"height";i:207;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (327, 105, '_wp_attached_file', '2014/05/CS_Billboard.png') ; 
INSERT INTO `wp_postmeta` VALUES (328, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:24:"2014/05/CS_Billboard.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"CS_Billboard-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"CS_Billboard-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (329, 106, '_wp_attached_file', '2014/05/CS_Mag.png') ; 
INSERT INTO `wp_postmeta` VALUES (330, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:682;s:4:"file";s:18:"2014/05/CS_Mag.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"CS_Mag-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"CS_Mag-300x204.png";s:5:"width";i:300;s:6:"height";i:204;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (331, 107, '_wp_attached_file', '2014/05/HC_Flyer.png') ; 
INSERT INTO `wp_postmeta` VALUES (332, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:597;s:4:"file";s:20:"2014/05/HC_Flyer.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"HC_Flyer-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:20:"HC_Flyer-300x179.png";s:5:"width";i:300;s:6:"height";i:179;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (333, 108, '_wp_attached_file', '2014/05/LilWayne_Poster.png') ; 
INSERT INTO `wp_postmeta` VALUES (334, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1187;s:4:"file";s:27:"2014/05/LilWayne_Poster.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"LilWayne_Poster-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"LilWayne_Poster-252x300.png";s:5:"width";i:252;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"LilWayne_Poster-862x1024.png";s:5:"width";i:862;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (335, 109, '_wp_attached_file', '2014/05/HC_Homepage.png') ; 
INSERT INTO `wp_postmeta` VALUES (336, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:594;s:4:"file";s:23:"2014/05/HC_Homepage.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"HC_Homepage-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"HC_Homepage-300x178.png";s:5:"width";i:300;s:6:"height";i:178;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (337, 110, '_wp_attached_file', '2014/05/Label_MeatPackaging.png') ; 
INSERT INTO `wp_postmeta` VALUES (338, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:862;s:6:"height";i:750;s:4:"file";s:31:"2014/05/Label_MeatPackaging.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Label_MeatPackaging-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:31:"Label_MeatPackaging-300x261.png";s:5:"width";i:300;s:6:"height";i:261;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (339, 111, '_wp_attached_file', '2014/05/Shirt_Millenium.png') ; 
INSERT INTO `wp_postmeta` VALUES (340, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:675;s:6:"height";i:882;s:4:"file";s:27:"2014/05/Shirt_Millenium.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Shirt_Millenium-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Shirt_Millenium-229x300.png";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (341, 112, '_wp_attached_file', '2014/05/Wine_TerraNova.png') ; 
INSERT INTO `wp_postmeta` VALUES (342, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1191;s:4:"file";s:26:"2014/05/Wine_TerraNova.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Wine_TerraNova-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"Wine_TerraNova-251x300.png";s:5:"width";i:251;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:27:"Wine_TerraNova-859x1024.png";s:5:"width";i:859;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (343, 113, '_wp_attached_file', '2014/05/Wayfinding_Cart.png') ; 
INSERT INTO `wp_postmeta` VALUES (344, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:780;s:6:"height";i:587;s:4:"file";s:27:"2014/05/Wayfinding_Cart.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Wayfinding_Cart-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Wayfinding_Cart-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (345, 114, '_wp_attached_file', '2014/05/TypeChronology.png') ; 
INSERT INTO `wp_postmeta` VALUES (346, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:564;s:4:"file";s:26:"2014/05/TypeChronology.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"TypeChronology-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"TypeChronology-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (347, 115, '_wp_attached_file', '2014/05/Wayfinding_App.png') ; 
INSERT INTO `wp_postmeta` VALUES (348, 115, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1152;s:4:"file";s:26:"2014/05/Wayfinding_App.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Wayfinding_App-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"Wayfinding_App-260x300.png";s:5:"width";i:260;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:27:"Wayfinding_App-888x1024.png";s:5:"width";i:888;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (349, 116, '_wp_attached_file', '2014/05/Windstar_Logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (350, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:868;s:6:"height";i:569;s:4:"file";s:25:"2014/05/Windstar_Logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Windstar_Logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"Windstar_Logo-300x196.png";s:5:"width";i:300;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (351, 117, '_wp_attached_file', '2014/05/BC_Homepage_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (352, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:26:"2014/05/BC_Homepage_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"BC_Homepage_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"BC_Homepage_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (353, 118, '_wp_attached_file', '2014/05/BC_Flyers_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (354, 118, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:24:"2014/05/BC_Flyers_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"BC_Flyers_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"BC_Flyers_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (355, 119, '_wp_attached_file', '2014/05/BC_NewsAds_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (356, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:25:"2014/05/BC_NewsAds_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BC_NewsAds_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"BC_NewsAds_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (357, 120, '_wp_attached_file', '2014/05/BC_Poster_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (358, 120, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:24:"2014/05/BC_Poster_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"BC_Poster_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"BC_Poster_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (359, 121, '_wp_attached_file', '2014/05/NG_Seminar_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (360, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:25:"2014/05/NG_Seminar_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"NG_Seminar_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"NG_Seminar_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (361, 122, '_wp_attached_file', '2014/05/CS_Mag_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (362, 122, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:21:"2014/05/CS_Mag_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"CS_Mag_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"CS_Mag_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (363, 123, '_wp_attached_file', '2014/05/CS_Billboard_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (364, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:27:"2014/05/CS_Billboard_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"CS_Billboard_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"CS_Billboard_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (365, 124, '_wp_attached_file', '2014/05/NG_Web_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (366, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:21:"2014/05/NG_Web_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"NG_Web_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"NG_Web_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (367, 125, '_wp_attached_file', '2014/05/HC_Flyer_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (368, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:23:"2014/05/HC_Flyer_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"HC_Flyer_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"HC_Flyer_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (369, 126, '_wp_attached_file', '2014/05/HC_Homepage_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (370, 126, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:26:"2014/05/HC_Homepage_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"HC_Homepage_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:26:"HC_Homepage_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (371, 127, '_wp_attached_file', '2014/05/LilWayne_Poster_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (372, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:30:"2014/05/LilWayne_Poster_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"LilWayne_Poster_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"LilWayne_Poster_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (373, 128, '_wp_attached_file', '2014/05/Label_MeatPackaging_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (374, 128, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:34:"2014/05/Label_MeatPackaging_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"Label_MeatPackaging_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:34:"Label_MeatPackaging_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (375, 129, '_wp_attached_file', '2014/05/Shirt_Millenium_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (376, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:30:"2014/05/Shirt_Millenium_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Shirt_Millenium_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"Shirt_Millenium_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (377, 130, '_wp_attached_file', '2014/05/Wine_TerraNova_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (378, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:29:"2014/05/Wine_TerraNova_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"Wine_TerraNova_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"Wine_TerraNova_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (379, 131, '_wp_attached_file', '2014/05/TypeChronology_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (380, 131, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:29:"2014/05/TypeChronology_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"TypeChronology_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"TypeChronology_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (381, 132, '_wp_attached_file', '2014/05/Wayfinding_Cart_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (382, 132, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:30:"2014/05/Wayfinding_Cart_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Wayfinding_Cart_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:30:"Wayfinding_Cart_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (383, 133, '_wp_attached_file', '2014/05/Wayfinding_App_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (384, 133, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:29:"2014/05/Wayfinding_App_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"Wayfinding_App_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:29:"Wayfinding_App_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (385, 134, '_wp_attached_file', '2014/05/Windstar_Logo_TN.png') ; 
INSERT INTO `wp_postmeta` VALUES (386, 134, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/Windstar_Logo_TN.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Windstar_Logo_TN-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:28:"Windstar_Logo_TN-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (387, 1, '_thumbnail_id', '118') ; 
INSERT INTO `wp_postmeta` VALUES (390, 1, '_wp_old_slug', 'hello-world') ; 
INSERT INTO `wp_postmeta` VALUES (397, 141, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (398, 141, '_edit_lock', '1399667975:1') ; 
INSERT INTO `wp_postmeta` VALUES (399, 141, '_thumbnail_id', '120') ; 
INSERT INTO `wp_postmeta` VALUES (404, 143, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (405, 143, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (406, 143, '_menu_item_object_id', '3') ; 
INSERT INTO `wp_postmeta` VALUES (407, 143, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (408, 143, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (409, 143, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (410, 143, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (411, 143, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (413, 8, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (414, 8, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (415, 91, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (416, 91, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (417, 87, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (418, 87, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (419, 85, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (420, 85, '_wp_trash_meta_time', '1399513278') ; 
INSERT INTO `wp_postmeta` VALUES (421, 144, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (422, 144, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (423, 144, '_menu_item_object_id', '5') ; 
INSERT INTO `wp_postmeta` VALUES (424, 144, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (425, 144, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (426, 144, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (427, 144, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (428, 144, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (430, 145, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (431, 145, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (432, 145, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (433, 145, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (434, 145, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (435, 145, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (436, 145, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (437, 145, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (439, 146, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (440, 146, '_edit_lock', '1399609042:1') ; 
INSERT INTO `wp_postmeta` VALUES (441, 146, '_thumbnail_id', '119') ; 
INSERT INTO `wp_postmeta` VALUES (444, 148, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (445, 148, '_edit_lock', '1399608782:1') ; 
INSERT INTO `wp_postmeta` VALUES (446, 148, '_thumbnail_id', '117') ; 
INSERT INTO `wp_postmeta` VALUES (457, 154, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (458, 154, '_edit_lock', '1399609020:1') ; 
INSERT INTO `wp_postmeta` VALUES (459, 154, '_thumbnail_id', '121') ; 
INSERT INTO `wp_postmeta` VALUES (462, 156, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (463, 156, '_edit_lock', '1399608800:1') ; 
INSERT INTO `wp_postmeta` VALUES (464, 156, '_thumbnail_id', '124') ; 
INSERT INTO `wp_postmeta` VALUES (467, 158, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (468, 158, '_edit_lock', '1399609012:1') ; 
INSERT INTO `wp_postmeta` VALUES (469, 158, '_thumbnail_id', '123') ; 
INSERT INTO `wp_postmeta` VALUES (472, 160, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (473, 160, '_edit_lock', '1399609003:1') ; 
INSERT INTO `wp_postmeta` VALUES (474, 160, '_thumbnail_id', '122') ; 
INSERT INTO `wp_postmeta` VALUES (477, 162, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (478, 162, '_edit_lock', '1399608963:1') ; 
INSERT INTO `wp_postmeta` VALUES (479, 162, '_thumbnail_id', '125') ; 
INSERT INTO `wp_postmeta` VALUES (482, 164, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (483, 164, '_edit_lock', '1399608949:1') ; 
INSERT INTO `wp_postmeta` VALUES (484, 164, '_thumbnail_id', '127') ; 
INSERT INTO `wp_postmeta` VALUES (487, 166, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (488, 166, '_edit_lock', '1399608602:1') ; 
INSERT INTO `wp_postmeta` VALUES (489, 166, '_thumbnail_id', '126') ; 
INSERT INTO `wp_postmeta` VALUES (492, 168, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (493, 168, '_edit_lock', '1399608935:1') ; 
INSERT INTO `wp_postmeta` VALUES (494, 168, '_thumbnail_id', '128') ; 
INSERT INTO `wp_postmeta` VALUES (497, 170, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (498, 170, '_edit_lock', '1399608917:1') ; 
INSERT INTO `wp_postmeta` VALUES (499, 170, '_thumbnail_id', '129') ; 
INSERT INTO `wp_postmeta` VALUES (502, 172, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (503, 172, '_edit_lock', '1399608897:1') ; 
INSERT INTO `wp_postmeta` VALUES (504, 172, '_thumbnail_id', '130') ; 
INSERT INTO `wp_postmeta` VALUES (507, 174, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (508, 174, '_edit_lock', '1399608882:1') ; 
INSERT INTO `wp_postmeta` VALUES (509, 174, '_thumbnail_id', '132') ; 
INSERT INTO `wp_postmeta` VALUES (512, 176, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (513, 176, '_edit_lock', '1399608869:1') ; 
INSERT INTO `wp_postmeta` VALUES (514, 176, '_thumbnail_id', '131') ; 
INSERT INTO `wp_postmeta` VALUES (517, 178, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (518, 178, '_edit_lock', '1399608529:1') ; 
INSERT INTO `wp_postmeta` VALUES (519, 178, '_thumbnail_id', '133') ; 
INSERT INTO `wp_postmeta` VALUES (522, 180, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (523, 180, '_edit_lock', '1399643029:1') ; 
INSERT INTO `wp_postmeta` VALUES (524, 180, '_thumbnail_id', '134') ; 
INSERT INTO `wp_postmeta` VALUES (605, 224, '_wp_attached_file', '2014/05/Maintenance.png') ; 
INSERT INTO `wp_postmeta` VALUES (606, 224, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:440;s:6:"height";i:350;s:4:"file";s:23:"2014/05/Maintenance.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"Maintenance-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"Maintenance-300x238.png";s:5:"width";i:300;s:6:"height";i:238;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (607, 226, '_wp_attached_file', '2014/05/Arch.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (608, 226, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:16:"2014/05/Arch.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"Arch-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"Arch-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (609, 227, '_wp_attached_file', '2014/05/BraylonKeira1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (610, 227, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:25:"2014/05/BraylonKeira1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira1-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (611, 225, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (612, 225, '_edit_lock', '1399643498:1') ; 
INSERT INTO `wp_postmeta` VALUES (613, 228, '_wp_attached_file', '2014/05/Water.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (614, 228, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:17:"2014/05/Water.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Water-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"Water-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (615, 229, '_wp_attached_file', '2014/05/LightRail.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (616, 229, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:750;s:4:"file";s:21:"2014/05/LightRail.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"LightRail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"LightRail-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (617, 230, '_wp_attached_file', '2014/05/Cactus.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (618, 230, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1333;s:4:"file";s:18:"2014/05/Cactus.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Cactus-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"Cactus-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"Cactus-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (619, 231, '_wp_attached_file', '2014/05/BraylonKeira4.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (620, 231, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:25:"2014/05/BraylonKeira4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira4-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (621, 232, '_wp_attached_file', '2014/05/BraylonKeira3.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (622, 232, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1510;s:4:"file";s:25:"2014/05/BraylonKeira3.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira3-198x300.jpg";s:5:"width";i:198;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"BraylonKeira3-678x1024.jpg";s:5:"width";i:678;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (623, 233, '_wp_attached_file', '2014/05/BraylonKeira2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (624, 233, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:662;s:4:"file";s:25:"2014/05/BraylonKeira2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"BraylonKeira2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"BraylonKeira2-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (625, 234, '_wp_attached_file', '2014/05/Water_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (626, 234, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:20:"2014/05/Water_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"Water_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"Water_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (627, 235, '_wp_attached_file', '2014/05/LightRail_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (628, 235, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:24:"2014/05/LightRail_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"LightRail_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"LightRail_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (629, 236, '_wp_attached_file', '2014/05/Cactus_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (630, 236, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:21:"2014/05/Cactus_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"Cactus_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Cactus_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (631, 237, '_wp_attached_file', '2014/05/Arch_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (632, 237, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:19:"2014/05/Arch_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"Arch_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"Arch_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (633, 238, '_wp_attached_file', '2014/05/BraylonKeira4_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (634, 238, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira4_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira4_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira4_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (635, 239, '_wp_attached_file', '2014/05/BraylonKeira3_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (636, 239, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira3_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira3_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira3_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (637, 240, '_wp_attached_file', '2014/05/BraylonKeira2_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (638, 240, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira2_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira2_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira2_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (639, 241, '_wp_attached_file', '2014/05/BraylonKeira1_TN.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (640, 241, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:360;s:4:"file";s:28:"2014/05/BraylonKeira1_TN.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"BraylonKeira1_TN-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"BraylonKeira1_TN-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (643, 225, '_thumbnail_id', '241') ; 
INSERT INTO `wp_postmeta` VALUES (646, 243, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (647, 243, '_edit_lock', '1399643470:1') ; 
INSERT INTO `wp_postmeta` VALUES (648, 243, '_thumbnail_id', '240') ; 
INSERT INTO `wp_postmeta` VALUES (655, 247, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (656, 247, '_edit_lock', '1399643550:1') ; 
INSERT INTO `wp_postmeta` VALUES (657, 247, '_thumbnail_id', '239') ; 
INSERT INTO `wp_postmeta` VALUES (660, 249, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (661, 249, '_edit_lock', '1399643947:1') ; 
INSERT INTO `wp_postmeta` VALUES (664, 251, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (665, 251, '_edit_lock', '1399643652:1') ; 
INSERT INTO `wp_postmeta` VALUES (666, 251, '_thumbnail_id', '237') ; 
INSERT INTO `wp_postmeta` VALUES (669, 253, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (670, 253, '_edit_lock', '1399643750:1') ; 
INSERT INTO `wp_postmeta` VALUES (671, 253, '_thumbnail_id', '234') ; 
INSERT INTO `wp_postmeta` VALUES (674, 255, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (675, 255, '_edit_lock', '1399643797:1') ; 
INSERT INTO `wp_postmeta` VALUES (676, 255, '_thumbnail_id', '236') ; 
INSERT INTO `wp_postmeta` VALUES (679, 257, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (680, 257, '_edit_lock', '1399643855:1') ; 
INSERT INTO `wp_postmeta` VALUES (681, 257, '_thumbnail_id', '235') ; 
INSERT INTO `wp_postmeta` VALUES (684, 249, '_thumbnail_id', '238') ; 
INSERT INTO `wp_postmeta` VALUES (687, 14, '_wp_page_template', 'template-main-child.php') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (234 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-04-27 04:13:11', '2014-04-27 04:13:11', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Brookline College Flyers</h1>
<hr class="content-title-rule">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'publish', 'open', 'open', '', 'bc-flyers', '', '', '2014-05-09 04:15:59', '2014-05-09 04:15:59', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-04-27 04:13:11', '2014-04-27 04:13:11', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-04-27 04:13:11', '2014-04-27 04:13:11', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2014-04-27 04:16:32', '2014-04-27 04:16:32', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life.
<br>
<br>
After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status.
<br>
<br>
Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads/2014-05/LizPonce_Resume/pdf">here</a>.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2014-05-06 02:23:13', '2014-05-06 02:23:13', '', 0, 'http://localhost:8888/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-04-27 04:16:32', '2014-04-27 04:16:32', 'Hi! Here is the section about yours truly!', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-04-27 04:16:32', '2014-04-27 04:16:32', '', 4, 'http://localhost:8888/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-04-27 04:16:52', '2014-04-27 04:16:52', 'Follow/Tweet Me - <a style="color: #005bad;" href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a style="color: #005bad;" href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-05-06 13:02:44', '2014-05-06 13:02:44', '', 0, 'http://localhost:8888/?page_id=6', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-04-27 04:16:52', '2014-04-27 04:16:52', 'Contact me!', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-04-27 04:16:52', '2014-04-27 04:16:52', '', 6, 'http://localhost:8888/?p=7', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-04-27 04:17:14', '2014-04-27 04:17:14', '', 'Graphic Design', '', 'trash', 'open', 'open', '', 'graphic-design', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 0, 'http://localhost:8888/?page_id=8', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-04-27 04:17:14', '2014-04-27 04:17:14', 'Here are my super cool graphics!', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-04-27 04:17:14', '2014-04-27 04:17:14', '', 8, 'http://localhost:8888/?p=9', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-04-27 04:17:33', '2014-04-27 04:17:33', 'Your CSS expert reporting here!', 'Web Design', '', 'trash', 'open', 'open', '', 'web-design', '', '', '2014-05-06 13:20:40', '2014-05-06 13:20:40', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-04-27 04:17:33', '2014-04-27 04:17:33', 'Your CSS expert reporting here!', 'Web Design', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-04-27 04:17:33', '2014-04-27 04:17:33', '', 10, 'http://localhost:8888/?p=11', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-04-27 04:17:53', '2014-04-27 04:17:53', 'What!? Pictures too??', 'Photography', '', 'trash', 'open', 'open', '', 'photography', '', '', '2014-05-06 13:20:40', '2014-05-06 13:20:40', '', 0, 'http://localhost:8888/?page_id=12', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-04-27 04:17:53', '2014-04-27 04:17:53', 'What!? Pictures too??', 'Photography', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-04-27 04:17:53', '2014-04-27 04:17:53', '', 12, 'http://localhost:8888/?p=13', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 'Downloads', '', 'publish', 'open', 'open', 'showmethemoney!', 'downloads', '', '', '2014-05-09 20:29:20', '2014-05-09 20:29:20', '', 0, 'http://localhost:8888/?page_id=14', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 'Downloadable Pictures', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-04-27 04:18:28', '2014-04-27 04:18:28', '', 14, 'http://localhost:8888/?p=15', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=17', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=18', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=19', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=20', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=21', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=22', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=23', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2014-04-30 21:39:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=24', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-04-30 21:40:41', '2014-04-30 21:40:41', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-05-08 01:41:43', '2014-05-08 01:41:43', '', 0, 'http://localhost:8888/?p=25', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2014-04-30 21:40:41', '2014-04-30 21:40:41', ' ', '', '', 'publish', 'open', 'open', '', '26', '', '', '2014-05-08 01:41:43', '2014-05-08 01:41:43', '', 0, 'http://localhost:8888/?p=26', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-04-30 21:40:41', '2014-04-30 21:40:41', ' ', '', '', 'publish', 'open', 'open', '', '27', '', '', '2014-05-08 01:41:44', '2014-05-08 01:41:44', '', 0, 'http://localhost:8888/?p=27', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2014-04-30 21:39:54', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=28', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-04-30 21:39:54', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-04-30 21:39:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=31', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2014-05-01 01:36:49', '2014-05-01 01:36:49', '', 'Hexagon', '', 'inherit', 'open', 'open', '', 'hexagon', '', '', '2014-05-01 01:36:49', '2014-05-01 01:36:49', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Hexagon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-05-01 01:40:02', '2014-05-01 01:40:02', '', 'LizPonce_WebLogo', '', 'inherit', 'open', 'open', '', 'lizponce_weblogo', '', '', '2014-05-01 01:40:02', '2014-05-01 01:40:02', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LizPonce_WebLogo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2014-05-01 02:42:56', '2014-05-01 02:42:56', '', 'WebDesign_Icon', '', 'inherit', 'open', 'open', '', 'webdesign_icon', '', '', '2014-05-01 02:42:56', '2014-05-01 02:42:56', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/WebDesign_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-05-01 02:42:57', '2014-05-01 02:42:57', '', 'Geometric_Icon', '', 'inherit', 'open', 'open', '', 'geometric_icon', '', '', '2014-05-01 02:42:57', '2014-05-01 02:42:57', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Geometric_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-05-01 02:42:58', '2014-05-01 02:42:58', '', 'Shutter_Icon', '', 'inherit', 'open', 'open', '', 'shutter_icon', '', '', '2014-05-01 02:42:58', '2014-05-01 02:42:58', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Shutter_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-05-01 03:09:24', '2014-05-01 03:09:24', '', 'Twitter_Icon', '', 'inherit', 'open', 'open', '', 'twitter_icon', '', '', '2014-05-01 03:09:24', '2014-05-01 03:09:24', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Twitter_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2014-05-01 03:09:25', '2014-05-01 03:09:25', '', 'LinkedIn_Icon', '', 'inherit', 'open', 'open', '', 'linkedin_icon', '', '', '2014-05-01 03:09:25', '2014-05-01 03:09:25', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LinkedIn_Icon.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-05-01 04:08:58', '2014-05-01 04:08:58', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads">here.', 'About', '', 'inherit', 'open', 'open', '', '4-autosave-v1', '', '', '2014-05-01 04:08:58', '2014-05-01 04:08:58', '', 4, 'http://localhost:8888/4-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-05-01 04:04:23', '2014-05-01 04:04:23', 'Hello! My name is Liz Ponce and I am a Graphic Designer, Web Designer and Photographer. How did I get here you ask? Well, let me explain...

At the tender age of 16, I started took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:04:23', '2014-05-01 04:04:23', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2014-05-01 04:04:56', '2014-05-01 04:04:56', 'Hello! My name is Liz Ponce and I am a Graphic Designer, Web Designer and Photographer. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:04:56', '2014-05-01 04:04:56', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-05-01 04:06:56', '2014-05-01 04:06:56', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:06:56', '2014-05-01 04:06:56', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2014-05-01 04:09:20', '2014-05-01 04:09:20', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life. After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status. Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads/2014-05/LizPonce_Resume/pdf">here</a>.', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-01 04:09:20', '2014-05-01 04:09:20', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2014-05-06 02:23:13', '2014-05-06 02:23:13', 'Hello! My name is Liz Ponce and I am a <strong>Graphic Designer, Web Designer and Photographer</strong>. How did I get here you ask? Well, let me explain...

At the tender age of 16, I took my very first Graphic Design class while attending high school in the sahara they call Arizona (moving from Chicago, my body was not yet adjusted to the heat). After that, as they say, the rest is history! I was hooked on design right from the get-go and knew that I would continue to do this for the rest of my life.
<br>
<br>
After graduating high school, I continued on to major in Graphic Design, taking classes at a few colleges before finally settling on Collins College. While at Collins, I gained a wealth of knowledge from my teachers there and finished off my Bachelor\'s degree with Magna Cum Laude honors and even achieved the Valedictorian status.
<br>
<br>
Since graduating, I have worked at few places that have taken my knowledge and expertise farther than I ever imagined. I am always trying to learn as much as I can in the design world and enjoy being able to experience this growing industry!

Check out all of the great stuff that I have had the opportunity to work on and visit my <a href="/contact/">Contact</a> page for any design requests.

Download a copy of my resume <a href="/wp-content/uploads/2014-05/LizPonce_Resume/pdf">here</a>.', 'About', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-05-06 02:23:13', '2014-05-06 02:23:13', '', 4, 'http://localhost:8888/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2014-05-06 02:29:00', '2014-05-06 02:29:00', '<p>Your Name*<br />
    [text* your-name] </p>

<p>Your Email*<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Write Some Words<br />
    [textarea your-message] </p>

<p>[submit "Give Me a Shout"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)
liz@lizponce.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Liz Ponce (http://localhost:8888)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2014-05-06 02:32:11', '2014-05-06 02:32:11', '', 0, 'http://localhost:8888/?post_type=wpcf7_contact_form&#038;p=59', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2014-05-06 13:02:34', '2014-05-06 13:02:34', 'Follow/Tweet Me - <a style="color: #005bad;" href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a style="color: #005bad;" href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-autosave-v1', '', '', '2014-05-06 13:02:34', '2014-05-06 13:02:34', '', 6, 'http://localhost:8888/6-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-05-06 02:30:40', '2014-05-06 02:30:40', 'Contact me!
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-05-06 02:30:40', '2014-05-06 02:30:40', '', 6, 'http://localhost:8888/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-05-06 02:34:55', '2014-05-06 02:34:55', 'Follow/Tweet Me - <a href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-05-06 02:34:55', '2014-05-06 02:34:55', '', 6, 'http://localhost:8888/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-05-06 13:02:07', '2014-05-06 13:02:07', 'Follow/Tweet Me - <a style="color: #005bad;" href="http://www.twitter.com/thelizponce">@thelizponce</a>
Let\'s Connect - <a style="color: #005bad;" href="www.linkedin.com/in/lizponce">Liz Ponce</a>
[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-05-06 13:02:07', '2014-05-06 13:02:07', '', 6, 'http://localhost:8888/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-05-07 04:01:54', '2014-05-07 04:01:54', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-autosave-v1', '', '', '2014-05-07 04:01:54', '2014-05-07 04:01:54', '', 8, 'http://localhost:8888/8-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-05-06 13:19:47', '2014-05-06 13:19:47', '', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-06 13:19:47', '2014-05-06 13:19:47', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-05-06 13:20:52', '2014-05-06 13:20:52', '', 'Work', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-06 13:20:52', '2014-05-06 13:20:52', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-05-06 14:56:56', '2014-05-06 14:56:56', '', 'Brookline College Flyers', '', 'trash', 'open', 'open', '', 'brookline-college-flyers', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=67', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2014-05-06 14:56:56', '2014-05-06 14:56:56', '<img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" />', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '67-revision-v1', '', '', '2014-05-06 14:56:56', '2014-05-06 14:56:56', '', 67, 'http://localhost:8888/67-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2014-05-06 14:57:55', '2014-05-06 14:57:55', '', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '67-revision-v1', '', '', '2014-05-06 14:57:55', '2014-05-06 14:57:55', '', 67, 'http://localhost:8888/67-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-05-07 02:27:37', '2014-05-07 02:27:37', '', 'Flyer', '', 'trash', 'open', 'open', '', 'flyer', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=71', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2014-05-07 02:27:37', '2014-05-07 02:27:37', '', 'Flyer', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-05-07 02:27:37', '2014-05-07 02:27:37', '', 71, 'http://localhost:8888/71-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2014-05-07 02:27:57', '2014-05-07 02:27:57', '<p>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
</p>
<p>
It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
</p>', 'Brookline College', '', 'trash', 'open', 'open', '', 'brookline-college', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=73', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-05-07 02:27:57', '2014-05-07 02:27:57', '', 'Brookline College', '', 'inherit', 'open', 'open', '', '73-revision-v1', '', '', '2014-05-07 02:27:57', '2014-05-07 02:27:57', '', 73, 'http://localhost:8888/73-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-05-07 02:28:43', '2014-05-07 02:28:43', '', 'Identity', '', 'trash', 'open', 'open', '', 'identity', '', '', '2014-05-07 03:07:46', '2014-05-07 03:07:46', '', 0, 'http://localhost:8888/?post_type=portfolio&#038;p=75', 0, 'portfolio', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2014-05-07 02:28:43', '2014-05-07 02:28:43', '', 'Identity', '', 'inherit', 'open', 'open', '', '75-revision-v1', '', '', '2014-05-07 02:28:43', '2014-05-07 02:28:43', '', 75, 'http://localhost:8888/75-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2014-05-07 02:40:02', '2014-05-07 02:40:02', '<p>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
</p>
<p>
It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
</p>', 'Brookline College', '', 'inherit', 'open', 'open', '', '73-revision-v1', '', '', '2014-05-07 02:40:02', '2014-05-07 02:40:02', '', 73, 'http://localhost:8888/73-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2014-05-07 02:53:12', '2014-05-07 02:53:12', '[af-portfolio]', 'Work', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 02:53:12', '2014-05-07 02:53:12', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2014-05-07 03:08:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-07 03:08:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=80', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2014-05-07 03:10:01', '2014-05-07 03:10:01', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 03:10:01', '2014-05-07 03:10:01', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2014-05-07 03:12:04', '2014-05-07 03:12:04', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-150x150.png" alt="" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:12:04', '2014-05-07 03:12:04', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2014-05-07 03:13:35', '2014-05-07 03:13:35', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x300.png" alt="" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:13:35', '2014-05-07 03:13:35', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2014-05-07 03:14:22', '2014-05-07 03:14:22', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:14:22', '2014-05-07 03:14:22', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2014-05-07 03:14:57', '2014-05-07 03:14:57', '', 'Web Design', '', 'trash', 'open', 'open', '', 'web-design', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 91, 'http://localhost:8888/?page_id=85', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-05-07 03:14:57', '2014-05-07 03:14:57', '', 'Web Design', '', 'inherit', 'open', 'open', '', '85-revision-v1', '', '', '2014-05-07 03:14:57', '2014-05-07 03:14:57', '', 85, 'http://localhost:8888/85-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-05-07 03:15:29', '2014-05-07 03:15:29', '', 'Photography', '', 'trash', 'open', 'open', '', 'photography', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 91, 'http://localhost:8888/?page_id=87', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-05-07 03:15:29', '2014-05-07 03:15:29', '', 'Photography', '', 'inherit', 'open', 'open', '', '87-revision-v1', '', '', '2014-05-07 03:15:29', '2014-05-07 03:15:29', '', 87, 'http://localhost:8888/87-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-05-07 03:19:35', '2014-05-07 03:19:35', '', 'Portfolio', '', 'trash', 'open', 'open', '', 'portfolio', '', '', '2014-05-08 01:41:18', '2014-05-08 01:41:18', '', 0, 'http://localhost:8888/?page_id=91', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-05-07 03:19:35', '2014-05-07 03:19:35', '', 'Portfolio', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2014-05-07 03:19:35', '2014-05-07 03:19:35', '', 91, 'http://localhost:8888/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-05-07 03:56:18', '2014-05-07 03:56:18', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers-300x198.png" alt="BC_flyers" width="300" height="198" class="alignnone size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 03:56:18', '2014-05-07 03:56:18', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-05-07 04:02:57', '2014-05-07 04:02:57', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>

<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_flyers.png" alt="BC_flyers" width="360" height="360" class="alignleft size-medium wp-image-68" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 04:02:57', '2014-05-07 04:02:57', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2014-05-07 14:20:25', '2014-05-07 14:20:25', '', 'BC_Flyers', '', 'inherit', 'open', 'open', '', 'bc_flyers', '', '', '2014-05-07 14:20:25', '2014-05-07 14:20:25', '', 1, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2014-05-07 14:20:26', '2014-05-07 14:20:26', '', 'BC_Poster', '', 'inherit', 'open', 'open', '', 'bc_poster', '', '', '2014-05-07 14:20:26', '2014-05-07 14:20:26', '', 141, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Poster.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2014-05-07 14:20:29', '2014-05-07 14:20:29', '', 'BC_Homepage', '', 'inherit', 'open', 'open', '', 'bc_homepage', '', '', '2014-05-07 14:20:29', '2014-05-07 14:20:29', '', 148, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Homepage.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-05-07 14:20:30', '2014-05-07 14:20:30', '', 'BC_NewsAds', '', 'inherit', 'open', 'open', '', 'bc_newsads', '', '', '2014-05-07 14:20:30', '2014-05-07 14:20:30', '', 146, 'http://localhost:8888/wp-content/uploads/2014/05/BC_NewsAds.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-05-07 14:20:31', '2014-05-07 14:20:31', '', 'NG_Seminar', '', 'inherit', 'open', 'open', '', 'ng_seminar', '', '', '2014-05-07 14:20:31', '2014-05-07 14:20:31', '', 154, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-05-07 14:20:32', '2014-05-07 14:20:32', '', 'NG_Web', '', 'inherit', 'open', 'open', '', 'ng_web', '', '', '2014-05-07 14:20:32', '2014-05-07 14:20:32', '', 156, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Web.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-05-07 14:20:33', '2014-05-07 14:20:33', '', 'CS_Billboard', '', 'inherit', 'open', 'open', '', 'cs_billboard', '', '', '2014-05-07 14:20:33', '2014-05-07 14:20:33', '', 158, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-05-07 14:20:34', '2014-05-07 14:20:34', '', 'CS_Mag', '', 'inherit', 'open', 'open', '', 'cs_mag', '', '', '2014-05-07 14:20:34', '2014-05-07 14:20:34', '', 160, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Mag.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-05-07 14:20:35', '2014-05-07 14:20:35', '', 'HC_Flyer', '', 'inherit', 'open', 'open', '', 'hc_flyer', '', '', '2014-05-07 14:20:35', '2014-05-07 14:20:35', '', 162, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Flyer.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-05-07 14:20:36', '2014-05-07 14:20:36', '', 'LilWayne_Poster', '', 'inherit', 'open', 'open', '', 'lilwayne_poster', '', '', '2014-05-07 14:20:36', '2014-05-07 14:20:36', '', 164, 'http://localhost:8888/wp-content/uploads/2014/05/LilWayne_Poster.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2014-05-07 14:20:40', '2014-05-07 14:20:40', '', 'HC_Homepage', '', 'inherit', 'open', 'open', '', 'hc_homepage', '', '', '2014-05-07 14:20:40', '2014-05-07 14:20:40', '', 166, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Homepage.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2014-05-07 14:20:41', '2014-05-07 14:20:41', '', 'Label_MeatPackaging', '', 'inherit', 'open', 'open', '', 'label_meatpackaging', '', '', '2014-05-07 14:20:41', '2014-05-07 14:20:41', '', 168, 'http://localhost:8888/wp-content/uploads/2014/05/Label_MeatPackaging.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2014-05-07 14:20:42', '2014-05-07 14:20:42', '', 'Shirt_Millenium', '', 'inherit', 'open', 'open', '', 'shirt_millenium', '', '', '2014-05-07 14:20:42', '2014-05-07 14:20:42', '', 170, 'http://localhost:8888/wp-content/uploads/2014/05/Shirt_Millenium.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2014-05-07 14:20:43', '2014-05-07 14:20:43', '', 'Wine_TerraNova', '', 'inherit', 'open', 'open', '', 'wine_terranova', '', '', '2014-05-07 14:20:43', '2014-05-07 14:20:43', '', 172, 'http://localhost:8888/wp-content/uploads/2014/05/Wine_TerraNova.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2014-05-07 14:20:46', '2014-05-07 14:20:46', '', 'Wayfinding_Cart', '', 'inherit', 'open', 'open', '', 'wayfinding_cart', '', '', '2014-05-07 14:20:46', '2014-05-07 14:20:46', '', 174, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2014-05-07 14:20:47', '2014-05-07 14:20:47', '', 'TypeChronology', '', 'inherit', 'open', 'open', '', 'typechronology', '', '', '2014-05-07 14:20:47', '2014-05-07 14:20:47', '', 176, 'http://localhost:8888/wp-content/uploads/2014/05/TypeChronology.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2014-05-07 14:20:48', '2014-05-07 14:20:48', '', 'Wayfinding_App', '', 'inherit', 'open', 'open', '', 'wayfinding_app', '', '', '2014-05-07 14:20:48', '2014-05-07 14:20:48', '', 178, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_App.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2014-05-07 14:20:51', '2014-05-07 14:20:51', '', 'Windstar_Logo', '', 'inherit', 'open', 'open', '', 'windstar_logo', '', '', '2014-05-07 14:20:51', '2014-05-07 14:20:51', '', 180, 'http://localhost:8888/wp-content/uploads/2014/05/Windstar_Logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2014-05-07 14:21:07', '2014-05-07 14:21:07', '', 'BC_Homepage_TN', '', 'inherit', 'open', 'open', '', 'bc_homepage_tn', '', '', '2014-05-07 14:21:07', '2014-05-07 14:21:07', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Homepage_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2014-05-07 14:21:08', '2014-05-07 14:21:08', '', 'BC_Flyers_TN', '', 'inherit', 'open', 'open', '', 'bc_flyers_tn', '', '', '2014-05-07 14:21:08', '2014-05-07 14:21:08', '', 8, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2014-05-07 14:21:09', '2014-05-07 14:21:09', '', 'BC_NewsAds_TN', '', 'inherit', 'open', 'open', '', 'bc_newsads_tn', '', '', '2014-05-07 14:21:09', '2014-05-07 14:21:09', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BC_NewsAds_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2014-05-07 14:21:10', '2014-05-07 14:21:10', '', 'BC_Poster_TN', '', 'inherit', 'open', 'open', '', 'bc_poster_tn', '', '', '2014-05-07 14:21:10', '2014-05-07 14:21:10', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BC_Poster_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-05-07 14:21:11', '2014-05-07 14:21:11', '', 'NG_Seminar_TN', '', 'inherit', 'open', 'open', '', 'ng_seminar_tn', '', '', '2014-05-07 14:21:11', '2014-05-07 14:21:11', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-05-07 14:21:12', '2014-05-07 14:21:12', '', 'CS_Mag_TN', '', 'inherit', 'open', 'open', '', 'cs_mag_tn', '', '', '2014-05-07 14:21:12', '2014-05-07 14:21:12', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Mag_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2014-05-07 14:21:13', '2014-05-07 14:21:13', '', 'CS_Billboard_TN', '', 'inherit', 'open', 'open', '', 'cs_billboard_tn', '', '', '2014-05-07 14:21:13', '2014-05-07 14:21:13', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2014-05-07 14:21:14', '2014-05-07 14:21:14', '', 'NG_Web_TN', '', 'inherit', 'open', 'open', '', 'ng_web_tn', '', '', '2014-05-07 14:21:14', '2014-05-07 14:21:14', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/NG_Web_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 'HC_Flyer_TN', '', 'inherit', 'open', 'open', '', 'hc_flyer_tn', '', '', '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Flyer_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 'HC_Homepage_TN', '', 'inherit', 'open', 'open', '', 'hc_homepage_tn', '', '', '2014-05-07 14:21:15', '2014-05-07 14:21:15', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/HC_Homepage_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2014-05-07 14:21:16', '2014-05-07 14:21:16', '', 'LilWayne_Poster_TN', '', 'inherit', 'open', 'open', '', 'lilwayne_poster_tn', '', '', '2014-05-07 14:21:16', '2014-05-07 14:21:16', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LilWayne_Poster_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2014-05-07 14:21:17', '2014-05-07 14:21:17', '', 'Label_MeatPackaging_TN', '', 'inherit', 'open', 'open', '', 'label_meatpackaging_tn', '', '', '2014-05-07 14:21:17', '2014-05-07 14:21:17', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Label_MeatPackaging_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2014-05-07 14:21:18', '2014-05-07 14:21:18', '', 'Shirt_Millenium_TN', '', 'inherit', 'open', 'open', '', 'shirt_millenium_tn', '', '', '2014-05-07 14:21:18', '2014-05-07 14:21:18', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Shirt_Millenium_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2014-05-07 14:21:19', '2014-05-07 14:21:19', '', 'Wine_TerraNova_TN', '', 'inherit', 'open', 'open', '', 'wine_terranova_tn', '', '', '2014-05-07 14:21:19', '2014-05-07 14:21:19', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Wine_TerraNova_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 'TypeChronology_TN', '', 'inherit', 'open', 'open', '', 'typechronology_tn', '', '', '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/TypeChronology_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 'Wayfinding_Cart_TN', '', 'inherit', 'open', 'open', '', 'wayfinding_cart_tn', '', '', '2014-05-07 14:21:21', '2014-05-07 14:21:21', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2014-05-07 14:21:22', '2014-05-07 14:21:22', '', 'Wayfinding_App_TN', '', 'inherit', 'open', 'open', '', 'wayfinding_app_tn', '', '', '2014-05-07 14:21:22', '2014-05-07 14:21:22', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_App_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2014-05-07 14:21:23', '2014-05-07 14:21:23', '', 'Windstar_Logo_TN', '', 'inherit', 'open', 'open', '', 'windstar_logo_tn', '', '', '2014-05-07 14:21:23', '2014-05-07 14:21:23', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Windstar_Logo_TN.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2014-05-08 03:10:29', '2014-05-08 03:10:29', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<di
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-autosave-v1', '', '', '2014-05-08 03:10:29', '2014-05-08 03:10:29', '', 1, 'http://localhost:8888/1-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (136, 1, '2014-05-07 14:25:56', '2014-05-07 14:25:56', '<p>I designed these flyers while working at my internship at Brookline College. They were intended to promote the new programs available to students and once completed were hung around the several campuses around the valley.</p> 

<p>Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 14:25:56', '2014-05-07 14:25:56', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (137, 1, '2014-05-07 14:26:50', '2014-05-07 14:26:50', '<a href="/?p=1/"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers_TN.png" alt="BC_Flyers_TN" width="360" height="360" class="alignnone size-full wp-image-118" /></a>', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 14:26:50', '2014-05-07 14:26:50', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (138, 1, '2014-05-07 14:31:12', '2014-05-07 14:31:12', '<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p>Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 14:31:12', '2014-05-07 14:31:12', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2014-05-07 14:32:24', '2014-05-07 14:32:24', '<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-07 14:32:24', '2014-05-07 14:32:24', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2014-05-07 14:38:16', '2014-05-07 14:38:16', '', 'Graphic Design', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-05-07 14:38:16', '2014-05-07 14:38:16', '', 8, 'http://localhost:8888/8-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2014-05-08 01:37:20', '2014-05-08 01:37:20', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'publish', 'open', 'open', '', 'brookline-college-poster', '', '', '2014-05-09 04:19:54', '2014-05-09 04:19:54', '', 0, 'http://localhost:8888/?p=141', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (142, 1, '2014-05-08 01:37:20', '2014-05-08 01:37:20', '', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-revision-v1', '', '', '2014-05-08 01:37:20', '2014-05-08 01:37:20', '', 141, 'http://localhost:8888/141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (143, 1, '2014-05-08 01:39:24', '2014-05-08 01:39:24', ' ', '', '', 'publish', 'open', 'open', '', '143', '', '', '2014-05-08 01:41:43', '2014-05-08 01:41:43', '', 0, 'http://localhost:8888/?p=143', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (144, 1, '2014-05-08 01:41:44', '2014-05-08 01:41:44', ' ', '', '', 'publish', 'open', 'open', '', '144', '', '', '2014-05-08 01:41:44', '2014-05-08 01:41:44', '', 0, 'http://localhost:8888/?p=144', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2014-05-08 01:41:44', '2014-05-08 01:41:44', ' ', '', '', 'publish', 'open', 'open', '', '145', '', '', '2014-05-08 01:41:44', '2014-05-08 01:41:44', '', 0, 'http://localhost:8888/?p=145', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2014-05-08 01:45:09', '2014-05-08 01:45:09', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_NewsAds.png" alt="BC_NewsAds" width="580" height="486" class="alignnone size-full wp-image-102" /></div>

<div class="post-description">
<h1>Brookline College Advertisements</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Advertisements', '', 'publish', 'open', 'open', '', 'brookline-college-ads', '', '', '2014-05-09 04:19:43', '2014-05-09 04:19:43', '', 0, 'http://localhost:8888/?p=146', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2014-05-08 01:45:09', '2014-05-08 01:45:09', '', 'Brookline College Ads', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-08 01:45:09', '2014-05-08 01:45:09', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (148, 1, '2014-05-08 02:13:07', '2014-05-08 02:13:07', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Homepage.png" alt="BC_Homepage" width="992" height="410" class="alignnone size-full wp-image-101" /></div>

<div class="post-description">
<h1>Brookline College Graphics</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Brookline College Graphics', '', 'publish', 'open', 'open', '', 'brookline-college-graphics', '', '', '2014-05-09 04:15:23', '2014-05-09 04:15:23', '', 0, 'http://localhost:8888/?p=148', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2014-05-08 02:13:07', '2014-05-08 02:13:07', '', 'Brookline College Graphics', '', 'inherit', 'open', 'open', '', '148-revision-v1', '', '', '2014-05-08 02:13:07', '2014-05-08 02:13:07', '', 148, 'http://localhost:8888/148-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2014-05-08 03:09:26', '2014-05-08 03:09:26', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:09:26', '2014-05-08 03:09:26', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (151, 1, '2014-05-08 03:11:03', '2014-05-08 03:11:03', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</p>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:11:03', '2014-05-08 03:11:03', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (152, 1, '2014-05-08 03:11:16', '2014-05-08 03:11:16', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:11:16', '2014-05-08 03:11:16', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (153, 1, '2014-05-08 03:12:10', '2014-05-08 03:12:10', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Brookline College Flyers</h1>
<hr class="content-title-rule">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-08 03:12:10', '2014-05-08 03:12:10', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2014-05-08 13:13:35', '2014-05-08 13:13:35', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'publish', 'open', 'open', '', 'next-generation-itinerary', '', '', '2014-05-09 04:19:22', '2014-05-09 04:19:22', '', 0, 'http://localhost:8888/?p=154', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (155, 1, '2014-05-08 13:13:35', '2014-05-08 13:13:35', '', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-05-08 13:13:35', '2014-05-08 13:13:35', '', 154, 'http://localhost:8888/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (156, 1, '2014-05-08 13:17:36', '2014-05-08 13:17:36', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Web.png" alt="NG_Web" width="1000" height="691" class="alignnone size-full wp-image-104" /></div>

<div class="post-description">
<h1>Next Generation<br>Registration Form</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Next Generation Registration Form', '', 'publish', 'open', 'open', '', 'next-generation-registration-form', '', '', '2014-05-09 04:14:26', '2014-05-09 04:14:26', '', 0, 'http://localhost:8888/?p=156', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (157, 1, '2014-05-08 13:17:36', '2014-05-08 13:17:36', '', 'Next Generation Registration Form', '', 'inherit', 'open', 'open', '', '156-revision-v1', '', '', '2014-05-08 13:17:36', '2014-05-08 13:17:36', '', 156, 'http://localhost:8888/156-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (158, 1, '2014-05-08 13:18:28', '2014-05-08 13:18:28', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Billboard', '', 'publish', 'open', 'open', '', 'calsium-billboard', '', '', '2014-05-09 04:19:14', '2014-05-09 04:19:14', '', 0, 'http://localhost:8888/?p=158', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (159, 1, '2014-05-08 13:18:28', '2014-05-08 13:18:28', '', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-08 13:18:28', '2014-05-08 13:18:28', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (160, 1, '2014-05-08 13:18:57', '2014-05-08 13:18:57', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Mag.png" alt="CS_Mag" width="1000" height="682" class="alignnone size-full wp-image-106" /></div>

<div class="post-description">
<h1>calsium Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Advertisement', '', 'publish', 'open', 'open', '', 'calsium-magazine-ad', '', '', '2014-05-09 04:18:41', '2014-05-09 04:18:41', '', 0, 'http://localhost:8888/?p=160', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (161, 1, '2014-05-08 13:18:57', '2014-05-08 13:18:57', '', 'calsium Magazine Ad', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-08 13:18:57', '2014-05-08 13:18:57', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (162, 1, '2014-05-08 13:20:35', '2014-05-08 13:20:35', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Flyer.png" alt="HC_Flyer" width="1000" height="597" class="alignnone size-full wp-image-107" /></div>

<div class="post-description">
<h1>HomeCure Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'HomeCure Advertisement', '', 'publish', 'open', 'open', '', 'homecure-multi-page-advertisement', '', '', '2014-05-09 04:18:24', '2014-05-09 04:18:24', '', 0, 'http://localhost:8888/?p=162', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (163, 1, '2014-05-08 13:20:35', '2014-05-08 13:20:35', '', 'HomeCure Multi-Page Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-08 13:20:35', '2014-05-08 13:20:35', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (164, 1, '2014-05-08 13:21:06', '2014-05-08 13:21:06', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/LilWayne_Poster.png" alt="LilWayne_Poster" width="1000" height="1187" class="alignnone size-full wp-image-108" /></div>

<div class="post-description">
<h1>Concert Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Concert Poster', '', 'publish', 'open', 'open', '', 'concert-poster', '', '', '2014-05-09 04:18:10', '2014-05-09 04:18:10', '', 0, 'http://localhost:8888/?p=164', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (165, 1, '2014-05-08 13:21:06', '2014-05-08 13:21:06', '', 'Concert Poster', '', 'inherit', 'open', 'open', '', '164-revision-v1', '', '', '2014-05-08 13:21:06', '2014-05-08 13:21:06', '', 164, 'http://localhost:8888/164-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (166, 1, '2014-05-08 13:22:16', '2014-05-08 13:22:16', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Homepage.png" alt="HC_Homepage" width="1000" height="594" class="alignnone size-full wp-image-109" /></div>

<div class="post-description">
<h1>HomeCure Website</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'HomeCure Website', '', 'publish', 'open', 'open', '', 'homecure-website', '', '', '2014-05-09 04:12:23', '2014-05-09 04:12:23', '', 0, 'http://localhost:8888/?p=166', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (167, 1, '2014-05-08 13:22:16', '2014-05-08 13:22:16', '', 'HomeCure Website', '', 'inherit', 'open', 'open', '', '166-revision-v1', '', '', '2014-05-08 13:22:16', '2014-05-08 13:22:16', '', 166, 'http://localhost:8888/166-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (168, 1, '2014-05-08 13:22:50', '2014-05-08 13:22:50', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Label_MeatPackaging.png" alt="Label_MeatPackaging" width="862" height="750" class="alignnone size-full wp-image-110" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'publish', 'open', 'open', '', 'meat-package-label', '', '', '2014-05-09 04:17:56', '2014-05-09 04:17:56', '', 0, 'http://localhost:8888/?p=168', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (169, 1, '2014-05-08 13:22:50', '2014-05-08 13:22:50', '', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-08 13:22:50', '2014-05-08 13:22:50', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (170, 1, '2014-05-08 13:23:49', '2014-05-08 13:23:49', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Shirt_Millenium.png" alt="Shirt_Millenium" width="675" height="882" class="alignnone size-full wp-image-111" /></div>

<div class="post-description">
<h1>Millennium Shirt</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Millennium Shirt', '', 'publish', 'open', 'open', '', 'millennium-shirt', '', '', '2014-05-09 04:17:33', '2014-05-09 04:17:33', '', 0, 'http://localhost:8888/?p=170', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (171, 1, '2014-05-08 13:23:49', '2014-05-08 13:23:49', '', 'Millennium Shirt', '', 'inherit', 'open', 'open', '', '170-revision-v1', '', '', '2014-05-08 13:23:49', '2014-05-08 13:23:49', '', 170, 'http://localhost:8888/170-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (172, 1, '2014-05-08 13:24:27', '2014-05-08 13:24:27', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wine_TerraNova.png" alt="Wine_TerraNova" width="1000" height="1191" class="alignnone size-full wp-image-112" /></div>

<div class="post-description">
<h1>Terra Nova Wine Bottle</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Terra Nova Wine Bottle', '', 'publish', 'open', 'open', '', 'terra-nova-wine-bottle', '', '', '2014-05-09 04:17:18', '2014-05-09 04:17:18', '', 0, 'http://localhost:8888/?p=172', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (173, 1, '2014-05-08 13:24:27', '2014-05-08 13:24:27', '', 'Terra Nova Wine Bottle', '', 'inherit', 'open', 'open', '', '172-revision-v1', '', '', '2014-05-08 13:24:27', '2014-05-08 13:24:27', '', 172, 'http://localhost:8888/172-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (174, 1, '2014-05-08 13:24:58', '2014-05-08 13:24:58', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Grocery Store Wayfinding', '', 'publish', 'open', 'open', '', 'grocery-store-wayfinding', '', '', '2014-05-09 04:17:03', '2014-05-09 04:17:03', '', 0, 'http://localhost:8888/?p=174', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (175, 1, '2014-05-08 13:24:58', '2014-05-08 13:24:58', '', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-revision-v1', '', '', '2014-05-08 13:24:58', '2014-05-08 13:24:58', '', 174, 'http://localhost:8888/174-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (176, 1, '2014-05-08 13:25:33', '2014-05-08 13:25:33', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/TypeChronology.png" alt="TypeChronology" width="1000" height="564" class="alignnone size-full wp-image-114" /></div>

<div class="post-description">
<h1>Type Chronology</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Type Chronology', '', 'publish', 'open', 'open', '', 'type-chronology', '', '', '2014-05-09 04:16:49', '2014-05-09 04:16:49', '', 0, 'http://localhost:8888/?p=176', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (177, 1, '2014-05-08 13:25:33', '2014-05-08 13:25:33', '', 'Type Chronology', '', 'inherit', 'open', 'open', '', '176-revision-v1', '', '', '2014-05-08 13:25:33', '2014-05-08 13:25:33', '', 176, 'http://localhost:8888/176-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (178, 1, '2014-05-08 13:26:04', '2014-05-08 13:26:04', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_App.png" alt="Wayfinding_App" width="1000" height="1152" class="alignnone size-full wp-image-115" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding App</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Grocery Store Wayfinding App', '', 'publish', 'open', 'open', '', 'grocery-store-wayfinding-app', '', '', '2014-05-09 04:11:07', '2014-05-09 04:11:07', '', 0, 'http://localhost:8888/?p=178', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (179, 1, '2014-05-08 13:26:04', '2014-05-08 13:26:04', '', 'Grocery Store Wayfinding App', '', 'inherit', 'open', 'open', '', '178-revision-v1', '', '', '2014-05-08 13:26:04', '2014-05-08 13:26:04', '', 178, 'http://localhost:8888/178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (180, 1, '2014-05-08 13:26:28', '2014-05-08 13:26:28', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Windstar_Logo.png" alt="Windstar_Logo" width="868" height="569" class="alignnone size-full wp-image-116" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'publish', 'open', 'open', '', 'windstar-logo', '', '', '2014-05-09 04:16:35', '2014-05-09 04:16:35', '', 0, 'http://localhost:8888/?p=180', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (181, 1, '2014-05-08 13:26:28', '2014-05-08 13:26:28', '', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-08 13:26:28', '2014-05-08 13:26:28', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (182, 1, '2014-05-08 13:27:51', '2014-05-08 13:27:51', '', 'HomeCure Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-08 13:27:51', '2014-05-08 13:27:51', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (183, 1, '2014-05-08 13:28:28', '2014-05-08 13:28:28', '', 'calsium Advertisement', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-08 13:28:28', '2014-05-08 13:28:28', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (184, 1, '2014-05-08 13:29:03', '2014-05-08 13:29:03', '', 'Brookline College Advertisements', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-08 13:29:03', '2014-05-08 13:29:03', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (185, 1, '2014-05-09 03:45:34', '2014-05-09 03:45:34', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-09 03:45:34', '2014-05-09 03:45:34', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (186, 1, '2014-05-09 03:46:38', '2014-05-09 03:46:38', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/TypeChronology.png" alt="TypeChronology" width="1000" height="564" class="alignnone size-full wp-image-114" /></div>

<div class="post-description">
<h1>Type Chronology</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Type Chronology', '', 'inherit', 'open', 'open', '', '176-revision-v1', '', '', '2014-05-09 03:46:38', '2014-05-09 03:46:38', '', 176, 'http://localhost:8888/176-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (187, 1, '2014-05-09 03:47:11', '2014-05-09 03:47:11', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Windstar_Logo.png" alt="Windstar_Logo" width="868" height="569" class="alignnone size-full wp-image-116" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-09 03:47:11', '2014-05-09 03:47:11', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (188, 1, '2014-05-09 03:55:25', '2014-05-09 03:55:25', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-autosave-v1', '', '', '2014-05-09 03:55:25', '2014-05-09 03:55:25', '', 174, 'http://localhost:8888/174-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (189, 1, '2014-05-09 03:55:59', '2014-05-09 03:55:59', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-revision-v1', '', '', '2014-05-09 03:55:59', '2014-05-09 03:55:59', '', 174, 'http://localhost:8888/174-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (190, 1, '2014-05-09 03:57:10', '2014-05-09 03:57:10', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wine_TerraNova.png" alt="Wine_TerraNova" width="1000" height="1191" class="alignnone size-full wp-image-112" /></div>

<div class="post-description">
<h1>Terra Nova Wine Bottle</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Terra Nova Wine Bottle', '', 'inherit', 'open', 'open', '', '172-revision-v1', '', '', '2014-05-09 03:57:10', '2014-05-09 03:57:10', '', 172, 'http://localhost:8888/172-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (191, 1, '2014-05-09 03:58:25', '2014-05-09 03:58:25', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Shirt_Millenium.png" alt="Shirt_Millenium" width="675" height="882" class="alignnone size-full wp-image-111" /></div>

<div class="post-description">
<h1>Millennium Shirt</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Millennium Shirt', '', 'inherit', 'open', 'open', '', '170-revision-v1', '', '', '2014-05-09 03:58:25', '2014-05-09 03:58:25', '', 170, 'http://localhost:8888/170-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (192, 1, '2014-05-09 03:59:29', '2014-05-09 03:59:29', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-09 03:59:29', '2014-05-09 03:59:29', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (193, 1, '2014-05-09 03:59:58', '2014-05-09 03:59:58', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Label_MeatPackaging.png" alt="Label_MeatPackaging" width="862" height="750" class="alignnone size-full wp-image-110" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-09 03:59:58', '2014-05-09 03:59:58', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (194, 1, '2014-05-09 04:01:08', '2014-05-09 04:01:08', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/LilWayne_Poster.png" alt="LilWayne_Poster" width="1000" height="1187" class="alignnone size-full wp-image-108" /></div>

<div class="post-description">
<h1>Concert Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Concert Poster', '', 'inherit', 'open', 'open', '', '164-revision-v1', '', '', '2014-05-09 04:01:08', '2014-05-09 04:01:08', '', 164, 'http://localhost:8888/164-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (195, 1, '2014-05-09 04:02:19', '2014-05-09 04:02:19', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/HC_Flyer.png" alt="HC_Flyer" width="1000" height="597" class="alignnone size-full wp-image-107" /></div>

<div class="post-description">
<h1>HomeCure Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'HomeCure Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-09 04:02:19', '2014-05-09 04:02:19', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (196, 1, '2014-05-09 04:03:26', '2014-05-09 04:03:26', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/CS_Mag.png" alt="CS_Mag" width="1000" height="682" class="alignnone size-full wp-image-106" /></div>

<div class="post-description">
<h1>calsium Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Advertisement', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-09 04:03:26', '2014-05-09 04:03:26', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (197, 1, '2014-05-09 04:04:17', '2014-05-09 04:04:17', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-09 04:04:17', '2014-05-09 04:04:17', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (198, 1, '2014-05-09 04:06:01', '2014-05-09 04:06:01', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-autosave-v1', '', '', '2014-05-09 04:06:01', '2014-05-09 04:06:01', '', 154, 'http://localhost:8888/154-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (199, 1, '2014-05-09 04:06:08', '2014-05-09 04:06:08', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-05-09 04:06:08', '2014-05-09 04:06:08', '', 154, 'http://localhost:8888/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (200, 1, '2014-05-09 04:07:21', '2014-05-09 04:07:21', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-09 04:07:21', '2014-05-09 04:07:21', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (201, 1, '2014-05-09 04:08:44', '2014-05-09 04:08:44', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_NewsAds.png" alt="BC_NewsAds" width="580" height="486" class="alignnone size-full wp-image-102" /></div>

<div class="post-description">
<h1>Brookline College Advertisements</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Advertisements', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-09 04:08:44', '2014-05-09 04:08:44', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (202, 1, '2014-05-09 04:09:47', '2014-05-09 04:09:47', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-revision-v1', '', '', '2014-05-09 04:09:47', '2014-05-09 04:09:47', '', 141, 'http://localhost:8888/141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (203, 1, '2014-05-09 04:10:56', '2014-05-09 04:10:56', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Wayfinding_App.png" alt="Wayfinding_App" width="1000" height="1152" class="alignnone size-full wp-image-115" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding App</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Grocery Store Wayfinding App', '', 'inherit', 'open', 'open', '', '178-revision-v1', '', '', '2014-05-09 04:10:56', '2014-05-09 04:10:56', '', 178, 'http://localhost:8888/178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (204, 1, '2014-05-09 04:11:07', '2014-05-09 04:11:07', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_App.png" alt="Wayfinding_App" width="1000" height="1152" class="alignnone size-full wp-image-115" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding App</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Grocery Store Wayfinding App', '', 'inherit', 'open', 'open', '', '178-revision-v1', '', '', '2014-05-09 04:11:07', '2014-05-09 04:11:07', '', 178, 'http://localhost:8888/178-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (205, 1, '2014-05-09 04:12:23', '2014-05-09 04:12:23', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Homepage.png" alt="HC_Homepage" width="1000" height="594" class="alignnone size-full wp-image-109" /></div>

<div class="post-description">
<h1>HomeCure Website</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'HomeCure Website', '', 'inherit', 'open', 'open', '', '166-revision-v1', '', '', '2014-05-09 04:12:23', '2014-05-09 04:12:23', '', 166, 'http://localhost:8888/166-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (206, 1, '2014-05-09 04:14:02', '2014-05-09 04:14:02', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Web.png" alt="NG_Web" width="1000" height="691" class="alignnone size-full wp-image-104" /></div>

<div class="post-description">
<h1>Next Generation Registration Form</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Next Generation Registration Form', '', 'inherit', 'open', 'open', '', '156-revision-v1', '', '', '2014-05-09 04:14:02', '2014-05-09 04:14:02', '', 156, 'http://localhost:8888/156-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (207, 1, '2014-05-09 04:14:26', '2014-05-09 04:14:26', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Web.png" alt="NG_Web" width="1000" height="691" class="alignnone size-full wp-image-104" /></div>

<div class="post-description">
<h1>Next Generation<br>Registration Form</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Next Generation Registration Form', '', 'inherit', 'open', 'open', '', '156-revision-v1', '', '', '2014-05-09 04:14:26', '2014-05-09 04:14:26', '', 156, 'http://localhost:8888/156-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (208, 1, '2014-05-09 04:15:23', '2014-05-09 04:15:23', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Homepage.png" alt="BC_Homepage" width="992" height="410" class="alignnone size-full wp-image-101" /></div>

<div class="post-description">
<h1>Brookline College Graphics</h1>
<hr class="content-title-rule">
<p></p>

</div>', 'Brookline College Graphics', '', 'inherit', 'open', 'open', '', '148-revision-v1', '', '', '2014-05-09 04:15:23', '2014-05-09 04:15:23', '', 148, 'http://localhost:8888/148-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (209, 1, '2014-05-09 04:15:59', '2014-05-09 04:15:59', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Flyers.png" alt="BC_Flyers" width="1000" height="662" class="alignnone size-full wp-image-99" /></div>

<div class="post-description">
<h1>Brookline College Flyers</h1>
<hr class="content-title-rule">
<p>I designed these flyers while working at my internship at Brookline College. The piece on the left was targeted towards getting more prospective students interested in the Dental programs. Once completed, the flyer was distributed electronically through social media to connect with the potential students.</p>
<p>The second piece on the right was designed promote new Saturday classes that were available to the current students at Brookline College. This finalized design was placed throughout the halls of the Phoenix campus and was also seen online through social media.</p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Flyers', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-05-09 04:15:59', '2014-05-09 04:15:59', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (210, 1, '2014-05-09 04:16:35', '2014-05-09 04:16:35', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Windstar_Logo.png" alt="Windstar_Logo" width="868" height="569" class="alignnone size-full wp-image-116" /></div>

<div class="post-description">
<h1>Windstar Logo</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Windstar Logo', '', 'inherit', 'open', 'open', '', '180-revision-v1', '', '', '2014-05-09 04:16:35', '2014-05-09 04:16:35', '', 180, 'http://localhost:8888/180-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (211, 1, '2014-05-09 04:16:49', '2014-05-09 04:16:49', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/TypeChronology.png" alt="TypeChronology" width="1000" height="564" class="alignnone size-full wp-image-114" /></div>

<div class="post-description">
<h1>Type Chronology</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Type Chronology', '', 'inherit', 'open', 'open', '', '176-revision-v1', '', '', '2014-05-09 04:16:49', '2014-05-09 04:16:49', '', 176, 'http://localhost:8888/176-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (212, 1, '2014-05-09 04:17:03', '2014-05-09 04:17:03', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wayfinding_Cart.png" alt="Wayfinding_Cart" width="780" height="587" class="alignnone size-full wp-image-113" /></div>

<div class="post-description">
<h1>Grocery Store Wayfinding</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Grocery Store Wayfinding', '', 'inherit', 'open', 'open', '', '174-revision-v1', '', '', '2014-05-09 04:17:03', '2014-05-09 04:17:03', '', 174, 'http://localhost:8888/174-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (213, 1, '2014-05-09 04:17:18', '2014-05-09 04:17:18', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Wine_TerraNova.png" alt="Wine_TerraNova" width="1000" height="1191" class="alignnone size-full wp-image-112" /></div>

<div class="post-description">
<h1>Terra Nova Wine Bottle</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Terra Nova Wine Bottle', '', 'inherit', 'open', 'open', '', '172-revision-v1', '', '', '2014-05-09 04:17:18', '2014-05-09 04:17:18', '', 172, 'http://localhost:8888/172-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (214, 1, '2014-05-09 04:17:33', '2014-05-09 04:17:33', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Shirt_Millenium.png" alt="Shirt_Millenium" width="675" height="882" class="alignnone size-full wp-image-111" /></div>

<div class="post-description">
<h1>Millennium Shirt</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Millennium Shirt', '', 'inherit', 'open', 'open', '', '170-revision-v1', '', '', '2014-05-09 04:17:33', '2014-05-09 04:17:33', '', 170, 'http://localhost:8888/170-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (215, 1, '2014-05-09 04:17:56', '2014-05-09 04:17:56', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/Label_MeatPackaging.png" alt="Label_MeatPackaging" width="862" height="750" class="alignnone size-full wp-image-110" /></div>

<div class="post-description">
<h1>Meat Package Label</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator</p>
</div>', 'Meat Package Label', '', 'inherit', 'open', 'open', '', '168-revision-v1', '', '', '2014-05-09 04:17:56', '2014-05-09 04:17:56', '', 168, 'http://localhost:8888/168-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (216, 1, '2014-05-09 04:18:10', '2014-05-09 04:18:10', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/LilWayne_Poster.png" alt="LilWayne_Poster" width="1000" height="1187" class="alignnone size-full wp-image-108" /></div>

<div class="post-description">
<h1>Concert Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Concert Poster', '', 'inherit', 'open', 'open', '', '164-revision-v1', '', '', '2014-05-09 04:18:10', '2014-05-09 04:18:10', '', 164, 'http://localhost:8888/164-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (217, 1, '2014-05-09 04:18:24', '2014-05-09 04:18:24', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/HC_Flyer.png" alt="HC_Flyer" width="1000" height="597" class="alignnone size-full wp-image-107" /></div>

<div class="post-description">
<h1>HomeCure Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'HomeCure Advertisement', '', 'inherit', 'open', 'open', '', '162-revision-v1', '', '', '2014-05-09 04:18:24', '2014-05-09 04:18:24', '', 162, 'http://localhost:8888/162-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (218, 1, '2014-05-09 04:18:41', '2014-05-09 04:18:41', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Mag.png" alt="CS_Mag" width="1000" height="682" class="alignnone size-full wp-image-106" /></div>

<div class="post-description">
<h1>calsium Advertisement</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Advertisement', '', 'inherit', 'open', 'open', '', '160-revision-v1', '', '', '2014-05-09 04:18:41', '2014-05-09 04:18:41', '', 160, 'http://localhost:8888/160-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (219, 1, '2014-05-09 04:19:14', '2014-05-09 04:19:14', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/CS_Billboard.png" alt="CS_Billboard" width="1000" height="750" class="alignnone size-full wp-image-105" /></div>

<div class="post-description">
<h1>calsium Billboard</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign, Adobe Photoshop</p>
</div>', 'calsium Billboard', '', 'inherit', 'open', 'open', '', '158-revision-v1', '', '', '2014-05-09 04:19:14', '2014-05-09 04:19:14', '', 158, 'http://localhost:8888/158-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (220, 1, '2014-05-09 04:19:22', '2014-05-09 04:19:22', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/NG_Seminar.png" alt="NG_Seminar" width="1000" height="581" class="alignnone size-full wp-image-103" /></div>

<div class="post-description">
<h1>Next Generation Itinerary</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe InDesign</p>
</div>', 'Next Generation Itinerary ', '', 'inherit', 'open', 'open', '', '154-revision-v1', '', '', '2014-05-09 04:19:22', '2014-05-09 04:19:22', '', 154, 'http://localhost:8888/154-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (221, 1, '2014-05-09 04:19:43', '2014-05-09 04:19:43', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_NewsAds.png" alt="BC_NewsAds" width="580" height="486" class="alignnone size-full wp-image-102" /></div>

<div class="post-description">
<h1>Brookline College Advertisements</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign</p>
</div>', 'Brookline College Advertisements', '', 'inherit', 'open', 'open', '', '146-revision-v1', '', '', '2014-05-09 04:19:43', '2014-05-09 04:19:43', '', 146, 'http://localhost:8888/146-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (222, 1, '2014-05-09 04:19:54', '2014-05-09 04:19:54', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-revision-v1', '', '', '2014-05-09 04:19:54', '2014-05-09 04:19:54', '', 141, 'http://localhost:8888/141-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (223, 1, '2014-05-09 04:39:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-05-09 04:39:25', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=223', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (224, 1, '2014-05-09 04:39:34', '2014-05-09 04:39:34', '', 'Maintenance', '', 'inherit', 'open', 'open', '', 'maintenance', '', '', '2014-05-09 04:39:34', '2014-05-09 04:39:34', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Maintenance.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (225, 1, '2014-05-09 13:51:21', '2014-05-09 13:51:21', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira1.jpg" alt="BraylonKeira1" width="1000" height="662" class="alignnone size-full wp-image-227" /></div>

<div class="post-description">
<h1>Neworn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn', '', '', '2014-05-09 13:53:57', '2014-05-09 13:53:57', '', 0, 'http://localhost:8888/?p=225', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (226, 1, '2014-05-09 13:47:09', '2014-05-09 13:47:09', '', 'Arch', '', 'inherit', 'open', 'open', '', 'arch', '', '', '2014-05-09 13:47:09', '2014-05-09 13:47:09', '', 251, 'http://localhost:8888/wp-content/uploads/2014/05/Arch.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (227, 1, '2014-05-09 13:47:12', '2014-05-09 13:47:12', '', 'BraylonKeira1', '', 'inherit', 'open', 'open', '', 'braylonkeira1', '', '', '2014-05-09 13:47:12', '2014-05-09 13:47:12', '', 225, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (228, 1, '2014-05-09 13:48:22', '2014-05-09 13:48:22', '', 'Water', '', 'inherit', 'open', 'open', '', 'water', '', '', '2014-05-09 13:48:22', '2014-05-09 13:48:22', '', 253, 'http://localhost:8888/wp-content/uploads/2014/05/Water.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (229, 1, '2014-05-09 13:48:23', '2014-05-09 13:48:23', '', 'LightRail', '', 'inherit', 'open', 'open', '', 'lightrail', '', '', '2014-05-09 13:48:23', '2014-05-09 13:48:23', '', 257, 'http://localhost:8888/wp-content/uploads/2014/05/LightRail.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (230, 1, '2014-05-09 13:48:24', '2014-05-09 13:48:24', '', 'Cactus', '', 'inherit', 'open', 'open', '', 'cactus', '', '', '2014-05-09 13:48:24', '2014-05-09 13:48:24', '', 255, 'http://localhost:8888/wp-content/uploads/2014/05/Cactus.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (231, 1, '2014-05-09 13:48:28', '2014-05-09 13:48:28', '', 'BraylonKeira4', '', 'inherit', 'open', 'open', '', 'braylonkeira4', '', '', '2014-05-09 13:48:28', '2014-05-09 13:48:28', '', 249, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (232, 1, '2014-05-09 13:48:29', '2014-05-09 13:48:29', '', 'BraylonKeira3', '', 'inherit', 'open', 'open', '', 'braylonkeira3', '', '', '2014-05-09 13:48:29', '2014-05-09 13:48:29', '', 247, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (233, 1, '2014-05-09 13:48:31', '2014-05-09 13:48:31', '', 'BraylonKeira2', '', 'inherit', 'open', 'open', '', 'braylonkeira2', '', '', '2014-05-09 13:48:31', '2014-05-09 13:48:31', '', 243, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (234, 1, '2014-05-09 13:49:45', '2014-05-09 13:49:45', '', 'Water_TN', '', 'inherit', 'open', 'open', '', 'water_tn', '', '', '2014-05-09 13:49:45', '2014-05-09 13:49:45', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Water_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (235, 1, '2014-05-09 13:49:46', '2014-05-09 13:49:46', '', 'LightRail_TN', '', 'inherit', 'open', 'open', '', 'lightrail_tn', '', '', '2014-05-09 13:49:46', '2014-05-09 13:49:46', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/LightRail_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (236, 1, '2014-05-09 13:49:47', '2014-05-09 13:49:47', '', 'Cactus_TN', '', 'inherit', 'open', 'open', '', 'cactus_tn', '', '', '2014-05-09 13:49:47', '2014-05-09 13:49:47', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Cactus_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (237, 1, '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 'Arch_TN', '', 'inherit', 'open', 'open', '', 'arch_tn', '', '', '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/Arch_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (238, 1, '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 'BraylonKeira4_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira4_tn', '', '', '2014-05-09 13:49:48', '2014-05-09 13:49:48', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (239, 1, '2014-05-09 13:49:49', '2014-05-09 13:49:49', '', 'BraylonKeira3_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira3_tn', '', '', '2014-05-09 13:49:49', '2014-05-09 13:49:49', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (240, 1, '2014-05-09 13:49:50', '2014-05-09 13:49:50', '', 'BraylonKeira2_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira2_tn', '', '', '2014-05-09 13:49:50', '2014-05-09 13:49:50', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira2_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (241, 1, '2014-05-09 13:49:51', '2014-05-09 13:49:51', '', 'BraylonKeira1_TN', '', 'inherit', 'open', 'open', '', 'braylonkeira1_tn', '', '', '2014-05-09 13:49:51', '2014-05-09 13:49:51', '', 0, 'http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira1_TN.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (242, 1, '2014-05-09 13:51:21', '2014-05-09 13:51:21', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira1.jpg" alt="BraylonKeira1" width="1000" height="662" class="alignnone size-full wp-image-227" /></div>

<div class="post-description">
<h1>Neworn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '225-revision-v1', '', '', '2014-05-09 13:51:21', '2014-05-09 13:51:21', '', 225, 'http://localhost:8888/225-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (243, 1, '2014-05-09 13:53:16', '2014-05-09 13:53:16', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira2.jpg" alt="BraylonKeira2" width="1000" height="662" class="alignnone size-full wp-image-233" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn-2', '', '', '2014-05-09 13:53:31', '2014-05-09 13:53:31', '', 0, 'http://localhost:8888/?p=243', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (244, 1, '2014-05-09 13:53:16', '2014-05-09 13:53:16', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira2.jpg" alt="BraylonKeira2" width="1000" height="662" class="alignnone size-full wp-image-233" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '243-revision-v1', '', '', '2014-05-09 13:53:16', '2014-05-09 13:53:16', '', 243, 'http://localhost:8888/243-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (245, 1, '2014-05-09 13:53:31', '2014-05-09 13:53:31', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira2.jpg" alt="BraylonKeira2" width="1000" height="662" class="alignnone size-full wp-image-233" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '243-revision-v1', '', '', '2014-05-09 13:53:31', '2014-05-09 13:53:31', '', 243, 'http://localhost:8888/243-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (246, 1, '2014-05-09 13:53:57', '2014-05-09 13:53:57', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BraylonKeira1.jpg" alt="BraylonKeira1" width="1000" height="662" class="alignnone size-full wp-image-227" /></div>

<div class="post-description">
<h1>Neworn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '225-revision-v1', '', '', '2014-05-09 13:53:57', '2014-05-09 13:53:57', '', 225, 'http://localhost:8888/225-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (247, 1, '2014-05-09 13:54:46', '2014-05-09 13:54:46', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3.jpg" alt="BraylonKeira3" width="1000" height="1510" class="alignnone size-full wp-image-232" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn-3', '', '', '2014-05-09 13:54:46', '2014-05-09 13:54:46', '', 0, 'http://localhost:8888/?p=247', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (248, 1, '2014-05-09 13:54:46', '2014-05-09 13:54:46', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira3.jpg" alt="BraylonKeira3" width="1000" height="1510" class="alignnone size-full wp-image-232" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '247-revision-v1', '', '', '2014-05-09 13:54:46', '2014-05-09 13:54:46', '', 247, 'http://localhost:8888/247-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (249, 1, '2014-05-09 13:55:27', '2014-05-09 13:55:27', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4.jpg" alt="BraylonKeira4" width="1000" height="662" class="alignnone size-full wp-image-231" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'publish', 'open', 'open', '', 'newborn-4', '', '', '2014-05-09 14:01:13', '2014-05-09 14:01:13', '', 0, 'http://localhost:8888/?p=249', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (250, 1, '2014-05-09 13:55:27', '2014-05-09 13:55:27', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/BraylonKeira4.jpg" alt="BraylonKeira4" width="1000" height="662" class="alignnone size-full wp-image-231" /></div>

<div class="post-description">
<h1>Newborn</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Newborn', '', 'inherit', 'open', 'open', '', '249-revision-v1', '', '', '2014-05-09 13:55:27', '2014-05-09 13:55:27', '', 249, 'http://localhost:8888/249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (251, 1, '2014-05-09 13:56:31', '2014-05-09 13:56:31', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Arch.jpg" alt="Arch" width="1000" height="750" class="alignnone size-full wp-image-226" /></div>

<div class="post-description">
<h1>Night</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Night', '', 'publish', 'open', 'open', '', 'night', '', '', '2014-05-09 13:56:31', '2014-05-09 13:56:31', '', 0, 'http://localhost:8888/?p=251', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (252, 1, '2014-05-09 13:56:31', '2014-05-09 13:56:31', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Arch.jpg" alt="Arch" width="1000" height="750" class="alignnone size-full wp-image-226" /></div>

<div class="post-description">
<h1>Night</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Night', '', 'inherit', 'open', 'open', '', '251-revision-v1', '', '', '2014-05-09 13:56:31', '2014-05-09 13:56:31', '', 251, 'http://localhost:8888/251-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (253, 1, '2014-05-09 13:58:05', '2014-05-09 13:58:05', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Water.jpg" alt="Water" width="1000" height="750" class="alignnone size-full wp-image-228" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'publish', 'open', 'open', '', 'macro', '', '', '2014-05-09 13:58:05', '2014-05-09 13:58:05', '', 0, 'http://localhost:8888/?p=253', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (254, 1, '2014-05-09 13:58:05', '2014-05-09 13:58:05', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Water.jpg" alt="Water" width="1000" height="750" class="alignnone size-full wp-image-228" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'inherit', 'open', 'open', '', '253-revision-v1', '', '', '2014-05-09 13:58:05', '2014-05-09 13:58:05', '', 253, 'http://localhost:8888/253-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (255, 1, '2014-05-09 13:58:54', '2014-05-09 13:58:54', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Cactus.jpg" alt="Cactus" width="1000" height="1333" class="alignnone size-full wp-image-230" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'publish', 'open', 'open', '', 'macro-2', '', '', '2014-05-09 13:58:54', '2014-05-09 13:58:54', '', 0, 'http://localhost:8888/?p=255', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (256, 1, '2014-05-09 13:58:54', '2014-05-09 13:58:54', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/Cactus.jpg" alt="Cactus" width="1000" height="1333" class="alignnone size-full wp-image-230" /></div>

<div class="post-description">
<h1>Macro</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Macro', '', 'inherit', 'open', 'open', '', '255-revision-v1', '', '', '2014-05-09 13:58:54', '2014-05-09 13:58:54', '', 255, 'http://localhost:8888/255-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (257, 1, '2014-05-09 13:59:53', '2014-05-09 13:59:53', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/LightRail.jpg" alt="LightRail" width="1000" height="750" class="alignnone size-full wp-image-229" /></div>

<div class="post-description">
<h1>Motion Blur</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Motion Blur', '', 'publish', 'open', 'open', '', 'motion-blur', '', '', '2014-05-09 13:59:53', '2014-05-09 13:59:53', '', 0, 'http://localhost:8888/?p=257', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (258, 1, '2014-05-09 13:59:53', '2014-05-09 13:59:53', '<div class="fs-image"><img src="http://localhost:8888/wp-content/uploads/2014/05/LightRail.jpg" alt="LightRail" width="1000" height="750" class="alignnone size-full wp-image-229" /></div>

<div class="post-description">
<h1>Motion Blur</h1>
<hr class="content-title-rule">
<p></p>

<p class="post-programs">Equipment Used: </p>
</div>', 'Motion Blur', '', 'inherit', 'open', 'open', '', '257-revision-v1', '', '', '2014-05-09 13:59:53', '2014-05-09 13:59:53', '', 257, 'http://localhost:8888/257-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (259, 1, '2014-05-09 20:27:48', '2014-05-09 20:27:48', '', 'Downloads', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-05-09 20:27:48', '2014-05-09 20:27:48', '', 14, 'http://localhost:8888/14-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (260, 1, '2014-05-09 20:40:36', '2014-05-09 20:40:36', '<div class="fs-image"><img src="/wp-content/uploads/2014/05/BC_Poster.png" alt="BC_Poster" width="1000" height="1384" class="alignnone size-full wp-image-100" /></div>

<div class="post-description">
<h1>Brookline College Poster</h1>
<hr class="content-title-rule">
<p>This poster was designed while completing my internship at Brookline College. </p>

<p class="post-programs">Programs Used: Adobe Illustrator, Adobe InDesign, Adobe Photoshop</p>
</div>', 'Brookline College Poster', '', 'inherit', 'open', 'open', '', '141-autosave-v1', '', '', '2014-05-09 20:40:36', '2014-05-09 20:40:36', '', 141, 'http://localhost:8888/141-autosave-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (33 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (27, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (75, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (141, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (143, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (144, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (145, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (146, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (148, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (154, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (156, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (158, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (160, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (162, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (164, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (166, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (168, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (170, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (172, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (174, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (176, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (178, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (180, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (225, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (243, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (247, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (249, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (251, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (253, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (255, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (257, 8, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (8 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'portfolio_cats', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'portfolio_cats', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'portfolio_cats', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 3, 'category', '', 0, 14) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 4, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 5, 'category', '', 0, 8) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (5 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Main Navigation', 'main-navigation', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Graphic Design', 'graphic-design', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Web Design', 'web-design', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Photography', 'photography', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (22 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'lizponce') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '223') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, '_yoast_wpseo_profile_updated', '1398893840') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'libraryContent=browse&editor=html&urlbutton=none&imgsize=full&wpfb_adv_uploader=1') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1399647443') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:13:"add-portfolio";i:2;s:12:"add-post_tag";i:3;s:18:"add-portfolio_cats";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'closedpostboxes_toplevel_page_wpcf7', 'a:1:{i:0;s:7:"formdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'metaboxhidden_toplevel_page_wpcf7', 'a:0:{}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'lizponce', '$P$BAqASczPkmitex4zNwkcD6vD8WpFGj1', 'lizponce', 'liz@lizponce.com', '', '2014-04-27 04:13:11', '', 0, 'lizponce') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_cats`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpfb_cats`
#

DROP TABLE IF EXISTS `wp_wpfb_cats`;


#
# Table structure of table `wp_wpfb_cats`
#

CREATE TABLE `wp_wpfb_cats` (
  `cat_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL DEFAULT '',
  `cat_description` text,
  `cat_folder` varchar(300) NOT NULL DEFAULT '',
  `cat_path` varchar(2000) NOT NULL DEFAULT '',
  `cat_parent` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_num_files` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_num_files_total` int(8) unsigned NOT NULL DEFAULT '0',
  `cat_user_roles` text NOT NULL,
  `cat_owner` bigint(20) unsigned DEFAULT NULL,
  `cat_icon` varchar(255) DEFAULT NULL,
  `cat_exclude_browser` enum('0','1') NOT NULL DEFAULT '0',
  `cat_order` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  FULLTEXT KEY `USER_ROLES` (`cat_user_roles`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpfb_cats (1 records)
#
 
INSERT INTO `wp_wpfb_cats` VALUES (1, 'Keira\'s Newborn Pictures', '', 'keira\'s_newborn_pictures', 'keira\'s_newborn_pictures', 0, 1, 1, '', 1, '', '0', 0) ;
#
# End of data contents of table wp_wpfb_cats
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_cats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_files`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpfb_files`
#

DROP TABLE IF EXISTS `wp_wpfb_files`;


#
# Table structure of table `wp_wpfb_files`
#

CREATE TABLE `wp_wpfb_files` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(300) NOT NULL DEFAULT '',
  `file_path` varchar(2000) NOT NULL DEFAULT '',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_mtime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_hash` char(32) NOT NULL,
  `file_remote_uri` varchar(255) NOT NULL DEFAULT '',
  `file_thumbnail` varchar(255) DEFAULT NULL,
  `file_display_name` varchar(255) NOT NULL DEFAULT '',
  `file_description` text,
  `file_tags` varchar(255) NOT NULL DEFAULT '',
  `file_requirement` varchar(255) DEFAULT NULL,
  `file_version` varchar(64) DEFAULT NULL,
  `file_author` varchar(255) DEFAULT NULL,
  `file_language` varchar(255) DEFAULT NULL,
  `file_platform` varchar(255) DEFAULT NULL,
  `file_license` varchar(255) NOT NULL DEFAULT '',
  `file_user_roles` text NOT NULL,
  `file_offline` enum('0','1') NOT NULL DEFAULT '0',
  `file_direct_linking` enum('0','1','2') NOT NULL DEFAULT '0',
  `file_force_download` enum('0','1') NOT NULL DEFAULT '0',
  `file_category` int(8) unsigned NOT NULL DEFAULT '0',
  `file_category_name` varchar(127) NOT NULL DEFAULT '',
  `file_update_of` bigint(20) unsigned DEFAULT NULL,
  `file_post_id` bigint(20) unsigned DEFAULT NULL,
  `file_attach_order` int(8) NOT NULL DEFAULT '0',
  `file_wpattach_id` bigint(20) NOT NULL DEFAULT '0',
  `file_added_by` bigint(20) unsigned DEFAULT NULL,
  `file_hits` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_ratings` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_rating_sum` bigint(20) unsigned NOT NULL DEFAULT '0',
  `file_last_dl_ip` varchar(100) NOT NULL DEFAULT '',
  `file_last_dl_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `file_custom_cf1` text NOT NULL,
  `file_custom_cf2` text NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `DESCRIPTION` (`file_description`),
  FULLTEXT KEY `USER_ROLES` (`file_user_roles`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpfb_files (1 records)
#
 
INSERT INTO `wp_wpfb_files` VALUES (1, '1.jpg', 'keira\'s_newborn_pictures/1.jpg', 7266470, '2014-05-09 20:23:31', 1399667011, 'f4b4f3e6e07cd7c2a86f2032aa98be89', '', '1-120x113.jpg', 'Keira and Braylon', '', ',,', '', '', '', '', '', '', '', '0', '1', '0', 1, 'Keira\'s Newborn Pictures', 0, 0, 0, 0, 1, 0, 0, 0, '', '0000-00-00 00:00:00', '', '') ;
#
# End of data contents of table wp_wpfb_files
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Saturday 10. May 2014 01:59 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_afp_items`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_cats`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_files`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpfb_files_id3`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpfb_files_id3`
#

DROP TABLE IF EXISTS `wp_wpfb_files_id3`;


#
# Table structure of table `wp_wpfb_files_id3`
#

CREATE TABLE `wp_wpfb_files_id3` (
  `file_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `analyzetime` int(11) NOT NULL DEFAULT '0',
  `value` longtext NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `KEYWORDS` (`keywords`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpfb_files_id3 (1 records)
#
 
INSERT INTO `wp_wpfb_files_id3` VALUES (1, 1399667014, 'YTo3OntzOjk6ImF2ZGF0YWVuZCI7aTo3MjY2NDcwO3M6MTA6ImZpbGVmb3JtYXQiO3M6MzoianBnIjtzOjU6InZpZGVvIjthOjY6e3M6MTA6ImRhdGFmb3JtYXQiO3M6MzoianBnIjtzOjE1OiJiaXRzX3Blcl9zYW1wbGUiO2k6MjQ7czoxODoicGl4ZWxfYXNwZWN0X3JhdGlvIjtkOjE7czoxMjoicmVzb2x1dGlvbl94IjtpOjI2OTc7czoxMjoicmVzb2x1dGlvbl95IjtpOjI1NTE7czoxNzoiY29tcHJlc3Npb25fcmF0aW8iO2Q6MC4zNTIwNTUyNTAwMTAxNjIyNDYxNzcwMDM0NTMzNDAxNDg1NTMyNTIyMjAxNTM4MDg1OTM3NTt9czo5OiJtaW1lX3R5cGUiO3M6MTA6ImltYWdlL2pwZWciO3M6NDoiaXB0YyI7YToyOntzOjEyOiJJUFRDRW52ZWxvcGUiO2E6MTp7czoxNzoiQ29kZWRDaGFyYWN0ZXJTZXQiO2E6MDp7fX1zOjE1OiJJUFRDQXBwbGljYXRpb24iO2E6Mzp7czoyNDoiQXBwbGljYXRpb25SZWNvcmRWZXJzaW9uIjthOjA6e31zOjExOiJEYXRlQ3JlYXRlZCI7YToxOntpOjA7czo4OiIyMDE0MDMxNSI7fXM6MTE6IlRpbWVDcmVhdGVkIjthOjE6e2k6MDtzOjExOiIxNDA4MDgrMDAwMCI7fX19czozOiJqcGciO2E6MTp7czo0OiJleGlmIjthOjU6e3M6NDoiRklMRSI7YTo0OntzOjEyOiJGaWxlRGF0ZVRpbWUiO2k6MTM5OTY2NzAxMTtzOjg6IkZpbGVUeXBlIjtpOjI7czo4OiJNaW1lVHlwZSI7czoxMDoiaW1hZ2UvanBlZyI7czoxMzoiU2VjdGlvbnNGb3VuZCI7czozMDoiQU5ZX1RBRywgSUZEMCwgVEhVTUJOQUlMLCBFWElGIjt9czo4OiJDT01QVVRFRCI7YTo3OntzOjQ6Imh0bWwiO3M6MjY6IndpZHRoPSIyNjk3IiBoZWlnaHQ9IjI1NTEiIjtzOjY6IkhlaWdodCI7aToyNTUxO3M6NToiV2lkdGgiO2k6MjY5NztzOjE1OiJBcGVydHVyZUZOdW1iZXIiO3M6NToiZi81LjYiO3M6MTM6IkZvY3VzRGlzdGFuY2UiO3M6NToiMS4xMm0iO3M6MTg6IlRodW1ibmFpbC5GaWxlVHlwZSI7aToyO3M6MTg6IlRodW1ibmFpbC5NaW1lVHlwZSI7czoxMDoiaW1hZ2UvanBlZyI7fXM6NDoiSUZEMCI7YTo5OntzOjQ6Ik1ha2UiO3M6MTc6Ik5JS09OIENPUlBPUkFUSU9OIjtzOjU6Ik1vZGVsIjtzOjExOiJOSUtPTiBENTEwMCI7czoxMToiT3JpZW50YXRpb24iO2k6MTtzOjExOiJYUmVzb2x1dGlvbiI7aTozMDA7czoxMToiWVJlc29sdXRpb24iO2k6MzAwO3M6MTQ6IlJlc29sdXRpb25Vbml0IjtpOjI7czo4OiJTb2Z0d2FyZSI7czoyOToiQWRvYmUgUGhvdG9zaG9wIENTNSBNYWNpbnRvc2giO3M6ODoiRGF0ZVRpbWUiO3M6MTk6IjIwMTQ6MDM6MTYgMTY6MzQ6MTciO3M6MTY6IkV4aWZfSUZEX1BvaW50ZXIiO2k6MjIwO31zOjk6IlRIVU1CTkFJTCI7YTo2OntzOjExOiJDb21wcmVzc2lvbiI7aTo2O3M6MTE6IlhSZXNvbHV0aW9uIjtpOjcyO3M6MTE6IllSZXNvbHV0aW9uIjtpOjcyO3M6MTQ6IlJlc29sdXRpb25Vbml0IjtpOjI7czoyMToiSlBFR0ludGVyY2hhbmdlRm9ybWF0IjtpOjk5ODtzOjI3OiJKUEVHSW50ZXJjaGFuZ2VGb3JtYXRMZW5ndGgiO2k6MTEwMTM7fXM6NDoiRVhJRiI7YToyMzp7czoxMjoiRXhwb3N1cmVUaW1lIjtkOjAuMDMzMzMzMzMzMzMzMzMzMzMyODcwNzQwNDA2NDA2MTg0Nzc0ODIzNDg2ODA0OTYyMTU4MjAzMTI1O3M6NzoiRk51bWJlciI7ZDo1LjU5OTk5OTk5OTk5OTk5OTY0NDcyODYzMjExOTk0OTkwNzA2NDQzNzg2NjIxMDkzNzU7czoxNToiRXhwb3N1cmVQcm9ncmFtIjtpOjE7czoxNToiSVNPU3BlZWRSYXRpbmdzIjtpOjEwMDtzOjExOiJFeGlmVmVyc2lvbiI7aToyMjE7czoxNjoiRGF0ZVRpbWVPcmlnaW5hbCI7czoxOToiMjAxNDowMzoxNSAxNDowODowOCI7czoxNzoiRGF0ZVRpbWVEaWdpdGl6ZWQiO3M6MTk6IjIwMTQ6MDM6MTUgMTQ6MDg6MDgiO3M6MTc6IlNodXR0ZXJTcGVlZFZhbHVlIjtkOjQuOTA2ODkwOTk5OTk5OTk5ODkxNjU2NDQzNjUxMjk5OTIzNjU4MzcwOTcxNjc5Njg3NTtzOjEzOiJBcGVydHVyZVZhbHVlIjtkOjQuOTcwODU0MDAwMDAwMDAwMTA1Nzg1NjAyNDk5OTYzNzE1NjcyNDkyOTgwOTU3MDMxMjU7czoxNjoiTWF4QXBlcnR1cmVWYWx1ZSI7ZDozLjYwMDAwMDAwMDAwMDAwMDA4ODgxNzg0MTk3MDAxMjUyMzIzMzg5MDUzMzQ0NzI2NTYyNTtzOjE1OiJTdWJqZWN0RGlzdGFuY2UiO2Q6MS4xMjAwMDAwMDAwMDAwMDAxMDY1ODE0MTAzNjQwMTUwMjc4ODA2Njg2NDAxMzY3MTg3NTtzOjEyOiJNZXRlcmluZ01vZGUiO2k6NTtzOjExOiJGb2NhbExlbmd0aCI7aToxODtzOjEwOiJTdWJTZWNUaW1lIjtpOjIwO3M6MTg6IlN1YlNlY1RpbWVPcmlnaW5hbCI7aToyMDtzOjE5OiJTdWJTZWNUaW1lRGlnaXRpemVkIjtpOjIwO3M6MTA6IkNvbG9yU3BhY2UiO2k6NjU1MzU7czoxNDoiRXhpZkltYWdlV2lkdGgiO2k6MjY5NztzOjE1OiJFeGlmSW1hZ2VMZW5ndGgiO2k6MjU1MTtzOjEzOiJTZW5zaW5nTWV0aG9kIjtpOjI7czoxMjoiRXhwb3N1cmVNb2RlIjtpOjE7czoxNjoiRGlnaXRhbFpvb21SYXRpbyI7aToxO3M6MjE6IkZvY2FsTGVuZ3RoSW4zNW1tRmlsbSI7aToyNzt9fX1zOjM6InhtcCI7YTo4OntzOjM6InJkZiI7YTowOnt9czo1OiJ4bWxucyI7YTo4OntzOjM6InhtcCI7czoyODoiaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI7czozOiJhdXgiO3M6MzM6Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvYXV4LyI7czo5OiJwaG90b3Nob3AiO3M6MzQ6Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iO3M6NToieG1wTU0iO3M6MzE6Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iO3M6NToic3RFdnQiO3M6NDg6Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyI7czo1OiJzdFJlZiI7czo0NjoiaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyI7czoyOiJkYyI7czozMjoiaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iO3M6MzoiY3JzIjtzOjQ0OiJodHRwOi8vbnMuYWRvYmUuY29tL2NhbWVyYS1yYXctc2V0dGluZ3MvMS4wLyI7fXM6MzoieG1wIjthOjQ6e3M6MTE6IkNyZWF0b3JUb29sIjtzOjI5OiJBZG9iZSBQaG90b3Nob3AgQ1M1IE1hY2ludG9zaCI7czoxMDoiTW9kaWZ5RGF0ZSI7czoyNToiMjAxNC0wMy0xNlQxNjozNDoxNy0wNzowMCI7czoxMDoiQ3JlYXRlRGF0ZSI7czoyMjoiMjAxNC0wMy0xNVQxNDowODowOC4yMCI7czoxMjoiTWV0YWRhdGFEYXRlIjtzOjI1OiIyMDE0LTAzLTE2VDE2OjM0OjE3LTA3OjAwIjt9czozOiJhdXgiO2E6Njp7czoxMjoiU2VyaWFsTnVtYmVyIjtpOjM2MjgxMTg7czo4OiJMZW5zSW5mbyI7czoyNToiMTgwLzEwIDU1MC8xMCAzNS8xMCA1Ni8xMCI7czo0OiJMZW5zIjtzOjIyOiIxOC4wLTU1LjAgbW0gZi8zLjUtNS42IjtzOjY6IkxlbnNJRCI7aToxNTQ7czoxMToiSW1hZ2VOdW1iZXIiO2k6MzQxNjtzOjI0OiJBcHByb3hpbWF0ZUZvY3VzRGlzdGFuY2UiO2Q6MS4xMjAwMDAwMDAwMDAwMDAxMDY1ODE0MTAzNjQwMTUwMjc4ODA2Njg2NDAxMzY3MTg3NTt9czo5OiJwaG90b3Nob3AiO2E6Mzp7czoxMToiRGF0ZUNyZWF0ZWQiO3M6MjM6IjIwMTQtMDMtMTVUMTQ6MDg6MDguMDAyIjtzOjk6IkNvbG9yTW9kZSI7aTo0O3M6MTA6IklDQ1Byb2ZpbGUiO3M6MjU6IlUuUy4gV2ViIENvYXRlZCAoU1dPUCkgdjIiO31zOjU6InhtcE1NIjthOjU6e3M6MTA6IkRvY3VtZW50SUQiO3M6NDA6InhtcC5kaWQ6MDE1QzA1MkYwQjIwNjgxMTgyMkFEREY5M0E0NkU5QUMiO3M6MTg6Ik9yaWdpbmFsRG9jdW1lbnRJRCI7czozMjoiQUMwMDE5QTg4MERFNDA4RUFGQjdGREQzMkM1M0Y0Q0QiO3M6MTA6Ikluc3RhbmNlSUQiO3M6NDA6InhtcC5paWQ6RkM3RjExNzQwNzIwNjgxMThDMTQ5NzQ3ODVEOUQ3QkYiO3M6NzoiSGlzdG9yeSI7YTowOnt9czoxMToiRGVyaXZlZEZyb20iO2E6Mzp7czoxNjoic3RSZWY6aW5zdGFuY2VJRCI7czo0MDoieG1wLmlpZDpGQjdGMTE3NDA3MjA2ODExOEMxNDk3NDc4NUQ5RDdCRiI7czoxNjoic3RSZWY6ZG9jdW1lbnRJRCI7czo0MDoieG1wLmRpZDowMTVDMDUyRjBCMjA2ODExODIyQURERjkzQTQ2RTlBQyI7czoyNDoic3RSZWY6b3JpZ2luYWxEb2N1bWVudElEIjtzOjMyOiJBQzAwMTlBODgwREU0MDhFQUZCN0ZERDMyQzUzRjRDRCI7fX1zOjI6ImRjIjthOjE6e3M6NjoiZm9ybWF0IjtzOjEwOiJpbWFnZS9qcGVnIjt9czozOiJjcnMiO2E6Mzc6e3M6MTE6IlJhd0ZpbGVOYW1lIjtzOjEyOiJEU0NfMDAwMi5ORUYiO3M6NzoiVmVyc2lvbiI7ZDo2LjcwMDAwMDAwMDAwMDAwMDE3NzYzNTY4Mzk0MDAyNTA0NjQ2Nzc4MTA2Njg5NDUzMTI1O3M6MTQ6IlByb2Nlc3NWZXJzaW9uIjtkOjUuNzAwMDAwMDAwMDAwMDAwMTc3NjM1NjgzOTQwMDI1MDQ2NDY3NzgxMDY2ODk0NTMxMjU7czoxMjoiV2hpdGVCYWxhbmNlIjtzOjc6IkFzIFNob3QiO3M6MTE6IlRlbXBlcmF0dXJlIjtpOjU0NTA7czo0OiJUaW50IjtzOjI6Ii0zIjtzOjg6IkV4cG9zdXJlIjtzOjU6IisxLjM1IjtzOjc6IlNoYWRvd3MiO2k6NTtzOjEwOiJCcmlnaHRuZXNzIjtzOjM6Iis0MCI7czo4OiJDb250cmFzdCI7czozOiIrMzIiO3M6OToiU2hhcnBuZXNzIjtpOjI1O3M6MTk6IkNvbG9yTm9pc2VSZWR1Y3Rpb24iO2k6MjU7czo3OiJDbGFyaXR5IjtzOjI6Iis1IjtzOjIxOiJQYXJhbWV0cmljU2hhZG93U3BsaXQiO2k6MjU7czoyMjoiUGFyYW1ldHJpY01pZHRvbmVTcGxpdCI7aTo1MDtzOjI0OiJQYXJhbWV0cmljSGlnaGxpZ2h0U3BsaXQiO2k6NzU7czoxMzoiU2hhcnBlblJhZGl1cyI7czo0OiIrMS4wIjtzOjEzOiJTaGFycGVuRGV0YWlsIjtpOjI1O3M6MjU6IkNvbG9yTm9pc2VSZWR1Y3Rpb25EZXRhaWwiO2k6NTA7czoxNjoiUGVyc3BlY3RpdmVTY2FsZSI7aToxMDA7czoxODoiQ29udmVydFRvR3JheXNjYWxlIjtzOjU6IkZhbHNlIjtzOjEzOiJUb25lQ3VydmVOYW1lIjtzOjE1OiJNZWRpdW0gQ29udHJhc3QiO3M6MTc6IlRvbmVDdXJ2ZU5hbWUyMDEyIjtzOjY6IkxpbmVhciI7czoxMzoiQ2FtZXJhUHJvZmlsZSI7czoxNDoiQWRvYmUgU3RhbmRhcmQiO3M6MTk6IkNhbWVyYVByb2ZpbGVEaWdlc3QiO3M6MzI6IjJGRUEzRUE5MkQ1REZFNzdGQkI3N0NDQUQ4NEM0NzY5IjtzOjE2OiJMZW5zUHJvZmlsZVNldHVwIjtzOjEyOiJMZW5zRGVmYXVsdHMiO3M6MTE6Ikhhc1NldHRpbmdzIjtzOjQ6IlRydWUiO3M6NzoiSGFzQ3JvcCI7czo1OiJGYWxzZSI7czoxNDoiQWxyZWFkeUFwcGxpZWQiO3M6NDoiVHJ1ZSI7czo5OiJUb25lQ3VydmUiO2E6Njp7aTowO3M6NDoiMCwgMCI7aToxO3M6NjoiMzIsIDIyIjtpOjI7czo2OiI2NCwgNTYiO2k6MztzOjg6IjEyOCwgMTI4IjtpOjQ7czo4OiIxOTIsIDE5NiI7aTo1O3M6ODoiMjU1LCAyNTUiO31zOjEyOiJUb25lQ3VydmVSZWQiO2E6Mjp7aTowO3M6NDoiMCwgMCI7aToxO3M6ODoiMjU1LCAyNTUiO31zOjE0OiJUb25lQ3VydmVHcmVlbiI7YToyOntpOjA7czo0OiIwLCAwIjtpOjE7czo4OiIyNTUsIDI1NSI7fXM6MTM6IlRvbmVDdXJ2ZUJsdWUiO2E6Mjp7aTowO3M6NDoiMCwgMCI7aToxO3M6ODoiMjU1LCAyNTUiO31zOjE1OiJUb25lQ3VydmVQVjIwMTIiO2E6Mjp7aTowO3M6NDoiMCwgMCI7aToxO3M6ODoiMjU1LCAyNTUiO31zOjE4OiJUb25lQ3VydmVQVjIwMTJSZWQiO2E6Mjp7aTowO3M6NDoiMCwgMCI7aToxO3M6ODoiMjU1LCAyNTUiO31zOjIwOiJUb25lQ3VydmVQVjIwMTJHcmVlbiI7YToyOntpOjA7czo0OiIwLCAwIjtpOjE7czo4OiIyNTUsIDI1NSI7fXM6MTk6IlRvbmVDdXJ2ZVBWMjAxMkJsdWUiO2E6Mjp7aTowO3M6NDoiMCwgMCI7aToxO3M6ODoiMjU1LCAyNTUiO319fX0=', 'jpg dataformat bits_per_sample pixel_aspect_ratio resolution_x resolution_y compression_ratio image jpeg codedcharacterset 20140315 140808 0000 applicationrecordversion datecreated timecreated iptcenvelope iptcapplication any_tag ifd0 thumbnail exif filedatetime filetype mimetype sectionsfound width 2697 height 2551 f 5 6 1 12m html aperturefnumber focusdistance nikon corporation d5100 adobe photoshop cs5 macintosh 2014 03 16 34 17 make model orientation xresolution yresolution resolutionunit software datetime exif_ifd_pointer compression jpeginterchangeformat jpeginterchangeformatlength 15 14 08 exposuretime fnumber exposureprogram isospeedratings exifversion datetimeoriginal datetimedigitized shutterspeedvalue aperturevalue maxaperturevalue subjectdistance meteringmode focallength subsectime subsectimeoriginal subsectimedigitized colorspace exifimagewidth exifimagelength sensingmethod exposuremode digitalzoomratio focallengthin35mmfilm file computed http ns com xap aux mm stype resourceevent resourceref purl org dc elements camera raw settings xmp xmpmm stevt stref crs 16t16 07 15t14 20 creatortool modifydate createdate metadatadate 180 10 550 35 56 18 55 serialnumber lensinfo lens lensid imagenumber approximatefocusdistance 002 u s web coated swop v2 colormode iccprofile did 015c052f0b206811822addf93a46e9ac ac0019a880de408eafb7fdd32c53f4cd iid fc7f1174072068118c14974785d9d7bf fb7f1174072068118c14974785d9d7bf instanceid documentid originaldocumentid history derivedfrom format dsc_0002 nef as shot 40 32 false medium contrast linear standard 2fea3ea92d5dfe77fbb77ccad84c4769 lensdefaults true 22 64 128 192 196 255 rawfilename version processversion whitebalance temperature tint exposure shadows brightness sharpness colornoisereduction clarity parametricshadowsplit parametricmidtonesplit parametrichighlightsplit sharpenradius sharpendetail colornoisereductiondetail perspectivescale converttograyscale tonecurvename tonecurvename2012 cameraprofile cameraprofiledigest lensprofilesetup hassettings hascrop alreadyapplied tonecurve tonecurvered tonecurvegreen tonecurveblue tonecurvepv2012 tonecurvepv2012red tonecurvepv2012green tonecurvepv2012blue rdf xmlns') ;
#
# End of data contents of table wp_wpfb_files_id3
# --------------------------------------------------------

