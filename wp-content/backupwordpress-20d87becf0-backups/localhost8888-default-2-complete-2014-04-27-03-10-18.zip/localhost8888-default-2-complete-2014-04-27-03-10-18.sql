# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-04-26 02:43:37', '2014-04-26 02:43:37', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (142 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'www.lizponce.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'liz@lizponce.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'permalink_structure', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (32, 'active_plugins', 'a:2:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:24:"wordpress-seo/wp-seo.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'home', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', 'a:2:{i:0;s:96:"/Users/LizPonce/Websites/www.lizponce.com/wp-content/plugins/backupwordpress/backupwordpress.php";i:1;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'lp-bootstrap', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'lp-bootstrap', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:38:"simple-backup/simple-backup-loader.php";s:23:"simple_backup_uninstall";}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'cron', 'a:7:{i:1398582720;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1398609820;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1398639600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1398653044;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1398653968;a:1:{s:14:"yoast_tracking";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1399172400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-3.9.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-3.9.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.9";s:7:"version";s:3:"3.9";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1398568214;s:15:"version_checked";s:3:"3.9";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1398568218;s:7:"checked";a:4:{s:12:"lp-bootstrap";s:9:"1.0-wpcom";s:14:"twentyfourteen";s:3:"1.0";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, '_site_transient_timeout_browser_a64afbf86ac7a1ef023e4b1e1f62f178', '1399085028', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, '_site_transient_browser_a64afbf86ac7a1ef023e4b1e1f62f178', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.131";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1398523430', 'no') ; 
INSERT INTO `wp_options` VALUES (108, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 01:07:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=4.0-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23279:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2328:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="http://make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="http://make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="http://make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="http://make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="http://make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="http://make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3022:"<p><a href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="http://make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="http://make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="http://make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 3.8 “Parker”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://wordpress.org/news/2013/12/parker/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/parker/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Dec 2013 17:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2765";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:19098:"<p>Version 3.8 of WordPress, named “Parker” in honor of <a href="http://en.wikipedia.org/wiki/Charlie_Parker">Charlie Parker</a>, bebop innovator, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet.</p>
<div id="v-6wORgoGb-1" class="video-player"><embed id="v-6wORgoGb-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=6wORgoGb&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h2 class="aligncenter">Introducing a modern new design</h2>
<p><img class="wp-image-2951 aligncenter" alt="overview" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193" data-recalc-dims="1" /></p>
<p>WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. Gone are overbearing gradients and dozens of shades of grey — bring on a bigger, bolder, more colorful design!</p>
<p><img class="aligncenter  wp-image-2856" style="margin-left: 0;margin-right: 0" alt="about-modern-wordpress" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/design.png?resize=623%2C151" data-recalc-dims="1" /></p>
<h3>Modern aesthetic</h3>
<p>The new WordPress dashboard has a fresh, uncluttered design that embraces clarity and simplicity.</p>
<h3>Clean typography</h3>
<p>The Open Sans typeface provides simple, friendly text that is optimized for both desktop and mobile viewing. It’s even open source, just like WordPress.</p>
<h3>Refined contrast</h3>
<p>We think beautiful design should never sacrifice legibility. With superior contrast and large, comfortable type, the new design is easy to read and a pleasure to navigate.</p>
<hr />
<h2 class="aligncenter">WordPress on every device</h2>
<p><img class="alignright  wp-image-2984" alt="responsive" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/responsive.jpg?resize=255%2C255" data-recalc-dims="1" />We all access the internet in different ways. Smartphone, tablet, notebook, desktop — no matter what you use, WordPress will adapt and you’ll feel right at home.</p>
<h3>High definition at high speed</h3>
<p>WordPress is sharper than ever with new vector-based icons that scale to your screen. By ditching pixels, pages load significantly faster, too.</p>
<hr />
<h2 class="aligncenter">Admin color schemes to match your personality</h2>
<p><img class="aligncenter  wp-image-2954" alt="colors" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?resize=623%2C339" data-recalc-dims="1" /></p>
<p>WordPress just got a colorful new update. We’ve included eight new admin color schemes so you can pick the one that suits you best.</p>
<p>Color schemes can be previewed and changed from your Profile page.</p>
<hr />
<h2 class="aligncenter">Refined theme management</h2>
<p><img class="alignright  wp-image-2967" alt="themes" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344" data-recalc-dims="1" />The new themes screen lets you survey your themes at a glance. Or want more information? Click to discover more. Then sit back and use your keyboard’s navigation arrows to flip through every theme you’ve got.</p>
<h3>Smoother widget experience</h3>
<p>Drag-drag-drag. Scroll-scroll-scroll. Widget management can be complicated. With the new design, we’ve worked to streamline the widgets screen.</p>
<p>Have a large monitor? Multiple widget areas stack side-by-side to use the available space. Using a tablet? Just tap a widget to add it.</p>
<hr />
<h2 class="aligncenter">Twenty Fourteen, a sleek new magazine theme</h2>
<p><img class="aligncenter size-large wp-image-2789" alt="The new Twenty Fourteen theme displayed on a laptop. tablet and phone" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275" data-recalc-dims="1" /></p>
<h3>Turn your blog into a magazine</h3>
<p>Create a beautiful magazine-style site with WordPress and Twenty Fourteen. Choose a grid or a slider to display featured content on your homepage. Customize your site with three widget areas or change your layout with two page templates.</p>
<p>With a striking design that does not compromise our trademark simplicity, Twenty Fourteen is our most intrepid default theme yet.</p>
<hr />
<h2>Beginning of a new era</h2>
<p>This release was led by Matt Mullenweg. This is our second release using the new plugin-first development process, with a much shorter timeframe than in the past. We think it’s been going great. You can check out the features currently in production on the <a title="Make WordPress Core" href="http://make.wordpress.org/core/" target="_blank">make/core blog</a>.</p>
<p>There are 188 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/admiralthrawn">admiralthrawn</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aralbald">Andrey Kabakchiev</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/apeatling">Andy Peatling</a>, <a href="http://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/fliespl">Arkadiusz Rzadkowolski</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy Schneider</a>, <a href="http://profiles.wordpress.org/binarymoon">binarymoon</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/calin">Calin Don</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/chrisbliss18">Chris Jean</a>, <a href="http://profiles.wordpress.org/iblamefish">Clinton Montague</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/dbernar1">Dan Bernardic</a>, <a href="http://profiles.wordpress.org/danieldudzic">Daniel Dudzic</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/datafeedrcom">datafeedr</a>, <a href="http://profiles.wordpress.org/lessbloat">Dave Martin</a>, <a href="http://profiles.wordpress.org/drw158">Dave Whitley</a>, <a href="http://profiles.wordpress.org/designsimply">designsimply</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/dziudek">dziudek</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gnarf37">gnarf37</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/isaackeyet">Isaac Keyet</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="http://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jblz">Jeff Bowen</a>, <a href="http://profiles.wordpress.org/jeffr0">Jeff Chandler</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jeherve">Jeremy Herve</a>, <a href="http://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jhned">jhned</a>, <a href="http://profiles.wordpress.org/jim912">jim912</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/nukaga">Junko Nukaga</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K. Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/codebykat">Kat Hagan</a>, <a href="http://profiles.wordpress.org/littlethingsstudio">Kate Whitley</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/koki4a">Konstantin Dankov</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lite3">lite3</a>, <a href="http://profiles.wordpress.org/lucp">Luc Princen</a>, <a href="http://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="http://profiles.wordpress.org/mako09">Mako</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/megane9988">megane9988</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/micahwave">micahwave</a>, <a href="http://profiles.wordpress.org/cainm">Michael Cain</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">Michael Erlewine</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/chellycat">Michelle Langston</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mt8biz">moto hachi</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/ninio">ninio</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="http://profiles.wordpress.org/odysseygate">odyssey</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/senlin">Piet</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/bamadesigner">Rachel Carden</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/radices">Radices</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/defries">Remkus de Vries</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/wet">Robert Wetzlmayr, PHP-Programmierer</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="http://profiles.wordpress.org/sanchothefat">sanchothefat</a>, <a href="http://profiles.wordpress.org/sboisvert">sboisvert</a>, <a href="http://profiles.wordpress.org/scottbasgaard">Scott Basgaard</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirbrillig">sirbrillig</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/thomasguillot">Thomas Guillot</a>, <a href="http://profiles.wordpress.org/tierra">tierra</a>, <a href="http://profiles.wordpress.org/tillkruess">Till Krüss</a>, <a href="http://profiles.wordpress.org/tlamedia">TLA Media</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomdxw">tomdxw</a>, <a href="http://profiles.wordpress.org/tommcfarlin">tommcfarlin</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/trishasalas">trishasalas</a>, <a href="http://profiles.wordpress.org/mbmufffin">Tyler Smith</a>, <a href="http://profiles.wordpress.org/grapplerulrich">Ulrich</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/l10n">Vladimir</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yonasy">yonasy</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, and <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>. Also thanks to <a href="http://benmorrison.org/">Ben Morrison</a> and <a href="http://christineswebb.com/">Christine Webb</a> for help with the video.</p>
<p>Thanks for choosing WordPress. See you soon for version 3.9!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/news/2013/12/parker/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 26 Apr 2014 02:43:50 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 17 Apr 2014 01:07:32 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (109, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1398523430', 'no') ; 
INSERT INTO `wp_options` VALUES (110, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1398480230', 'no') ; 
INSERT INTO `wp_options` VALUES (111, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1398523432', 'no') ; 
INSERT INTO `wp_options` VALUES (112, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: How to Repair a Crashed WordPress Posts Table";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21797";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/how-to-repair-a-crashed-wordpress-posts-table?utm_source=rss&utm_medium=rss&utm_campaign=how-to-repair-a-crashed-wordpress-posts-table";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4659:"<div id="attachment_21873" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg" rel="prettyphoto[21797]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg?resize=1024%2C482" alt="photo credit: Code & Martini by Ivana Vasilj - cc license" class="size-full wp-image-21873" /></a><p class="wp-caption-text">photo credit: <a href="https://flic.kr/p/dLUWMb">Code &#038; Martini</a> by <a href="https://www.flickr.com/photos/ivanavasilj/">Ivana Vasilj</a> &#8211; cc license</p></div>
<p>Every now and then the WordPress posts table will crash and screw up your website. Why does this happen? It&#8217;s not always clear how tables get corrupted, although it can usually be attributed to an <a href="https://dev.mysql.com/doc/refman/5.1/en/crashing.html" target="_blank">unexpected event</a>, such as the MySQL server or the server host getting killed in the middle of an update, causing interrupted writes to the database.</p>
<h3>Symptoms of a Crashed Posts Table</h3>
<p>If you navigate to the &#8220;All Posts&#8221; or &#8220;All Pages&#8221; screen in the WordPress admin and find nothing there, your first instinct is probably to freak out. <strong><em>What happened to all of my content?!</em></strong> Don&#8217;t worry; it&#8217;s still there. This is often a symptom of a crashed posts table in the database. It&#8217;s the MySQL equivalent to a throwing a tantrum, but it&#8217;s easily fixed, so you should stay calm.</p>
<p>You may also see blank pages or get 404s on existing pages where there should be content. Those who have BuddyPress active may also see a message like this:</p>
<p><strong>&#8220;The following active BuddyPress Components do not have associated WordPress Pages: User Groups, Members, Activate, Register. Repair&#8221;</strong></p>
<p>When the posts table is crashed, BuddyPress can&#8217;t find those pages, so it gives you that warning, even though you set the pages before.</p>
<h3>How to Fix a Crashed Table</h3>
<p>Sometimes WordPress can repair this problem automatically, but other times you&#8217;ll just have to do it manually via phpMyAdmin. Before touching anything, make sure that you have a backup of your database.</p>
<p>If you&#8217;re not comfortable with phpmyadmin, you should first try to use <a href="http://codex.wordpress.org/Editing_wp-config.php#Automatic_Database_Optimizing" target="_blank">WordPress&#8217; recommended method of database repair</a>, available since 2.9. Add the following to your <em>wp-config.php</em> file:</p>
<pre class="brush: php; light: true; title: ; notranslate">define( \'WP_ALLOW_REPAIR\', true );</pre>
<p>That should take effect and automatically repair your crashed table after you visit the script at: <strong>{$your_site}/wp-admin/maint/repair.php</strong></p>
<p>If you&#8217;re comfortable with using phpmyadmin, you may opt for an alternative method of repair, which really does the same thing as the previous method:</p>
<p>Log into your host&#8217;s control panel and launch phpMyAdmin. Select your database and then look for the <strong>wp_posts</strong> table. Chances are that it&#8217;s not going to look like the other tables and will probably say &#8220;In Use&#8221;:</p>
<div id="attachment_21856" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/crashed-posts-table.jpg" rel="prettyphoto[21797]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/crashed-posts-table.jpg?resize=974%2C179" alt="Scary, right?!" class="size-full wp-image-21856" /></a><p class="wp-caption-text">Scary, right?!</p></div>
<p>This is the table that is bedeviling you and you&#8217;ll want to select it and then click on &#8220;<a href="https://dev.mysql.com/doc/refman/5.1/en/repair-table.html" target="_blank">Repair Table</a>&#8221; in the dropdown:</p>
<div id="attachment_21861" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/repair-table.jpg" rel="prettyphoto[21797]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/repair-table.jpg?resize=815%2C234" alt="Repair Table" class="size-full wp-image-21861" /></a><p class="wp-caption-text">Repair Table</p></div>
<p>This should have you all fixed up. Visit your site to verify that your posts and pages are back to normal. <em>Note:</em> This also works for other corrupted tables, i.e. wp_options, etc. It&#8217;s a fairly easy solution to a problem that presents itself as a dire emergency on the frontend of your WordPress site. File this one away for the next time you suspect a corrupted table.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 22:42:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WPTavern: WordPress Code Reference is Now Live";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21839";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:136:"http://wptavern.com/wordpress-code-reference-is-now-live?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-code-reference-is-now-live";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3186:"<p>Siobhan McKeown <a href="http://make.wordpress.org/docs/2014/04/25/good-news-everyone-version-1-of-the-code/" target="_blank">announced</a> that the first version of the WordPress Code Reference is now live. It&#8217;s still in the very early stages of development but is now out in the wild so that people can help contribute. <a href="http://developer.wordpress.org/reference" target="_blank">Go try it out</a> to see how easy it is to search the WordPress code base.</p>
<p>The reference was created as part of the <a href="http://make.wordpress.org/docs/tag/devhub/" target="_blank">devhub project</a> to make it easy for developers to find more information about WordPress&#8217; functions, classes, methods, hooks, and filters. After a few quick searches, I found that the search function is actually quite forgiving and will return results that are similar to what you were looking for, even if you spell it wrong.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-code-reference.jpg" rel="prettyphoto[21839]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-code-reference.jpg?resize=794%2C595" alt="wordpress-code-reference" class="aligncenter size-full wp-image-21841" /></a></p>
<h3>How can you help improve the reference?</h3>
<p>McKeown said that current development for the parser will continue on Github and you can <a href="https://github.com/rmccue/WP-Parser/issues?labels=enhancement&state=open" target="_blank">open a ticket</a> there to offer feedback on issues and enhancements. Tickets for the code reference theme can be found on <a href="https://meta.trac.wordpress.org/query?status=!closed&component=developer.wordpress.org" target="_blank">meta trac</a>. Very soon you&#8217;ll be able to submit code examples to the reference, McKeown said:</p>
<blockquote><p>Please feel free to add tickets to meta trac if there are any issues you encounter, and if there’s a feature or enhancement you’d like we can discuss that too. We do have the functionality ready for submitting examples, we just need a few parser things fixed before we can deploy it.</p></blockquote>
<p>The documentation team has been working at a feverish pace to completely overhaul WordPress docs to make them more useful to the community. The contributor handbooks have a <a href="https://make.wordpress.org/docs/2014/04/24/redesigned-contributor-handbooks/" target="_blank">new design</a> that is now live on the <a href="http://make.wordpress.org/core/handbook/" target="_blank">core</a>, <a href="http://make.wordpress.org/mobile/handbook/" target="_blank">mobile</a>, <a href="http://make.wordpress.org/docs/handbook/" target="_blank">docs</a>, and <a href="http://make.wordpress.org/polyglots/handbook/" target="_blank">polyglot</a> handbooks. If you want to get in on the fun and help to make WordPress docs more awesome, join the <a href="https://make.wordpress.org/docs/" target="_blank">Docs team</a> at their weekly meeting <a href="http://www.timeanddate.com/worldclock/fixedtime.html?hour=23&min=00&sec=0&p1=0&msg=Docs+Team+Chat" target="_blank">Thursdays at 23:00 UTC</a> in IRC on the #wordpress-sfd channel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 20:50:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Interface: A Free Responsive Business Theme for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21697";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/interface-a-free-responsive-business-theme-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=interface-a-free-responsive-business-theme-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2890:"<p><a href="http://wordpress.org/themes/interface" target="_blank">Interface</a> is a new business theme in the WordPress Themes Directory, created by <a href="http://themehorse.com/" target="_blank">Theme Horse</a>, the same folks behind the popular <a href="http://wordpress.org/themes/clean-retina" target="_blank">Clean Retina</a> and <a href="http://wordpress.org/themes/attitude" target="_blank">Attitude</a> themes that have more than 80,000 downloads combined. If you need to set up a simple business site and you&#8217;re into the flat-style <a href="http://wptavern.com/exploring-wordpress-theme-designers-love-affair-with-mint-green" target="_blank">mint green design trend</a>, then the new Interface theme might be just the ticket.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/interface.jpg" rel="prettyphoto[21697]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/interface.jpg?resize=880%2C660" alt="interface" class="aligncenter size-full wp-image-21789" /></a></p>
<p>The theme is responsive, retina ready, and compatible with both BuddyPress and bbPress. The social features drop nicely into the theme without any conflicts.</p>
<p>Interface includes several options in the customizer for setting the header image, navigation, background, etc. It also includes a host of theme-specific widgets that you can edit live to create promotional boxes, feature recent work, display services, and add items typically related to business needs.</p>
<p>In addition to the customizer options, Interface includes its own options panel for further customization of the homepage slider, layouts, social links, blog category, optional search form in the header, favicon and more advanced settings.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/interface-options.jpg" rel="prettyphoto[21697]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/interface-options.jpg?resize=875%2C183" alt="interface-options" class="aligncenter size-full wp-image-21804" /></a></p>
<p>Inside this theme you&#8217;ll find many different building blocks for customizing your business site, including:</p>
<ul>
<li>4 layouts for posts/pages</li>
<li>5 unique page templates</li>
<li>8 widget areas</li>
<li>6 custom widgets</li>
<li>Separate top and bottom info bar to highlight contact/email/location</li>
</ul>
<p>Check out the <a href="http://themehorse.com/preview/interface/" target="_blank">live demo</a> on the Theme Horse site where you can view all the different page and blog templates available for both business and more blogger-oriented sites. With all the customization options, <a href="http://wordpress.org/themes/interface" target="_blank">Interface</a> is bound to be another favorite from the folks at Theme Horse. Add it to your site from WordPress.org via the theme browser in your admin panel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 18:09:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Matt: Scrollkit and Longreads at Automattic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43748";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://ma.tt/2014/04/scrollkit-and-longreads-at-automattic/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:680:"<p>You might have seen the news last week that <a href="http://www.businessweek.com/articles/2014-04-09/automattic-steward-of-wordpress-snaps-up-longreads">Longreads is joining Automattic&#8217;s editorial team</a>. Today I&#8217;m excited to announce that <a href="http://www.scrollkit.com/">we&#8217;ve acquired Scroll Kit and they&#8217;re joining Automattic as well</a>, and will be focused on making customization more visual and intuitive. We&#8217;re barely on the second inning of what WordPress could be, and the impact it can have on the world, and I consider myself very lucky to be working with the best and brightest on transforming the way the world publishes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Apr 2014 00:32:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Automattic Snaps Up Scroll Kit to Add to the WordPress.com Product Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21755";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/automattic-snaps-up-scroll-kit-to-add-to-the-wordpress-com-product-team?utm_source=rss&utm_medium=rss&utm_campaign=automattic-snaps-up-scroll-kit-to-add-to-the-wordpress-com-product-team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3265:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/scroll-kit.png" rel="prettyphoto[21755]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/scroll-kit.png?resize=640%2C338" alt="scroll-kit" class="aligncenter size-full wp-image-21768" /></a></p>
<p>Scroll Kit founders Cody Brown and Kate Ray <a href="http://www.scrollkit.com/" target="_blank">announced</a> today that they are joining the product team at WordPress.com. Automattic, having recently acquired <a href="http://wptavern.com/automattic-acquires-longreads-invests-in-digital-longform-publishing" target="_blank">Longreads</a> and <a href="http://wptavern.com/cloudup-makes-file-sharing-incredibly-easy" target="_blank">Cloudup</a>, adds <a href="http://www.scrollkit.com/" target="_blank">Scroll Kit</a> to its collection, ostensibly in order to subsume its better features into WordPress.com.</p>
<p>Unlike Cloudup and Longreads, which have continued on with business as usual after acquisition, Scroll Kit will be shutting down its editor in three months as part of the deal. Users of the app are encouraged to export their scrolls in case a more native solution is available further down the road.</p>
<p>Scroll Kit allowed users to create beautiful web pages without writing a line of code. Its powerful visual content editor was actually used to<a href="http://techcrunch.com/2013/05/21/snow-fail-the-new-york-times-and-its-misunderstanding-of-copyright/" target="_blank"> recreate the New York Time&#8217;s interactive Snowfall experiment in an hour</a>, a project which NYT says took hundreds of hours of hand-coding. Although its makers cannot yet comment on their super secret future plans, one cannot help but wonder if this radically simplified visual editor may soon make its way into WordPress.com.</p>
<p>Scroll Kit already has a WordPress <a href="http://wordpress.org/plugins/scrollkit/" target="_blank">plugin</a> listed among WordPress.com VIP&#8217;s list of layout and organization <a href="http://vip.wordpress.com/plugins/" target="_blank">plugins</a>. This tool offered Scroll Kit users the ability to connect directly to self-hosted WordPress sites and create customized templates as well as change images, fonts, backgrounds, and add special effects. <strong>&#8220;We&#8217;ll take what we learned building Scroll Kit and apply it to a product that’s always been tightly integrated with ours,&#8221;</strong> Scroll Kit creators said, as they bid their current users goodbye.</p>
<p>Will WordPress.com incorporate Scroll Kit&#8217;s editor into the theme editing experience for its customers? If so, it will be interesting to see if some of those features trickle down to the open source WordPress project. With the instant popularity of front-end visual editors like <a href="http://velocitypage.com/" target="_blank">VelocityPage</a> for self-hosted sites, a simplified theme editing experience is bound to resonate with WordPress.com&#8217;s user base. Scroll Kit&#8217;s makers said that their objective was <strong>&#8220;to create a process for making the web that was more like drawing on a piece of paper.&#8221;</strong> If they can bring that experience to WordPress.com, then Automattic has just bought itself a magic wand.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 23:37:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: View More Themes in the WordPress Theme Browser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21736";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/view-more-themes-in-the-wordpress-theme-browser?utm_source=rss&utm_medium=rss&utm_campaign=view-more-themes-in-the-wordpress-theme-browser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3169:"<p><a href="http://wptavern.com/wordpress-3-9-smith-released" target="_blank">WordPress 3.9</a> brought a huge improvement to the WordPress theme browsing experience. By default, the new browser shows large preview images of themes with indicators for the ones you already have installed. It also allows for better filtering and exploring of featured and popular items.</p>
<div id="attachment_21121" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39ThemeExperience.png" rel="prettyphoto[21736]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39ThemeExperience.png?resize=859%2C503" alt="Theme Browser Experience Revamped In WordPress 3.9" class="size-full wp-image-21121" /></a><p class="wp-caption-text">Theme Browser Experience Revamped In WordPress 3.9</p></div>
<p>These updates to the theme browser make it far more likely that WordPress users will want to look for new themes without leaving the admin. The experience is much better than searching directly on WordPress.org.</p>
<h3>See More Themes</h3>
<p>Themes and their previews load quickly from WordPress.org, but the size of the thumbnails prevents you from seeing more of them on the screen at once. <a href="http://wordpress.org/plugins/see-more-themes/" target="_blank">See More Themes</a> is a new plugin, written by <a href="http://www.sdavismedia.com/" target="_blank">Sean Davis</a>, that allows you to browse more themes. When activated, the plugin modifies WordPress&#8217; default admin CSS for the theme browser, reducing the size of the thumbnails to display more themes.</p>
<p>The default theme browser looks like this:</p>
<div id="attachment_21748" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/old-theme-browser.png" rel="prettyphoto[21736]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/old-theme-browser.png?resize=1025%2C643" alt="Default Theme Browser" class="size-full wp-image-21748" /></a><p class="wp-caption-text">Default Theme Browser</p></div>
<p>When you have See More Themes activated, you&#8217;ll be able to take in more themes at a glance:</p>
<div id="attachment_21749" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/new-theme-browser.png" rel="prettyphoto[21736]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/new-theme-browser.png?resize=1025%2C643" alt="Theme Browser with See More Themes plugin activated" class="size-full wp-image-21749" /></a><p class="wp-caption-text">Theme Browser with See More Themes plugin activated</p></div>
<p>Sometimes it takes hours of browsing and previewing themes before you can settle on one that works for your site. See More Themes helps you browse through them faster while still presenting a decent sized thumbnail. It also maintains the theme browser&#8217;s responsiveness. If you like being able to see more themes at once, <a href="http://wordpress.org/plugins/see-more-themes/" target="_blank">download</a> the plugin from WordPress.org the next time you&#8217;re on the hunt for new themes in the admin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 22:10:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Why WordPress Can’t Kill Commercial Plugin Businesses";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21735";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/why-wordpress-cant-kill-commercial-plugin-businesses?utm_source=rss&utm_medium=rss&utm_campaign=why-wordpress-cant-kill-commercial-plugin-businesses";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2820:"<p><span class="post-byline"><span class="author publisher-anchor-color">Iain Poulson recently published a post that asks an important but easy question to answer. </span></span><a title="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/" href="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/">Will WordPress be a Plugin Business Killer?</a> The post is based on the idea that features from a commercial plugin added to WordPress could kill the business based on that plugin.</p>
<p>The short answer to Poulson&#8217;s question is <strong>no</strong>. Here&#8217;s why.</p>
<h3>WordPress Needs To Be Generic</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2009/08/gravitylogo.png" rel="prettyphoto[21735]"><img class="alignright size-full wp-image-2322" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2009/08/gravitylogo.png?resize=108%2C109" alt="gravityforms logo" /></a>WordPress serves a huge audience. Commercial plugins usually address a specific niche and hammer away at it with features and functionality. It wouldn&#8217;t make sense to take GravityForms or Backup Buddy and merge them into WordPress because those plugins are not generic enough to cover a wide audience.</p>
<p>Even if a GravityForms were to merge into core, it would likely be stripped of its niche focused functionality and probably be rewritten. It would be stripped to a point of basic functionality to cover the majority of WordPress users. GravityForms would likely continue to exist as a successful commercial plugin since it would contain features that didn&#8217;t make it to the core of WordPress.</p>
<h3>Don&#8217;t Sell Features, Sell Products</h3>
<p>Within the comments of the article, Carl Hancock of RocketGenius <a title="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/#comment-1352082767" href="http://www.polevaultweb.com/2014/04/will-wordpress-plugin-business-killer/#comment-1352082767">made a great point</a> when he said:</p>
<blockquote><p>To me a viable commercial product is just that. A product. Not a feature. If something is more of a feature, then unless it&#8217;s part of a collection of offerings it could be dicey to rely on it as a commercial plugin. Features aren&#8217;t products.</p></blockquote>
<p>I agree. Commercial plugins that are just glorified features are more at risk of being added to core than full-fledged products. Regardless of either camp, merging existing plugins into core is not a routine task. Outside of the features as plugins first model, it rarely happens.</p>
<p>I don&#8217;t think commercial plugin author needs to worry. Is it a possibility worth considering? Definitely, but it&#8217;s one of those thoughts that should be in the back of your mind, not the forefront.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 21:46:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Take the WordPress Contributor Experience Survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21701";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/take-the-wordpress-contributor-experience-survey?utm_source=rss&utm_medium=rss&utm_campaign=take-the-wordpress-contributor-experience-survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4205:"<div id="attachment_21721" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/we.jpg" rel="prettyphoto[21701]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/we.jpg?resize=1024%2C474" alt="photo credit:  - cc license" class="size-full wp-image-21721" /></a><p class="wp-caption-text">photo credit: <a href="https://flic.kr/p/mkLUc">23rdian</a> &#8211; <a href="https://creativecommons.org/licenses/by-nc/2.0/">cc</a> license</p></div>
<p>If you&#8217;ve ever contributed to the WordPress project, whether through code, documentation, plugins and themes, speaking at a WordCamp, etc., your feedback is requested on the WordPress <a href="http://wordpressdotorg.polldaddy.com/s/wordpress-contributor-experience-poll" target="_blank">Contributor Experience Survey</a>.  Jen Mylo <a href="http://make.wordpress.org/community/2014/04/24/contributor-experience-survey/" target="_blank">announced</a> the survey today, noting that none of the questions are mandatory.</p>
<p>One of the questions in the survey asks: <strong>&#8220;What can the WordPress project do to make current contributors feel valued?&#8221;</strong> Since the vast majority of community contributions to the project are done on a volunteer basis, the project is seeking feedback for recognizing and valuing those efforts.</p>
<p>Recent and continued <a href="http://wptavern.com/wordpress-org-profile-redesign-is-live" target="_blank">improvements to WordPress.org profiles</a> present a more accurate representation of a user&#8217;s involvement in the project and recognize users with badges that denote contributions to code, plugins, themes, WordCamps, as well as active participation in the groups listed on <a href="http://make.wordpress.org/" target="_blank">make.wordpress.org</a>. Do these badges resonate with contributors or are there more creative ways that the project can help them feel valued?</p>
<h3>Helping New Contributors Feel Welcome and Encouraged</h3>
<p>Another important question on the survey asks what the WordPress project can do better to make new contributors feel welcome and encouraged. Getting a better handle on this could potentially help the project expand its contributor base and move forward at a faster rate. This past year WordPress has launched several new initiatives targeted at improving new contributors&#8217; experiences.</p>
<p>Recent <a href="http://wptavern.com/wordpress-core-trac-gets-a-design-refresh-new-features-and-enhancements" target="_blank">updates to WordPress core trac</a>, as well as the <a href="http://make.wordpress.org/core/2014/01/27/proposed-trac-component-reorganization/" target="_blank">components reorganization</a>, have gone a long way toward helping contributors to specialize and stay informed on selected tickets. The addition of the <a href="https://core.trac.wordpress.org/query?keywords=~good-first-bug" target="_blank">“good-first-bug”</a> keyword helps to streamline areas where new contributors might get their feet wet.</p>
<p>In addition to helping new code contributors, the <a href="http://make.wordpress.org/community/author/andreamiddleton/" target="_blank">WordCamp Organizer Hangouts</a> have been instrumental in getting new organizers oriented with the responsibilities of leading an event. A <a href="http://make.wordpress.org/docs/2014/02/25/docs-issue-tracker/" target="_blank">preliminary version</a> of a new <a href="http://wptavern.com/coming-soon-an-issues-tracker-for-wordpress-documentation" target="_blank">issues tracker for WordPress documentation</a> was recently launched and will be refined to help documentation contributors work together more efficiently. However, there are many more areas where contributors might jump in that have not yet been optimized for newcomers.</p>
<p>The survey asks for feedback on user experiences contributing to the project, both positive and negative. If you have any thoughts on how WordPress can improve these experiences, take a few minutes to communicate your feedback via the <a href="http://wordpressdotorg.polldaddy.com/s/wordpress-contributor-experience-poll" target="_blank">Contributor Experience Survey</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 18:23:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Read Where You Write In WordPress With The Orbital Feed Reader Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=20779";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:202:"http://wptavern.com/read-where-you-write-in-wordpress-with-the-orbital-feed-reader-plugin?utm_source=rss&utm_medium=rss&utm_campaign=read-where-you-write-in-wordpress-with-the-orbital-feed-reader-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3366:"<p>When <a title="http://googlereader.blogspot.com/2013/07/a-final-farewell.html" href="http://googlereader.blogspot.com/2013/07/a-final-farewell.html">Google Reader was shut down</a> on July 2nd, 2013, those who use RSS searched far and wide for suitable replacements. I&#8217;ve settled on using <a title="http://feedly.com/" href="http://feedly.com/">Feedly </a>for my needs. However, there is a plugin available that adds an RSS reader to WordPress so you can create blog posts as you read RSS feeds from within the same interface. It&#8217;s called <a title="http://wordpress.org/plugins/orbital-feed-reader/" href="http://wordpress.org/plugins/orbital-feed-reader/">Orbital Feed Reader</a> and is available on the WordPress plugin directory.</p>
<div id="attachment_21690" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/FeedsWithinOrbitalFeedReader.png" rel="prettyphoto[20779]"><img class="size-full wp-image-21690" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/FeedsWithinOrbitalFeedReader.png?resize=1025%2C559" alt="My Feeds Within Orbital Feed Reader" /></a><p class="wp-caption-text">My Feeds Within Orbital Feed Reader</p></div>
<p>By default, Orbital is subscribed to a few different feeds to get you started. The design of the interface is a far cry from what I&#8217;m use to with Feedly. Because of the way content from feeds are displayed, it&#8217;s hard to determine when posts begin and end. The way the content is displayed makes it hard to decipher, especially if the content contains a lot of images.</p>
<p>If you can get past those setbacks, the feed reader performs as advertised. At the end of each article is a Blog This button. Clicking the button opens up the Press This bookmarklet enabling you to quickly post content to your site. Any text that is highlighted within the article before the button is selected will automatically be shown in the content area of the <a title="http://codex.wordpress.org/Press_This" href="http://codex.wordpress.org/Press_This">Press This bookmarklet</a>. Being able to read feeds and quickly publish articles to a blog is a nice convenience.</p>
<p>You can add feeds either by importing an OPML file or by using a site&#8217;s RSS feed URL.</p>
<div id="attachment_21691" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OrbitalHowToAddFeeds.png" rel="prettyphoto[20779]"><img class="size-full wp-image-21691" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OrbitalHowToAddFeeds.png?resize=542%2C208" alt="How To Add Feeds In Orbital" /></a><p class="wp-caption-text">How To Add Feeds In Orbital</p></div>
<h3>I&#8217;m Sticking With Feedly</h3>
<p>Although I don&#8217;t use my feed reader as much as I used to, I prefer Feedly over Orbital because of the synching options between the web and mobile versions of the service. Feedly also displays content in a way that makes it easier to read compared to Orbital. Last but not least, I have the Press This bookmarklet installed in FireFox so I can blog stories from anywhere on the web.</p>
<p>With that said, the plugin&#8217;s purpose is to enable users to read RSS feeds and easily create blog content from within the same interface. It&#8217;s the plugin&#8217;s shining feature and it does so without any problems.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Apr 2014 17:42:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"WPTavern: ThemeLab Acquired By Syed Balkhi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:128:"http://wptavern.com/themelab-acquired-by-syed-balkhi?utm_source=rss&utm_medium=rss&utm_campaign=themelab-acquired-by-syed-balkhi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3938:"<p><a title="https://www.themelab.com/" href="https://www.themelab.com/">ThemeLab</a>, a popular site dedicated to WordPress theme topics has been acquired by <a title="http://www.balkhis.com/" href="http://www.balkhis.com/">Syed Balkhi</a>. ThemeLab has been a valuable resource of information since 2007. Leland Fiegel, the site&#8217;s previous owner made a positive mark within the community <a title="http://www.themelab.com/stop-downloading-wordpress-themes-from-shady-sites/" href="http://www.themelab.com/stop-downloading-wordpress-themes-from-shady-sites/">when he published an in-depth post</a> explaining why users shouldn&#8217;t download and use themes from shady sites discovered in Google.</p>
<div id="attachment_19876" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/03/ThemeLabShadySites.gif" rel="prettyphoto[19860]"><img class="size-large wp-image-19876" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/03/ThemeLabShadySites.gif?resize=500%2C265" alt="Don\'t Download Themes From Shady Sites" /></a><p class="wp-caption-text">Don&#8217;t Download Themes From Shady Sites</p></div>
<p>According to the <a title="https://www.themelab.com/about-us/" href="https://www.themelab.com/about-us/">about page</a>, the acquisition took place in 2013. During the time of acquisition, Balkhi and his team have revamped the site and turned it into a commercial theme shop. The site&#8217;s mission statement fits in with a trend we&#8217;ve noticed with commercial themes in general: &#8220;While most companies are focused on either design or functionality, our approach is to bring the best of both worlds with a special emphasis on usability.&#8221;</p>
<blockquote><p>As a WordPress user watching from the sidelines, I’ve noticed that themes have become extremely complex over the last several years. The race to add more features, more options, more shortcodes, and more of everything has led developers to lose sight of what’s more important: <strong>usability</strong>.</p>
<p>Beginners who are just starting out no longer find WordPress to be easy. A lot of this has to do with themes because that’s their first encounter. Having to go through 600 options just to get the theme to look like the demo is beyond silly.</p></blockquote>
<p>All of the free themes released on ThemeLab have been retired and are no longer available for download. Tutorials published by Fiegel will be updated as necessary with new ones on the way.</p>
<h3>What&#8217;s Next For Fiegel?</h3>
<p>ThemeLab has been an excellent resource of information within the WordPress community over the years. It&#8217;s awesome to see Fiegel has found the right buyer with the right price. In a <a title="http://leland.me/six-years-of-theme-lab/" href="http://leland.me/six-years-of-theme-lab/">detailed post on his personal blog</a>, Fiegel explains what the past six years have been like running ThemeLab as well the lessons he learned.</p>
<p>His next endeavor is called <a title="http://pluginferno.com/" href="http://pluginferno.com/">Pluginferno</a> and focuses on commercial plugins for WordPress, addons for existing popular plugins, plugin reviews, and commentary about the WordPress community in general.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/Testing.png" rel="prettyphoto[19860]"><img class="aligncenter size-full wp-image-21672" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/Testing.png?resize=1025%2C772" alt="Testing" /></a></p>
<p>He&#8217;ll also be entering the commercial theme market through <a title="http://powertheme.com/" href="http://powertheme.com/">PowerTheme</a>. There&#8217;s not a lot of information about the site but it will sell 100% GPL licensed themes. Both sites give Fiegel a fresh start. The lessons learned from running ThemeLab should make it easier for his new endeavors to be financially successful.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 21:41:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Have You Turned On Akismet 3.0′s Silent Discard Feature?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21649";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/have-you-turned-on-akismet-3-0s-silent-discard-feature?utm_source=rss&utm_medium=rss&utm_campaign=have-you-turned-on-akismet-3-0s-silent-discard-feature";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3926:"<p><a href="http://wordpress.org/plugins/akismet/" target="_blank">Akismet</a> is one of those quiet utility plugins that works in the background of your WordPress site without a lot of fanfare. When it&#8217;s doing it&#8217;s job, your blog comments stay spam-free and you never think twice about it. Forgetting to activate Akismet on a new site will quickly remind you of just how much spam is targeted at WordPress sites.</p>
<p><a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/" target="_blank">Akismet 3.0</a> is a major rewrite of the plugin that improves its efficiency in handling the worst spam that hits your site. When you visit your Akismet settings you&#8217;ll see how many days of your life Akismet has saved you as well as some new stats and graphs demonstrating the plugin&#8217;s effectiveness. Here&#8217;s an example from a small, personal blog:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-settings.jpg" rel="prettyphoto[21649]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-settings.jpg?resize=795%2C545" alt="akismet-settings" class="aligncenter size-full wp-image-21659" /></a></p>
<h3>Akismet 3.0&#8242;s Silent Discard Feature Improves Performance</h3>
<p>In addition to an easier signup and configuration process, this version introduced a silent discard feature that identifies and outright blocks the worst spam comments.</p>
<p>Throughout the course of improving Akismet, the team found that approximately 80% of spam is so bad that it could be flagged as “pervasive.” The silent discard feature causes pervasive spam to bypass the spam folder entirely so that you&#8217;ll never see it.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-discard-spam-feature.png" rel="prettyphoto[21649]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/akismet-discard-spam-feature.png?resize=697%2C116" alt="akismet-discard-spam-feature" class="aligncenter size-full wp-image-21657" /></a></p>
<p>The plugin previously had a relatively ineffective option that allowed site owners the ability to automatically discard spam on older posts. This didn&#8217;t do much to block the worst spam and users found it to be confusing.</p>
<p>Akismet 3.0 remembers your selections for this previous feature and applies them to the new silent discard feature. In most cases this means that the silent discard will be automatically turned on when you update the plugin. For users who are new to Akismet, the default setting is to store the pervasive spam in the spam folder for 15 days. The silent discard feature will need to be turned on from the plugin&#8217;s configuration page.</p>
<p>There are some very compelling reasons to turn this new feature on. When <a href="http://blog.akismet.com/2014/04/23/theres-a-ninja-in-your-akismet/" target="_blank">announcing</a> the silent discard option, the folks at Akismet said that <strong>&#8220;enabling the feature can result in significant reductions in your storage and resource usage requirements.&#8221;</strong> This is especially true on sites that are always publishing new content. Silently discarding the most pervasive spam, instead of storing all of it for 15 days, frees up the storage and resources required to display and manage those spam comments in the admin.</p>
<p>Akismet has zapped more than 135 billion spam comments and track backs to date, and the service is getting smarter at defeating the worst spam. The most important spam-fighting feature of 3.0 is the ability to silently discard pervasive spam before it even has the chance to land on your doorstop and get logged in your database. Turning this option on is a no-brainer. If you haven&#8217;t yet updated your plugins or have been waiting to update to WordPress 3.9, Akismet 3.0&#8242;s silent discard feature is another reason to get moving on those updates.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 21:04:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Tweet Archive: A Free WordPress Theme to Match the New Twitter Profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21511";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:204:"http://wptavern.com/tweet-archive-a-free-wordpress-theme-to-match-the-new-twitter-profiles?utm_source=rss&utm_medium=rss&utm_campaign=tweet-archive-a-free-wordpress-theme-to-match-the-new-twitter-profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3922:"<p>Yesterday, Twitter <a href="https://blog.twitter.com/2014/your-new-web-profile-is-here" target="_blank">announced</a> that it was rolling out the new profile redesign to all users. If you haven&#8217;t updated your Twitter profile, you can click on the &#8220;Get it Now&#8221; button on the <a href="https://about.twitter.com/products/new-profiles" target="_blank">new profiles product page</a>.</p>
<p>Last week we featured <a href="http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress" target="_blank">Ozh’ Tweet Archiver</a> as an easy way to archive your tweets to WordPress. The 2.0 version of the plugin has been updated to work with Twitter’s OAuth API and 2.0.1 has support for post formats, thanks to a contribution from <a href="http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress#comment-54394" target="_blank">Chip Bennett</a>. Ozh also updated the Tweet Archive WordPress theme that accompanies the plugin in order to more closely match Twitter&#8217;s new profile design.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/tweet-archiver-theme.jpg" rel="prettyphoto[21511]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/tweet-archiver-theme.jpg?resize=1025%2C589" alt="tweet-archiver-theme" class="aligncenter size-full wp-image-21624" /></a></p>
<p>You can view a <a href="http://planetozh.com/tweets/" target="_blank">live demo</a> on Ozh&#8217;s tweet archive site. He created the theme for his own use so you&#8217;ll need to edit a few files to personalize it. It was designed to work in combination with the plugin, so the top bar displaying total tweets, following, and followers only works with the plugin installed. The theme utilizes Font Awesome icons within the tweet archive and social accounts display. It also has support for a sidebar which you can use to allow easy browsing of archived tweets, stats, hashtags, or anything you wish.</p>
<p>All of the user info in the left column can be customized in the <em>header.php</em> file as well as the avatar. The header image can be changed in <em>style.css</em>. It would be cool if the theme was updated to use WordPress&#8217; custom header feature, but it wasn&#8217;t really created for distribution. Ozh has the project open to contribution, however, if anyone is interested in refining the theme.</p>
<h3>Use Your WordPress-Powered Twitter Archive to Boost Traffic</h3>
<p>Tweet Archive includes a search bar within the header, since WordPress&#8217; search feature is much easier to use when looking for specific content within your tweets. Ryan Hellyer, who has his tweets backed up to a subdomain, <a href="http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress#comment-54142" target="_blank">commented</a> on our previous post, highlighting another merit to hosting your own archive:</p>
<blockquote><p>Another unexpected benefit, is that I actually get traffic from it. Google seems to preferentially send traffic my way instead of to Twitter itself sometimes.</p></blockquote>
<p>If you&#8217;re getting extra traffic from hosting your own Twitter archive, you may want to make use of Twitter&#8217;s new pinned tweet feature. This should be easy to accomplish in your archive with WordPress&#8217; built-in sticky posts and a little bit of CSS to make it a larger entry. That way, when visitors land on your archive, they will see your curated favorites at the top of the list.</p>
<p>If you&#8217;re using the <a href="http://wordpress.org/plugins/ozh-tweet-archiver/" target="_blank">Ozh Tweet Archiver plugin</a> to automatically archive your tweets to WordPress and you want a theme that will approximate the new Twitter design, grab the <a href="https://github.com/ozh/ozh-tweet-archive-theme" target="_blank">Tweet Archive WordPress theme</a> on Github and customize it to match your Twitter profile.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 18:20:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"Akismet: There’s a Ninja in Your Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1351";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://blog.akismet.com/2014/04/23/theres-a-ninja-in-your-akismet/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2910:"<p>One of our favorite additions to <a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/">Akismet 3.0</a> is the new discard setting. Previously, our plugin featured an option that allowed site owners the ability to automatically discard spam on older posts. But, as some may certainly agree, it was rather confusing and had little effect on the world&#8217;s smarter spammers.</p>
<p>After giving thought to how we could improve that particular setting and the overall user experience, we found that approximately 80% of spam could be flagged as &#8220;pervasive&#8221;, meaning that it is the absolute worst of the worst (of the worst!). In fact, that 80% is so bad that there is simply no benefit in paying any attention to it at all. Not even for kicks and giggles. Trust us.</p>
<p>We came up with something that would allow you to automatically and silently discard all of that pervasive spam attacking your site so that it never even appears in your &#8220;Spam&#8221; folder. The new setting identifies the <strong>worst and most pervasive</strong> spam (which can certainly change over time) on our side during the comment check and will immediately discard it if you&#8217;ve configured the plugin to do so. </p>
<p>If you&#8217;re new to Akismet, these spam comments will be stored by default; you must activate the new feature from the plugin&#8217;s configuration page (if you upgraded to 3.0, Akismet will use the previous value of your 30-day discard setting) :</p>
<p><a href="http://akismet.files.wordpress.com/2014/04/akismet-discard-spam-feature.png"><img src="http://akismet.files.wordpress.com/2014/04/akismet-discard-spam-feature.png?w=640&h=106" alt="Akismet Discard Spam Feature" width="640" height="106" class="alignnone size-large wp-image-1376" /></a></p>
<p>It&#8217;s all very ninja-esque, we think. What&#8217;s more, enabling the feature can result in significant reductions in your storage and resource usage requirements.</p>
<p>This is a great step forward in our mission to make the web a cleaner place. We tested the feature on <a href="http://wordpress.com/">WordPress.com</a> and received excellent results and feedback prior to rolling it into the plugin. So, we think (and hope) you&#8217;ll enjoy it. We are also working on an enhancement to the feature, which will highlight the pervasive spam comments in the &#8220;Spam&#8221; folder for users who choose to store them.</p>
<p>If you have any feedback on the new feature, we would love to <a href="http://akismet.com/contact/">hear from you</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1351/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1351/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1351&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Apr 2014 13:09:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: New Plugin Adds Less CSS Preprocessor to WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21533";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/new-plugin-adds-less-css-preprocessor-to-wordpress-themes?utm_source=rss&utm_medium=rss&utm_campaign=new-plugin-adds-less-css-preprocessor-to-wordpress-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3374:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/less-theme-support.jpg" rel="prettyphoto[21533]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/less-theme-support.jpg?resize=772%2C250" alt="less-theme-support" class="aligncenter size-full wp-image-21583" /></a></p>
<p>Many WordPress developers opt to use the <a href="http://lesscss.org/" target="_blank">Less</a> CSS preprocessor to speed up theme development. Its availability of variables, mixins, and functions allows you to do more with CSS and to do it more efficiently. It also makes it easy to compile and minify files for production use. However, the initial setup for adding Less to each theme is a somewhat time-consuming process.</p>
<p>Justin Kopepasah wrote a tutorial in the past for <a href="http://kopepasah.com/tutorial/using-less-in-a-live-wordpress-theme/" target="_blank">using LESS in a live WordPress theme</a>, followed by one that <a href="http://kopepasah.com/tutorial/easily-add-less-css-pre-processor-to-any-wordpress-theme/" target="_blank">automated the process</a> by setting up the functionality as a Git submodule. Over time, he found that adding Less to each theme was becoming quite a chore, so he created a plugin to make the process easier for anyone.</p>
<p>Kopepasah&#8217;s <a href="https://wordpress.org/plugins/less-theme-support/" target="_blank">Less Theme Support</a> plugin radically simplifies the process of adding Less to your WordPress theme. It requires just two simple steps following activation:</p>
<ol>
<li>Add <em>style.less</em> to your theme&#8217;s root directory</li>
<li>Add theme support to the after_setup_theme hook:
<pre class="brush: php; light: true; title: ; notranslate">add_theme_support( \'less\', array( \'enable\' =&gt; true ) );</pre>
</li>
</ol>
<p>Less Theme Support comes with four different options which change how it functions on development vs. production sites. All are boolean values defaulting to false:</p>
<ul>
<li><strong>enable</strong> – Enables Less and enqueues <em>less.min.js</em> on the front end.</li>
<li><strong>develop</strong> – Enables development environment for Less and enqueues <em>less-develop.js</em>.</li>
<li><strong>watch</strong> – Enables watch mode for Less and enqueues <em>less-watch.js</em>.</li>
<li><strong>minify</strong> – Enables usage of a minified stylesheet (<em>style.min.css</em>) on the front end for all other visitors (best generated using lessc -x style.less > style.min.css).</li>
</ul>
<p>These options give you quite a bit of flexibility. For example, during development you might configure your theme support with the enable, develop, and watch options:</p>
<pre class="brush: php; title: ; notranslate">add_theme_support( \'less\', array(
    \'enable\'  =&gt; true,
    \'develop\' =&gt; true,
    \'watch\'  =&gt; true
) );</pre>
<p>Less theme support in production would us the minify option:</p>
<pre class="brush: php; title: ; notranslate">add_theme_support( \'less\', array(
 \'minify\' =&gt; true
) );</pre>
<p>Using the <a href="https://wordpress.org/plugins/less-theme-support/" target="_blank">Less Theme Support</a> plugin provides a much cleaner and easier way to add Less to your theme. Download it from WordPress.org or via the project&#8217;s page on <a href="https://github.com/kopepasah/less-theme-support" target="_blank">Github</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 21:49:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WPTavern: Display Before and After Images In WordPress With The TwentyTwenty Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=20955";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:210:"http://wptavern.com/display-before-and-after-images-in-wordpress-with-the-twentytwenty-plugin?utm_source=rss&utm_medium=rss&utm_campaign=display-before-and-after-images-in-wordpress-with-the-twentytwenty-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4181:"<p>Have you ever wanted to combine two images to show a before and after? You can&#8217;t do that with WordPress out of the box but it&#8217;s possible if you use the <a title="http://wordpress.org/plugins/twentytwenty/" href="http://wordpress.org/plugins/twentytwenty/">TwentyTwenty plugin</a> by <a title="http://aspiringwebdev.com/" href="http://aspiringwebdev.com/">Corey Martin</a>. The plugin takes advantage of the <a title="http://www.w3schools.com/cssref/pr_pos_clip.asp" href="http://www.w3schools.com/cssref/pr_pos_clip.asp">clip property</a> within CSS by stacking two identical sized images on top of each other. The clip property allows the image to show through the container. The slider is responsive and uses custom movement events within the <a title="https://github.com/stephband/jquery.event.move" href="https://github.com/stephband/jquery.event.move">jQuery Event Move library</a> to support <strong>1:1</strong> slider movement on mobile devices.</p>
<p>The plugin is very simple to use. Upload two identical sized images to the media library. When inserting images into a post, make sure the attachment display settings for image size are the same. Add the <strong>[TwentyTwenty]</strong> shortcode above the before image. Add <strong>[/TwentyTwenty]</strong> after the second image. Here&#8217;s an example of the shortcode added to a post.</p>
<div id="attachment_21585" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyShortcode.png" rel="prettyphoto[20955]"><img class="size-full wp-image-21585" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyShortcode.png?resize=754%2C703" alt="TwentyTwenty Shortcode In Action" /></a><p class="wp-caption-text">TwentyTwenty Shortcode In Action</p></div>
<p>The shortcode generates a slider that can be moved back and forth. You&#8217;ll see which images are before and after when you hover over the slider. To see either image, users must click and drag the circle left or right.</p>
<div id="attachment_21588" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyBefore.png" rel="prettyphoto[20955]"><img class="size-full wp-image-21588" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyBefore.png?resize=650%2C200" alt="TwentyTwenty Before Image" /></a><p class="wp-caption-text">TwentyTwenty Before Image</p></div>
<div id="attachment_21587" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyAfter.png" rel="prettyphoto[20955]"><img class="size-full wp-image-21587" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/TwentyTwentyAfter.png?resize=650%2C200" alt="TwentyTwenty After Image" /></a><p class="wp-caption-text">TwentyTwenty After Image</p></div>
<p>The plugin was written using <a title="http://sass-lang.com/" href="http://sass-lang.com/">Sass</a> and Zurb.com has a <a title="http://zurb.com/playground/twentytwenty" href="http://zurb.com/playground/twentytwenty">listing of each Sass variable</a> used and what its default value is. The variables enable you to control everything from the handle color to the handle radius.</p>
<p>Here are a couple of ideas where TwentyTwenty would be ideal to use.</p>
<ul>
<li>Compare counterfeit merchandise to real merchandise</li>
<li>Website redesigns</li>
<li>Home improvement renovations</li>
</ul>
<p>During my test with WordPress 3.9, I didn&#8217;t experience any problems. According to Martin, <a title="http://wordpress.org/support/plugin/twentytwenty" href="http://wordpress.org/support/plugin/twentytwenty">TwentyTwenty</a> is compatible with the latest versions of Chrome, Safari, FireFox, iOS, IE 9, and above. If you want to see the plugin in action, you can either watch this screencast by Martin or visit the <a title="http://zurb.com/playground/twentytwenty" href="http://zurb.com/playground/twentytwenty">plugin&#8217;s page on Zurb.com</a>.</p>
<p><span class="embed-youtube"></span></p>
<p><strong>Outside of showing before and after images, what other creative ways could this plugin be used?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 21:20:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WPTavern: WordPress 3.9 Adds 30 New Dashicons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21545";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:134:"http://wptavern.com/wordpress-3-9-adds-30-new-dashicons?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-9-adds-30-new-dashicons";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1541:"<p><a title="http://melchoyce.github.io/dashicons/" href="http://melchoyce.github.io/dashicons/">Dashicons</a> are what’s known as an icon font and were added to the core of WordPress with the release of 3.8. The icons are vector based so they can be as large or small as you want without losing quality. Plugin authors can use CSS, HTML, or a Glyph for use within Photoshop to display an icon. While 3.8 had 167 icons, WordPress 3.9 shipped with <a title="http://make.wordpress.org/core/2014/04/16/dashicons-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/16/dashicons-in-wordpress-3-9/">30 new Dashicons</a> bringing the total to 197.</p>
<div id="attachment_21547" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39Dashicons.png" rel="prettyphoto[21545]"><img class="size-full wp-image-21547" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WP39Dashicons.png?resize=652%2C313" alt="New Dashicons In WordPress 3.9" /></a><p class="wp-caption-text">New Dashicons In WordPress 3.9</p></div>
<p>The icons cover Media, TinyMCE, WordPress.org, Sorting, Widgets, Alerts, and Miscellaneous. Some plugin authors have already opted out of using a bitmap image and are using a Dashicon to represent their plugin within the WordPress admin menu. If none of the Dashicons match your use case, try <a title="http://genericons.com" href="http://genericons.com">Genericons</a> instead. Genereicons is also an icon font but has icons that are not focused on WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 19:37:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: Automattic Introduces Postbot App for Scheduling Photo Posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21535";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/automattic-introduces-postbot-app-for-scheduling-photo-posts?utm_source=rss&utm_medium=rss&utm_campaign=automattic-introduces-postbot-app-for-scheduling-photo-posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4368:"<p>Today Automattic introduced <a href="https://postbot.co/" target="_blank">Postbot</a>, a new stand-alone application for scheduling image posts. The new app allows users to upload multiple images and schedule them out over several days. Postbot creates a post for each image and automatically posts them to the selected blog, saving users the trouble of manually scheduling each one.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/postbot.gif" rel="prettyphoto[21535]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/postbot.gif?resize=752%2C376" alt="postbot" class="aligncenter size-full wp-image-21539" /></a></p>
<p>When using <a href="https://postbot.co/">Postbot</a>, you&#8217;ll need to connect via WordPress.com. The app is automatically connected to your main WordPress.com blog but once logged in you&#8217;ll have the option to connect other sites. Self-hosted WordPress sites can use the app via <a href="http://jetpack.me/" target="_blank">Jetpack</a> with the <a href="http://jetpack.me/support/json-api/" target="_blank">JSON API module</a> enabled.</p>
<p>Right now, you can only use the app from a desktop or mobile browser and John Godley, representing Automattic, says that a mobile app is not currently in the works. He elaborated on why they chose to create it as a standalone web app:</p>
<blockquote><p>Postbot lets us provide a very targeted set of features to anyone with a WordPress.com or WordPress.org/Jetpack blog (or both), from one central place. It’s already mobile-ready so a special mobile app isn&#8217;t currently planned.</p></blockquote>
<p>The experience of visiting <a href="https://postbot.co/" target="_blank">Postbot.co</a> from a mobile browser is not unlike using a mobile app. Those who plan to use it frequently via mobile can easily set a bookmark for quick launch while on the go.</p>
<h3>Postbot Puts Photo Publishing on Autopilot</h3>
<p>Postbot allows you to upload up to 50 photos at once to be published individually on different dates. While the images are uploading you can edit the titles, tags and content for each. The option to set a category is planned for a future version.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/uploading-postbot.png" rel="prettyphoto[21535]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/uploading-postbot.png?resize=688%2C311" alt="uploading-postbot" class="aligncenter size-full wp-image-21550" /></a></p>
<p>Scheduling allows you to set the number of days between posts published with the option to ignore weekends.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/schedule_postbot.png" rel="prettyphoto[21535]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/schedule_postbot.png?resize=635%2C42" alt="schedule_postbot" class="aligncenter size-full wp-image-21551" /></a></p>
<p>The app doesn&#8217;t yet allow you to set the featured image, but it&#8217;s on Automattic&#8217;s list of <a href="https://github.com/Automattic/Postbot/issues/6" target="_blank">feature requests</a> for future enhancements.</p>
<p>Postbot is an excellent example of the kinds of apps that can be created using the <a href="http://developer.wordpress.com/docs/api/" target="_blank">WordPress.com API</a>. If you want to take a peek under the hood, the app&#8217;s code was released under the GPL and can be found on <a href="https://github.com/Automattic/Postbot" target="_blank">Github</a>. This means that anyone can host their own Postbot web app or create interesting variations that interact with WordPress.com services.</p>
<p>Postbot is potentially very useful for photobloggers who want to break up their posts into individual images. It could also be handy for automating sites that are dedicated to publishing photos every day, i.e. &#8220;The Daily Kitten&#8221; or &#8220;Your Daily Dose of Fun.&#8221; It allows these kinds of sites to go on autopilot for publishing fresh content on a regular basis. Publishing new posts multiple times per day is an option <a href="http://en.blog.wordpress.com/2014/04/22/postbot-scheduled-photos/#comment-202397" target="_blank">currently under consideration</a> and may be a possibility in the future. We&#8217;ll be following the app&#8217;s progress as it adds new features based on user feedback.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 19:17:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Mike Little: Apologies for the old posts.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=2023";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:147:"http://journalized.zed1.com/archives/2014/04/22/apologies-for-the-old-posts/?utm_source=rss&utm_medium=rss&utm_campaign=apologies-for-the-old-posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:598:"<p>Folks, it looks like when I moved this old blog from a subdirectory to a subdomain, <a href="http://planet.wordpress.org">planet.wordpress.org</a> (the feed that shows up in your dashboard) thought my last few old posts were new. Hence a lot of old stuff appeared in your dashboard.</p>
<p>Sorry for the confusion&#8230;</p>
<p>Mike</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2014/04/22/apologies-for-the-old-posts/">Apologies for the old posts.</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 14:36:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: How The Advanced Image Editing Properties Contributed To WordPress Theme Lock-in";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21488";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/how-the-advanced-image-editing-properties-contributed-to-wordpress-theme-lock-in?utm_source=rss&utm_medium=rss&utm_campaign=how-the-advanced-image-editing-properties-contributed-to-wordpress-theme-lock-in";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6280:"<p>Although <a title="http://wptavern.com/wordpress-3-9-smith-released" href="http://wptavern.com/wordpress-3-9-smith-released">WordPress 3.9</a> has refined the media editing experience, it did so at the cost of removing a feature users appreciated. In WordPress 3.8, users could easily add a border, vertical, and horizontal padding to images. WordPress 3.9 removed this from the advanced image settings screen.</p>
<p>It’s not just those who use the self-hosted version of WordPress <a title="http://wordpress.org/support/topic/major-problems-with-image-editing-in-wp-39?replies=12" href="http://wordpress.org/support/topic/major-problems-with-image-editing-in-wp-39?replies=12">that are upset with the change</a>. A WordPress.com <a title="http://en.forums.wordpress.com/topic/image-resize-1?replies=430" href="http://en.forums.wordpress.com/topic/image-resize-1?replies=430">support forum thread</a> with over 430 posts is filled with users asking why the feature was removed. In some cases, WordPress.com staff are explaining how to use HTML code to add or remove borders to images.</p>
<p>Thankfully, there&#8217;s a new plugin available that not only restores the original advanced image settings but has expanded upon them. The plugin is called <a title="http://wordpress.org/plugins/advanced-image-styles/" href="http://wordpress.org/plugins/advanced-image-styles/">Advanced Image Styles</a> and is maintained by <a title="http://profiles.wordpress.org/gcorne/" href="http://profiles.wordpress.org/gcorne/">Gregory Cornelius</a>. As you can see, users can now apply padding in all four directions instead of two. You can also apply a border color instead of just the border width.</p>
<div id="attachment_21489" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/AdvancedImageEditingOptions.png" rel="prettyphoto[21488]"><img class="size-full wp-image-21489" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/AdvancedImageEditingOptions.png?resize=840%2C401" alt="Advanced Image Editing Styles" /></a><p class="wp-caption-text">Advanced Image Styles</p></div>
<p><a title="http://wordpress.org/support/view/plugin-reviews/advanced-image-styles" href="http://wordpress.org/support/view/plugin-reviews/advanced-image-styles">Early reviews</a> indicate users are happy to see these options return despite having to use a plugin. Unfortunately, those on WordPress.com are still out of luck. A member of the WordPress.com staff says <a title="http://en.forums.wordpress.com/topic/image-resize-1/page/15?replies=430#post-1754610" href="http://en.forums.wordpress.com/topic/image-resize-1/page/15?replies=430#post-1754610">it&#8217;s possible</a> the plugin will be merged into the WordPress.com codebase.</p>
<blockquote><p>I have asked the developers if this will be merged. At the moment I have not heard back. I will let you know as soon as possible!</p></blockquote>
<h3>These Options Are Causing Theme Lock-in</h3>
<p>If themes are coded to properly handle image padding and borders, the options within WordPress are redundant and unnecessary. What&#8217;s troubling is users are utilizing these options to override the styling within the theme instead of changing its CSS stylesheet.</p>
<p>In a test on my local server, I used the advanced image editing options to add a black, four pixel border to an image within the media library. Then I switched themes to see if the border was still there. I discovered that settings applied to images via the WordPress image editing options are displayed no matter which theme is used.</p>
<div id="attachment_21520" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OldTavernDesign.png" rel="prettyphoto[21488]"><img class="size-full wp-image-21520" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/OldTavernDesign.png?resize=605%2C339" alt="Old Tavern Design With The Black Image Border" /></a><p class="wp-caption-text">Old Tavern Design With The Black Image Border</p></div>
<div id="attachment_21519" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/NewTavernDesign.png" rel="prettyphoto[21488]"><img class="size-full wp-image-21519" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/NewTavernDesign.png?resize=665%2C387" alt="New Tavern Design With The Black Image Border" /></a><p class="wp-caption-text">New Tavern Design With The Black Image Border</p></div>
<p>If a user switches to a theme that uses a color scheme not compatible with the image border color, each image has to be edited individually within the media library. Each time an image is edited using the advanced settings provided by WordPress, you lose more theme compatibility and it further locks you in to a specific theme.</p>
<h3>WordPress.com vs. Self-hosted WordPress</h3>
<div id="attachment_21515" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WPcomWporg.png" rel="prettyphoto[21488]"><img class="wp-image-21515 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/WPcomWporg.png?resize=738%2C296" alt="WPcomWporg" /></a><p class="wp-caption-text">WordPress.com and WordPress.org</p></div>
<p>I understand why WordPress.com users would be so upset with the removal of these options. By default, they don&#8217;t have the ability to edit their theme&#8217;s CSS file. That is reserved as a paid upgrade. So these options give them a chance to override the styling within the theme without having the paid upgrade.</p>
<p>For self-hosted WordPress users, there is no excuse. Image borders and padding should be controlled through the theme, not the advanced image editing options provided by WordPress. Despite the options making it easy to apply those changes to images, users are only hurting themselves by using them.</p>
<p>I think the options for padding and image borders should stay removed from the self-hosted version of WordPress while restored on WordPress.com. In retrospect, these options should have never existed in the first place.</p>
<p><strong>Do you think the image border width, color, and padding options should be restored to the self-hosted version of WordPress?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Apr 2014 01:37:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Mike Little: WordPress 10th Anniversary: a Reflection";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1929";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:171:"http://journalized.zed1.com/archives/2013/05/27/wordpress-10th-anniversary-a-reflection/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-10th-anniversary-a-reflection";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:468:"<p>I posted about <a href="http://mikelittle.org/wordpress-10th-anniversary/">WordPress&#8217; 10th Anniversary</a> celebration and reflected on the last 10 years over on my new blog</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2013/05/27/wordpress-10th-anniversary-a-reflection/">WordPress 10th Anniversary: a Reflection</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Mike Little: WordPress – A 10 year journey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1867";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:147:"http://journalized.zed1.com/archives/2013/01/25/wordpress-a-10-year-journey/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-a-10-year-journey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2530:"<p><a href="http://journalized.zed1.com/wp-content/uploads/2013/01/wordpress-logo-notext-rgb.png"><img class="size-thumbnail wp-image-1873 alignleft" alt="WordPress logo" src="http://journalized.zed1.com/wp-content/uploads/2013/01/wordpress-logo-notext-rgb-150x150.png" width="150" height="150" /></a></p>
<p>I find it hard to believe but it has now been <strong>ten years</strong> since my fateful <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">comment on Matt&#8217;s blog </a>that kicked off what became the <a href="http://wordpress.org/">WordPress</a> project!<br />
From those humble beginnings of a simple unmaintained blogging platform (b2/Cafelog) to a world-beating open source CMS. B2/Cafelog was used by perhaps 2,000 bloggers. Now WordPress runs more than <a href="http://en.wordpress.com/stats/">60 million sites</a> around the world. That&#8217;s over <a href="http://w3techs.com/technologies/overview/content_management/all">17.5% of the web</a>!</p>
<h2>WordPress Industry</h2>
<p>WordPress now supports a world-wide industry from individual <a href="http://mikelittle.org/">WordPress specialists</a> like me (I&#8217;ve just completed my fourth year as my own company <a href="http://zed1.com/">zed1.com</a>); small WordPress-based companies like <a href="http://codeforthepeople.com/">Code for the People</a>; through to multi-million dollar companies like <a href="http://www.copyblogger.com/">Copyblogger</a>, <a href="http://www.woothemes.com/">WooThemes</a>, and of course <a href="http://automattic.com/">Automattic</a>.</p>
<p>Praise must go as usual to the <a href="http://make.wordpress.org/">fantastic community</a> around WordPress, the singular vision of <a href="http://ma.tt/">Matt Mullenweg</a>, and the awesome power of the <a title="GNU General Public License" href="http://www.gnu.org/licenses/gpl.html">GNU GPL</a> open source license.</p>
<h2>Here&#8217;s to the next year</h2>
<p>As WordPress enters it&#8217;s <strong>eleventh</strong> year, with version 3.5.1 recently released and <a href="http://make.wordpress.org/core/">version 3.6 currently in the making</a>, I predict it will be another great year for <a title="Personal Publishing Platform" href="http://wordpress.org">WordPress</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2013/01/25/wordpress-a-10-year-journey/">WordPress &#8211; A 10 year journey</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Mike Little: WordCamp Edinburgh UK 2012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1856";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:145:"http://journalized.zed1.com/archives/2012/05/29/wordcamp-edinburgh-uk-2012/?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-edinburgh-uk-2012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1650:"<p><a href="http://journalized.zed1.com/wp-content/uploads/2012/05/wordcamp-edinburgh-header-1.png"><img class="aligncenter size-full wp-image-1857" title="wordcamp-edinburgh-header-1" src="http://journalized.zed1.com/wp-content/uploads/2012/05/wordcamp-edinburgh-header-1.png" alt="" width="855" height="330" /></a></p>
<p>Folks, if you are looking to attend WordCamp Edinburgh UK 2012, on the weekend of the 14th and 15th of July, you need to get your <a href="http://2012.edinburgh.wordcamp.org/tickets/">tickets</a> pretty soon to qualify for the early bird price (£35).</p>
<p>After midday this coming Friday (June 1st) the price will rise to £45. Mind you, that&#8217;s still a fantastic price for a <a href="http://2012.edinburgh.wordcamp.org/"><strong>two-day weekend</strong> filled with WordPressy goodness</a> .</p>
<p>I&#8217;ll be there of course, will you? It&#8217;s looking like a cracker with some <a href="http://wiki.wpuk.org/2012_content_ideas">great ideas for sessions already put forward</a>. I&#8217;ll be running an extended session called <a href="http://2012.edinburgh.wordcamp.org/session/starting-out-with-wordpress/">Starting Out with WordPress</a>. Once again, get your <a href="http://2012.edinburgh.wordcamp.org/tickets/">tickets</a> soon.</p>
<p>I look forward to seeing you there.</p>
<p><a href="http://wpuk.org/">WPUK</a> is organising this event.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/05/29/wordcamp-edinburgh-uk-2012/">WordCamp Edinburgh UK 2012</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Mike Little: WordPress is Nine. Happy Birthday WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1852";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:177:"http://journalized.zed1.com/archives/2012/05/27/wordpress-is-nine-happy-birthday-wordpress/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-is-nine-happy-birthday-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1387:"<p>Today is the ninth birthday of WordPress (the anniversary of the <a href="http://wordpress.org/news/2003/05/wordpress-now-available/">first release</a>).</p>
<p>WordPress still continues to astonish me in its phenomenal growth. Comparing to <a href="http://journalized.zed1.com/archives/2011/05/27/wordpress-eighth-birthday/">this time last year</a>, WordPress now powers <a href="http://en.wordpress.com/stats/">more than 74 million sites</a>, accounting for <a href="http://w3techs.com/technologies/overview/content_management/all">more than 16% of the internet</a>.</p>
<div>I&#8217;m looking forward to the next year in the world of WordPress. As usual there are lots of exciting things ahead. The first <a href="http://wpappstore.com/">WordPress App Store</a> launched recently, and I&#8217;m sure there will be more (it looks like <a href="http://z1.tl/wpmudevdashboard">WPMU Dev&#8217;s updater/dashboard</a> now lets you buy).</div>
<div></div>
<div>WordPress is really maturing and as a platform and as an industry. There is much more to come and I can&#8217;t wait.</div>
<div></div>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/05/27/wordpress-is-nine-happy-birthday-wordpress/">WordPress is Nine. Happy Birthday WordPress!</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Mike Little: WordPress 3 for Business Bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1847";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:159:"http://journalized.zed1.com/archives/2012/03/11/wordpress-3-for-business-bloggers/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-for-business-bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1071:"<p>I&#8217;m currently reading <a href="http://www.packtpub.com/wordpress-3-for-business-bloggers/book">WordPress 3 for Business Bloggers</a><a href="http://www.packtpub.com/wordpress-3-for-business-bloggers/book"><img class="alignright" title="WordPress 3 for Business Bloggers" src="https://www.packtpub.com/sites/default/files/imagecache/productview/1322OS_WordPress%203%20for%20Business%20Bloggers_Frontcover.jpg" alt="" width="124" height="152" /></a> by Paul Thewlis. I&#8217;m trying to squeeze it in between all the other stuff I seem to have on my plate. I read the first edition of the book a couple of years ago (though I can&#8217;t find my review to point to); so I&#8217;m looking forward to this one.</p>
<p>I&#8217;ll post a proper review when I&#8217;ve finished it.</p>
<p>&nbsp;</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/03/11/wordpress-3-for-business-bloggers/">WordPress 3 for Business Bloggers</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Mike Little: WordPress – 9 years since it’s conception";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1836";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:169:"http://journalized.zed1.com/archives/2012/01/25/wordpress-9-years-since-its-conception/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-9-years-since-its-conception";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2138:"<p>Simon D <a title="Simon\'s tweet" href="https://twitter.com/#!/simond/status/162125708506832896">reminded me</a> that it is now nine years since my fateful <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">comment on Matt&#8217;s blog </a>that kicked off this whole WordPress thing!</p>
<blockquote class="twitter-tweet" width="550"><p>Nine years ago today @<a href="https://twitter.com/mikelittlezed1">mikelittlezed1</a> floated an idea which eventually became WordPress. <a href="https://twitter.com/search/%23thanksmike">#thanksmike</a> <a href="http://t.co/teYbVHX8" title="http://ma.tt/2003/01/the-blogging-software-dilemma/">ma.tt/2003/01/the-bl…</a></p>
<p>&mdash; Simon Dickson (@simond) <a href="https://twitter.com/simond/status/162125708506832896">January 25, 2012</a></p></blockquote>
<p></p>
<p>WordPress is really shaping up, and is an evermore stable and functional CMS platform. The statistics continue to astonish me, with more than <a href="http://en.wordpress.com/stats/">70 million sites</a> around the world. That&#8217;s nearly <a href="http://w3techs.com/technologies/overview/content_management/all">16% of the web</a>!</p>
<p>WordPress is supporting a whole industry of WordPress experts, including me: I&#8217;m just starting my fourth year as an <a href="http://zed1.com/">independent WordPress specialist</a>.</p>
<p>Praise must go as usual to the fantastic community around WordPress, the singular vision of <a href="http://ma.tt/">Matt Mullenweg</a>, and the awesome power of the <a title="GNU General Public License" href="http://www.gnu.org/licenses/gpl.html">GNU GPL</a> open source license.</p>
<p>With version 3.4 currently in the making, I predict it will be another great year for <a title="Personal Publishing Platform" href="http://wordpress.org">WordPress</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2012/01/25/wordpress-9-years-since-its-conception/">WordPress &#8211; 9 years since it&#8217;s conception</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Mike Little: WordPress’ Eighth Birthday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1813";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:143:"http://journalized.zed1.com/archives/2011/05/27/wordpress-eighth-birthday/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-eighth-birthday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1737:"<p>Today is WordPress&#8217; official eighth birthday (the anniversary of the <a href="http://wordpress.org/news/2003/05/wordpress-now-available/">first release</a>).</p>
<p>I still marvel at the incredible distance it has come. I&#8217;m also still proud that I had a part in its birth. But even more, I marvel at the wonderful contribution of all the WordPress community make to this fantastic project.</p>
<p>A client said to me this morning &#8220;This WordPress is brilliant isn&#8217;t it?&#8221; As I helped him set up his fourth WordPress site. You can&#8217;t get much clearer praise than that.</p>
<p>So raise a virtual beer (or other non-alcoholic beverage if, like me, you are teetotal) to WordPress, the community, and to another year.</p>
<p><strong>Update:</strong> I just spotted this tweet from <a href="http://twitter.com/#!/nacin">Andrew Nacin</a>:</p>
<blockquote class="twitter-tweet" width="550"><p>At more than 20 million WordPress.com blogs, that puts WordPress at north of 45 million sites. Wowza. Happy birthday indeed.</p>
<p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/status/74139775761793024">May 27, 2011</a></p></blockquote>
<p></p>
<p>Wow! 25 million <a href="http://wordpress.org/">standalone WordPress</a> sites plus 20 million <a href="http://WordPress.com">WordPress.com</a> sites! No wonder it <a href="http://w3techs.com/technologies/overview/content_management/all">powers more than 14 percent of the web</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2011/05/27/wordpress-eighth-birthday/">WordPress&#8217; Eighth Birthday</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Mike Little: WordPress – 8 Years in the making";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1748";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:155:"http://journalized.zed1.com/archives/2011/01/27/wordpress-8-years-in-the-making/?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-8-years-in-the-making";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2038:"<p>Wow! Another year has passed and it is now eight years since my fateful <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">comment on Matt&#8217;s blog </a>that kicked off this whole WordPress thing!</p>
<p>WordPress is now a mature CMS platform driving <a href="http://w3techs.com/technologies/overview/content_management/all">13% of the web</a>! It is used for an <a href="http://wordpress.org/showcase/">astonishing array</a> of very different web sites around the world, from the humblest one person blog to <a title="I\'m a Scientist, Get me out of here!" href="http://imascientist.org.uk/">award-winning education sites</a>, <a title="The New Adventures of Stephen Fry" href="http://www.stephenfry.com/">celebrity sites</a>, <a title="The New York Times blogs" href="http://www.nytimes.com/interactive/blogs/directory.html">newspapers</a>, and even <a title="The official site of the Prime Minister\'s Office" href="http://www.number10.gov.uk">world leaders</a>!</p>
<p>WordPress is supporting a whole industry of <a title="WordPress consultants" href="http://codepoet.com/">WordPress experts</a>, including me: I&#8217;m now in my third year as an <a href="http://zed1.com/">independent WordPress specialist</a>.</p>
<p>I believe that WordPress has achieved this massive success in no small way because of the fantastic community around it, the keen-eyed vision of <a href="http://ma.tt/">Matt Mullenweg</a>, and the awesome power of the <a title="GNU General Public License" href="http://www.gnu.org/licenses/gpl.html">GNU GPL</a> open source license.</p>
<p>With version 3.1 just around the corner, I predict it will be another great year for <a title="Personal Publishing Platform" href="http://wordpress.org">WordPress</a>.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2011/01/27/wordpress-8-years-in-the-making/">WordPress &#8211; 8 Years in the making</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Mike Little: WordCamp slides featured on Slideshare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1523";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:169:"http://journalized.zed1.com/archives/2010/07/21/wordcamp-slides-featured-on-slideshare/?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-slides-featured-on-slideshare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1285:"<p>The slides from <a href="http://www.slideshare.net/mikelittle/wordcamp-2010-im-a-scientist-get-me-out-of-here-mike-little">my presentation at WordCamp UK</a> in Manchester over the weekend are now on SlideShare. I presented on the fantastic <a href="http://imascientist.org.uk/">I&#8217;m a Scientist Get me Out of Here</a> project website I have built for <a href="http://www.gallomanor.com/">Gallomanor</a> this year.</p>
<p>It&#8217;s best to read the notes in the &#8220;Notes on slide x&#8221; tab so that everything makes sense! I also link to some of the plugins I used at the end.</p>
<p>Amazingly, the presentation features on the <a href="http://www.slideshare.net/">SlideShare home page</a> today along with a couple of other presentations from <a href="http://uk.wordcamp.org/">WordCamp UK</a>! See the &#8220;featured&#8221; section in the right hand column. Woo Hoo!</p>
<p>I have still to finish my write-up of the weekend, but will hopefully get that done &#8216;real soon&#8217;.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2010/07/21/wordcamp-slides-featured-on-slideshare/">WordCamp slides featured on Slideshare</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"Mike Little: WordCamp UK A Few Places Left";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://journalized.zed1.com/?p=1519";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:153:"http://journalized.zed1.com/archives/2010/07/15/wordcamp-uk-a-few-tickets-left/?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-uk-a-few-tickets-left";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1313:"<p>For those of you thinking you may have missed out on this coming weekend&#8217;s WordPress fun at <a href="http://uk.wordcamp.org/">WordCamp UK</a> in Manchester, think again!</p>
<p>As the tickets did not completely sell out, we are making the last few available on the door, as we did last year.</p>
<p>You must email me (mike at my domain ) to reserve a ticket, and then turn up on Saturday morning with your £30 cash.</p>
<p>To recap, WordCamp UK is this weekend, July 17th and 18th, at the <a href="http://www.business.mmu.ac.uk/">Manchester Metropolitan University Business School</a> which is in Manchester city centre, a few minutes walk from the main Piccadilly train Station.</p>
<p>There are <a href="http://wiki.wordcampuk.tonyscott.org.uk/2010_running_order">four simultaneous tracks</a> : General &amp; user, Specialist &amp; developer, Miscellaneous &amp; spontaneous and a &#8216;Genius Bar&#8217; (a range of WordPress experts available to advice attendees on a one-to-one basis).</p>
<p>I look forward to seeing you there.</p>
<p>The post <a rel="nofollow" href="http://journalized.zed1.com/archives/2010/07/15/wordcamp-uk-a-few-tickets-left/">WordCamp UK A Few Places Left</a> appeared first on <a rel="nofollow" href="http://journalized.zed1.com">Mike Little&#039;s Journalized</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 23:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Mike Little";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WordPress Projects Announced for Google Summer of Code 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21492";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/wordpress-projects-announced-for-google-summer-of-code-2014?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-projects-announced-for-google-summer-of-code-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2585:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/gsoc2014.png" rel="prettyphoto[21492]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/04/gsoc2014.png?resize=924%2C156" alt="gsoc2014" class="aligncenter size-full wp-image-21501" /></a></p>
<p>Earlier this year, WordPress was <a href="http://wptavern.com/wordpress-accepted-as-a-mentoring-organization-for-google-summer-of-code-2014" target="_blank">accepted</a> as one of 190 mentoring organizations for <a href="http://www.google-melange.com/gsoc/homepage/google/gsoc2014" target="_blank">Google Summer of Code 2014</a>. This year marks the 10th annual GSoC and WordPress&#8217; 7th year participating in the program. Five students have been <a href="http://make.wordpress.org/community/2014/04/21/gsoc-students-accepted/" target="_blank">accepted</a> and will soon begin work on some exciting projects:</p>
<ul>
<li><a href="http://profiles.wordpress.org/secretmapper" target="_blank">Arian Allenson M. Valdez</a> — Working on GlotPress UI and profiles with Yoav Farhi and Marko Heijnen as mentors</li>
<li><a href="http://profiles.wordpress.org/gautamgupta" target="_blank">Gautam Gupta</a> — Working on bbPress improvements with John James Jacoby and Stephen Edgar as mentors</li>
<li><a href="http://profiles.wordpress.org/avryl" target="_blank">Janneke Van Dorpe</a> — Working on front-end editing/content blocks with Gregory Cornelius and Aaron Jorbin as mentors</li>
<li><a href="http://profiles.wordpress.org/celloexpressions" target="_blank">Nick Halsey</a> — Working on adding custom menus to the customizer with Erick Hitter and Konstantin Obenland as mentors</li>
<li><a href="http://profiles.wordpress.org/VarunAgw" target="_blank">Varun Agrawal</a> — Working on SupportPress as a plugin with Ian Dunn, Aaron Campbell, and Alex Mills as mentors</li>
</ul>
<p>The students selected to participate are all very talented and enthusiastic. In fact, several of them are already active in contributing to WordPress core and have several plugins hosted in the directory.</p>
<p>GSoC 2014 kicks off May 19th when the students will begin their summer coding adventures. In the meantime, they will be bonding with their mentoring teams and working to nail down the scope of their projects. Jen Mylo, who is coordinating WordPress&#8217; involvement in the GSoC, will be working with the teams to set up some livestreamed prototype demos at midterm. Students will also be posting on a weekly basis and we&#8217;ll be following the progress on their projects throughout the summer.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 20:15:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: 13 Vagrant Resources for WordPress Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21194";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:156:"http://wptavern.com/13-vagrant-resources-for-wordpress-development?utm_source=rss&utm_medium=rss&utm_campaign=13-vagrant-resources-for-wordpress-development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8683:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/vagrant.png" rel="prettyphoto[21194]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/04/vagrant.png?resize=1025%2C463" alt="vagrant" class="aligncenter size-full wp-image-21435" /></a></p>
<p><a href="http://www.vagrantup.com/" target="_blank">Vagrant</a> is an open source tool that makes it easy to configure and distribute virtual development environments. The project was started in 2010 by Mitchell Hashimoto and John Bender who wanted to create a way to standardize development environments for teams. Vagrant was designed to put an end to the &#8220;works on my machine&#8221; frustration that often surfaces when teams develop on different environments.</p>
<p>Because it&#8217;s so lightweight and portable, many WordPress developers have adopted Vagrant for development, which has resulted in different tools and configurations for various project needs. We&#8217;ve collected a few WordPress-related Vagrant resources here that will help you get started.</p>
<h3>Varying Vagrant Vagrants</h3>
<p><a href="https://github.com/Varying-Vagrant-Vagrants/VVV" target="_blank">Varying Vagrant Vagrants</a> is one of the most widely used and best-supported Vagrant configurations for WordPress development. Originally created by the folks at <a href="http://10up.com/" target="_blank">10up</a>, the open source VVV project <a href="http://10up.com/blog/varying-vagrant-vagrants-future/" target="_blank">became a community organization</a> earlier this year. The company still contributes to its development and maintenance, helping to make it one of the most stable options for setting up a Vagrant-based WordPress development environment. VVV provides a comprehensive configuration for developing themes and plugins as well as for contributing to WordPress core.</p>
<h3>VVV Site Wizard</h3>
<p>If you&#8217;re a VVV user who is often creating and removing sites, then the <a href="https://github.com/aliso/vvv-site-wizard" target="_blank">VVV Site Wizard</a> may be able to save you some time. It completely automates the creation of new sites as well as the teardown of old ones.</p>
<h3>WordPress Theme Review VVV</h3>
<p>If you&#8217;re a VVV user who spends quite a bit of time developing WordPress themes, this is a quick Vagrant setup that adds all the necessary tools for reviewing themes. <a href="https://github.com/aubreypwd/wordpress-themereview-vvv" target="_blank">WordPress Theme Review VVV</a> creates a fresh WordPress site, installs and activates the Developer and Theme-Check plugins, and imports the Theme Unit Test data. Check out our <a href="http://wptavern.com/wordpress-theme-review-vvv-a-quick-vagrant-setup-for-testing-and-reviewing-themes" target="_blank">tutorial</a> for a quick walkthrough on setting it set up.</p>
<h3>Primary Vagrant</h3>
<p><a href="https://github.com/ChrisWiegman/Primary-Vagrant" target="_blank">Primary Vagrant</a> is a configuration created by Chris Wiegman. It&#8217;s similar to VVV but with a few important differences: it uses Apache instead of NGINX and Puppet instead of Bash. Wiegman used VVV and Puppet as a base for a new Vagrant configuration for WordPress plugin or theme development. Primary Vagrant supports Apache and MySQL on Ubuntu and allows for use of different major PHP versions (currently 5.3 – 5.5), which can be easily changed with one line of code.</p>
<h3>VagrantPress</h3>
<p><a href="https://github.com/chad-thompson/vagrantpress" target="_blank">VagrantPress</a> is a simple configuration that sets up a WordPress development environment using Apache with Vagrant/Puppet. It&#8217;s geared toward developing themes and plugins. VagrantPress currently does not allow for multiple installations but Chat Thompson, the project&#8217;s creator, <a href="http://wptavern.com/vagrantpress-a-wordpress-development-environment-for-themes-and-plugins#comment-53714" target="_blank">plans to add more features</a> related to automating the provisioning and maintenance of multiple WordPress installations.</p>
<h3>Chassis</h3>
<p><a href="https://github.com/Chassis/Chassis" target="_blank">Chassis</a> uses Vagrant and Puppet to create a development environment running Ubuntu, Ngnix, PHP 5.4, Imagick, MySQL, Xdebug, WP-CLI, and WordPress, a setup which more closely matches many managed WP hosting environments. Chassis makes it easy to add additional testing domains via a YAML configuration file. It also has support for WordPress multisite, which can be enabled in config.local.yaml or the project configuration file.</p>
<h3>WordPress and Vagrant Google Group</h3>
<p><a href="https://groups.google.com/forum/#!forum/wordpress-and-vagrant" target="_blank">WordPress and Vagrant</a> is a public Google group that you can join to post basic or advanced questions about using Vagrant for development. This can be a helpful resource for troubleshooting some unique issues concerning Vagrant-based WordPress development environments. Most of the threads seem to be about working with VVV, but the group isn&#8217;t specifically limited.</p>
<h3>WordPress Vagrant Boxes</h3>
<p><a href="https://github.com/tierra/wp-vagrant" target="_blank">WordPress Vagrant Boxes</a> is a Vagrant configuration that uses Apache. Although the web server is preconfigured to look for WordPress in a specific location, WordPress Vagrant Boxes is unique in that it doesn&#8217;t checkout or install WordPress at all. It&#8217;s up to you to unpack and install a WordPress ZIP, checkout from SVN, or clone from git.</p>
<h3>VCCW (vagrant-chef-centos-wordpress)</h3>
<p><a href="https://github.com/miya0001/vagrant-chef-centos-wordpress" target="_blank">VCCW</a> (Vagrant + Chef + CentOS + WordPress) was configured for those developing WordPress plugins, themes or websites. It includes 17 customizable constants for setting the WordPress version (or beta release), language, hostname, subdirectory, admin credentials, default plugins, default theme, multisite, SSL and other options. These constants give you a lot of flexibility in tailoring your development environment to your specific needs.</p>
<h3>Throwaway WordPress VMs with Vagrant and Ansible</h3>
<p><a href="https://github.com/jalefkowit/vagrant-ansible-wordpress" target="_blank">Throwaway WordPress VMs</a> uses Vagrant and <a href="http://www.ansible.com/home" target="_blank">Ansible</a> to automate the process of creating and provisioning local virtual machines for WordPress development. The scripts were designed for use with Ubuntu, but you can select any version of Ubuntu you wish to use, or a base box from <a href="http://www.vagrantbox.es/" target="_blank">vagrantbox.es</a>.</p>
<h3>WordPress Machine</h3>
<p><a href="https://github.com/audionerd/wordpress-machine" target="_blank">WordPress Machine</a> sets up WordPress on a LAMP stack. It also includes Composer, <a href="http://wp-cli.org/" target="_blank">WP-CLI</a>, and <a href="http://forge.thethemefoundry.com/" target="_blank">Forge</a> for WordPress theme setup and asset compilation (SCSS, CoffeeScript). This configuration runs <a href="http://ajk.fi/2013/wordpress-as-a-submodule/" target="_blank">WordPress as a submodule</a> using <a href="https://github.com/Darep/wordpress-boilerplate" target="_blank">WordPress Boilerplate</a>, which means that themes, plugins and uploads are separated from the WordPress installation so that WP can be easily updated as a git submodule.</p>
<h3>Monkey Rocket</h3>
<p>The developer who created <a href="https://github.com/Cikica/monkeyrocket" target="_blank">Monkey Rocket</a> used much of the code from VVV, which he found installed more things than he needed for a simple development environment. This Vagrant configuration is basically a stripped down version of VVV that will set you up with the latest stable version of WordPress at local.wordpress.dev on your machine.</p>
<h3>WordPress Kickstart</h3>
<p><a href="https://github.com/jnettome/wordpress_kickstart" target="_blank">WordPress Kickstart</a> is a Vagrant development environment provisioned by Puppet. It was created for use with production stacks that are hosted on <a href="https://www.digitalocean.com/" target="_blank">DigitalOcean</a>. Once you enter your DigitalOcean API credentials into the vagrantfile, you&#8217;ll have a command available for working on production deployment and provisioning. This command allows you to create a new droplet, setup your SSH key for authentication, create a new user account, and run the provisioners configured. You can easily switch back and forth from production to development by removing .vagrant/ from your project&#8217;s root folder.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Apr 2014 14:19:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: WPWeekly Episode 146 – WordPress 3.9 With Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=21420&preview_id=21420";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/wpweekly-episode-146-wordpress-3-9-with-andrew-nacin?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-146-wordpress-3-9-with-andrew-nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2175:"<p>In this weeks edition of WordPress Weekly, we discussed several topics with WordPress lead developer <a href="http://nacin.com/" title="http://nacin.com/">Andrew Nacin</a>. Ever since the release of WordPress 3.7, many have questioned why auto updates are turned on by default for minor and security updates. Nacin described the philosophy behind the auto update system and why the team will be sticking with its current implementation.</p>
<p>We also learned the details behind the release of a major security update to Jetpack. Last but not least, Nacin describes what it was like to lead the release of 3.9 and what he&#8217;ll be focusing on now that he won&#8217;t be leading a release cycle.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-3-9-smith-released" title="http://wptavern.com/wordpress-3-9-smith-released">WordPress 3.9 “Smith” Released</a><br />
<a href="http://wptavern.com/wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word" title="http://wptavern.com/wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word">WordPress 3.9 Has Built-In Support for Pasting from Microsoft Word</a><br />
<a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" title="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools">BuddyPress 2.0 Released: Big Performance Improvements and New Administration Tools</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, April 25th 3 P.M. Eastern &#8211; Special Guest &#8211; Japh</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #146:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 19 Apr 2014 14:29:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Andrew: Customizing TinyMCE 4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"http://azaozz.wordpress.com/?p=380";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://azaozz.wordpress.com/2014/04/19/customizing-tinymce-4-0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2358:"<p>Many of the TinyMCE settings have changed in version 4.0. There is a new default theme: Modern, and all the UI settings for the former Advanced theme (<code>theme_advanced...)</code> are deprecated.</p>
<p>One often used setting was <code>theme_advanced_blockformats</code><strong><code>.</code></strong> It was renamed to <code>block_formats</code> and keeps the same formatting. To specify a different set of elements for the &#8216;blockformats&#8217; drop-down (second toolbar row in the WordPress Visual editor), you can set a string of name=value pairs separated by a semicolon in the initialization object:</p>
<pre class="brush: jscript; title: ; notranslate">block_formats: "Paragraph=p;Heading 1=h1;Heading 2=h2;Heading 3=h3"</pre>
<p>Another handy setting: <code>theme_advanced_styles</code> doesn&#8217;t exist any more. However there is a more powerful version: <code>style_formats</code>. Now it can replace or add items to the new &#8220;Formats&#8221; menu.The value is an array of objects each containing a name that is displayed as sub-menu and several settings: a CSS class name or an inline style, and optionally the wrapper element where the class or inline style will be set:</p>
<pre class="brush: jscript; title: ; notranslate">
toolbar3: \'styleselect\',
style_formats_merge: true,
style_formats: { name: \'Custom styles\', [
  {title: \'Red bold text\', inline: \'b\', styles: {color: \'#ff0000\'}},
  {title: \'Red text\', inline: \'span\', styles: {color: \'#ff0000\'}},
  {title: \'Red header\', block: \'h1\', styles: {color: \'#ff0000\'}},
  {title: \'Example 1\', inline: \'span\', classes: \'example1\'},
  {title: \'Example 2\', inline: \'span\', classes: \'example2\'}
]}
</pre>
<p>The above code will add another sub-menu to &#8220;Formats&#8221; without replacing the default menu items. There is <a href="http://www.tinymce.com/wiki.php/Configuration:style_formats">more information</a> and an <a href="http://www.tinymce.com/tryit/custom_formats.php">example</a> on the TinyMCE website.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/azaozz.wordpress.com/380/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/azaozz.wordpress.com/380/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=azaozz.wordpress.com&blog=3380945&post=380&subd=azaozz&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 19 Apr 2014 07:04:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: Quotable: Highlight and Share WordPress Posts on Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:174:"http://wptavern.com/quotable-highlight-and-share-wordpress-posts-on-twitter?utm_source=rss&utm_medium=rss&utm_campaign=quotable-highlight-and-share-wordpress-posts-on-twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3084:"<p><a href="http://wptavern.com/wp-content/uploads/2014/04/quotable.png" rel="prettyphoto[21400]"><img src="http://wptavern.com/wp-content/uploads/2014/04/quotable.png" alt="quotable" width="772" height="250" class="aligncenter size-full wp-image-21403" /></a></p>
<p>Readers may not always identify with the title that you&#8217;ve chosen for your posts but they may find a gem within your article that is more &#8220;quotable&#8221; and worth sharing. <a href="http://wordpress.org/plugins/quotable/" target="_blank">Quotable</a> is a new WordPress plugin that capitalizes on this, allowing readers to highlight any text within your content to quote the article on Twitter.</p>
<p>The plugin, developed by <a href="http://josiahsprague.com/" target="_blank">Josiah Sprague</a>, was partially inspired by the toolbar on Medium.com that enables visitors to tweet or comment on the text they select. Sprague said that he created it out of his love for both WordPress and Twitter:</p>
<blockquote><p> I love how both platforms make it easy for people to share ideas and communicate openly and freely. I love that both serve as a sort of “public square” of the web and support discourse, democracy and free society.</p></blockquote>
<p>Quotable adds a tiny Twitter icon to the end of blockquotes for quick sharing.  It also works with text highlighting. Readers will often instinctively highlight text that they agree with or are wanting to share. When they do, they&#8217;ll naturally discover that it&#8217;s easy to share.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/quotable2.png" rel="prettyphoto[21400]"><img src="http://wptavern.com/wp-content/uploads/2014/04/quotable2.png" alt="quotable2" width="916" height="458" class="aligncenter size-full wp-image-21405" /></a></p>
<p>When you click the Twitter bird, a tweet modal will automatically launch with the quoted text inserted. Quotable also integrates with Twitter accounts configured via Yoast&#8217;s WordPress SEO, which allows you to include Twitter mentions for post authors and suggest following the website&#8217;s Twitter account.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/quotable-1.png" rel="prettyphoto[21400]"><img src="http://wptavern.com/wp-content/uploads/2014/04/quotable-1.png" alt="quotable-1" width="1400" height="1360" class="aligncenter size-full wp-image-21404" /></a></p>
<p>Let&#8217;s face it &#8211; the comments section of your post is not always the locus of the conversation sparked by your blog. Even if your post is the origin of a hotly debated topic, the conversation often moves to Twitter, and that&#8217;s OK. This plugin helps you to be ready to follow the conversation wherever it goes, especially if you configure it to automatically mention you, the post author, when a quote gets tweeted.</p>
<p>I tested Quotable with WordPress 3.9 and found that it works as advertised and fits naturally into any theme without being obtrusive. <a href="http://wordpress.org/plugins/quotable/" target="_blank">Download</a> it for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 23:10:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Akismet: New in 3.0: Activation with Jetpack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1308";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.akismet.com/2014/04/18/activation-with-jetpack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2091:"<p>We launched <a href="http://blog.akismet.com/2014/04/15/akismet-3-0-0/" title="Akismet 3.0.0 is Now Available">Akismet 3.0</a> just a few days ago and hope that you&#8217;ve already upgraded to enjoy its many new features. One of the nifty items we added to the mix is a seamless activation process using the popular <a href="http://wordpress.org/plugins/jetpack/" title="Jetpack by WordPress.com">Jetpack</a> plugin.</p>
<p>Let&#8217;s take a closer look.</p>
<p>If you have Jetpack and Akismet installed and activated on your site &#8211; and the Jetpack plugin connected to a <a href="http://wordpress.com" title="WordPress.com">WordPress.com</a> account &#8211; you will find this new feature in your dashboard via <strong>Jetpack &#8594; Akismet</strong>.</p>
<p>There, you will see which WordPress.com account is connected via Jetpack and an option to activate the Akismet plugin using that very same account.</p>
<p><a href="http://akismet.files.wordpress.com/2014/04/akismet-activation-with-jetpack.png"><img src="http://akismet.files.wordpress.com/2014/04/akismet-activation-with-jetpack.png?w=640&h=263" alt="Akismet Activation with Jetpack" class="alignnone size-large wp-image-1348" /></a></p>
<p>Click on <strong>Use this Akismet account</strong>, and you&#8217;re all set! Of course, you will have the option to disconnect the account at any time from the same page in your dashboard.</p>
<p>And if you want to use a different account to activate Akismet, no worries at all. Simply select the option to register a different email address or manually enter an existing API key.</p>
<p>Digging the new flow? Any problems with it? <a href="http://akismet.com/contact/" title="Contact Akismet">Drop us a line</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1308/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1308/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1308&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 19:40:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WordPress 3.9 Has Built-in Support for Pasting from Microsoft Word";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21366";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-9-has-built-in-support-for-pasting-from-microsoft-word";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2744:"<div id="attachment_21384" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/paste.png" rel="prettyphoto[21366]"><img src="http://wptavern.com/wp-content/uploads/2014/04/paste.png" alt="photo credit: This Year\'s Love - cc" width="900" height="401" class="size-full wp-image-21384" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/hand-nor-glove/1481913840/">This Year&#8217;s Love</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>A common support question that&#8217;s been popping up on the web after WordPress users update to 3.9: <strong>What happened to the &#8220;Paste from Word&#8221; button in the visual editor?</strong> If you find that the button is missing, don&#8217;t worry &#8211; it&#8217;s not a bug.  Prior to this update, the button was located in the kitchen sink of the visual editor:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/paste-from-word.png" rel="prettyphoto[21366]"><img src="http://wptavern.com/wp-content/uploads/2014/04/paste-from-word.png" alt="paste-from-word" width="622" height="233" class="aligncenter size-full wp-image-21370" /></a></p>
<p>WordPress 3.9, however, <a href="https://core.trac.wordpress.org/changeset/28089" target="_blank">removes the &#8220;paste from word&#8221; button</a> entirely. It includes <a href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/" target="_blank">TinyMCE 4.0</a> and has better built-in support for pasting in blocks of text for Microsoft Word. The better your software gets, the more the magic happens behind the scenes. WordPress now detects if the pasted text is coming from MS Word and makes the appropriate changes.</p>
<p>Until I saw the <a href="http://www.reddit.com/r/Wordpress/comments/23ah5d/copy_from_word_button_went_missing/" target="_blank">question</a> on Reddit, indicating that the button had gone missing, I had no idea that anyone still used this feature. The missing button is actually an enhancement, not a bug. Hopefully this information has reached you before you started deactivating all your plugins.</p>
<p>Unless you had been closely following the posts at <a href="http://make.wordpress.org" target="_blank">make.wordpress.org</a>, this improvement might have been easy to miss. Check out our <a href="http://wptavern.com/wordpress-3-9-smith-released" target="_blank">summary of everything that&#8217;s new in WordPress 3.9</a>. If you&#8217;re having any problems with the update, you may want to review some of the <a href="http://wptavern.com/common-issues-and-troubleshooting-wordpress-3-9" target="_blank">known issues</a> with plugins before posting in the support forums.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 17:53:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: How to Limit Activity Comment Depth in BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21347";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:162:"http://wptavern.com/how-to-limit-activity-comment-depth-in-buddypress?utm_source=rss&utm_medium=rss&utm_campaign=how-to-limit-activity-comment-depth-in-buddypress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2642:"<p>BuddyPress 2.0 was <a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" target="_blank">released</a> this week with many new administrative tools that make it easier to manage communities from the backend. One of the lesser known new features is the ability to limit comment depth in the activity stream.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/old-threaded-comments.png" rel="prettyphoto[21347]"><img src="http://wptavern.com/wp-content/uploads/2014/04/old-threaded-comments-300x258.png" alt="old-threaded-comments" width="300" height="258" class="alignright size-medium wp-image-21351" /></a>Activity threads can sometimes get out of control when it comes to replies, which results in the comments box getting progressively squished to an inconveniently small size.</p>
<p>In the past, the only way to change the comment depth was to filter the output of the bp_activity_can_comment_reply() function, but this wasn&#8217;t very user-friendly for community managers.</p>
<p>Since WordPress already has a built-in setting for comment depth, this was a natural fit for activity comments and did not require adding any new settings. BuddyPress 2.0 now <a href="https://buddypress.trac.wordpress.org/ticket/2768" target="_blank">respects WordPress&#8217; comment depth settings</a>. You can adjust them in the admin at <strong>Settings > Discussion > Other Comment Settings</strong>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/threaded-comments.png" rel="prettyphoto[21347]"><img src="http://wptavern.com/wp-content/uploads/2014/04/threaded-comments.png" alt="threaded-comments" width="1200" height="397" class="aligncenter size-full wp-image-21349" /></a></p>
<p>In the following example, threaded comments have been set to three. You&#8217;ll notice that the third comment has no reply link beneath it. Members can still comment on the activity item itself but will not be able to add more than three replies.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/activity-comments.png" rel="prettyphoto[21347]"><img src="http://wptavern.com/wp-content/uploads/2014/04/activity-comments.png" alt="activity-comments" width="900" height="680" class="aligncenter size-full wp-image-21355" /></a></p>
<p>This update shouldn&#8217;t affect the structure of your previous activity comments/replies, but it will be in effect for threaded comments moving forward. If you&#8217;ve been itching to to limit activity comment depth on your BuddyPress site, this new setting makes it easy to set a limit, without having to touch any code.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Apr 2014 06:42:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Cédric Motte : Sans contenu, WordPress n’est rien";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34325";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2014/04/17/cedric-motte-sans-contenu-wordpress-nest-rien/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:673:"<div id="v-4WgeuUC1-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34325/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34325/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34325&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/04/17/cedric-motte-sans-contenu-wordpress-nest-rien/"><img alt="13 &#8211; Cedric Motte-Conf-WCParis2014.mp4" src="http://videos.videopress.com/4WgeuUC1/video-88337de484_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 21:58:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: Automattic Publishes Transparency Report, Reaffirms Support for Freedom of Speech";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21275";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/automattic-publishes-transparency-report-reaffirms-support-for-freedom-of-speech?utm_source=rss&utm_medium=rss&utm_campaign=automattic-publishes-transparency-report-reaffirms-support-for-freedom-of-speech";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5451:"<p>Automattic was created to bring WordPress&#8217; open source publishing software to people on a larger scale. The company shares <a href="http://codex.wordpress.org/WordPress_Policies" target="_blank">WordPress&#8217; mission</a> to democratize publishing. As part of that mission, Automattic published a transparency report, which outlines the number of information requests, takedown demands, and national security requests it has received.</p>
<p>The <a href="http://transparency.automattic.com/" target="_blank">Transparency Report</a> is located on a new site which helps users to navigate what will likely become a large archive of information, as Automattic plans to publish a new report every six months. This report will keep users informed about which governments are making requests and policies for responding to them.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/transparency-report.jpg" rel="prettyphoto[21275]"><img src="http://wptavern.com/wp-content/uploads/2014/04/transparency-report.jpg" alt="transparency-report" width="1280" height="664" class="aligncenter size-full wp-image-21310" /></a></p>
<p>Writing on behalf of Automattic, Jenny Zhu <a href="http://en.blog.wordpress.com/2014/04/17/transparency-report/" target="_blank">summarized</a> the company&#8217;s policy regarding information requests:</p>
<blockquote><p>Our policy is to notify you of any information request we receive regarding your account, so that you may challenge the request. The only exception is if we are prohibited by law (not just asked nicely by the police) from making such a notification. </p></blockquote>
<h3>Automattic is Committed to Actively Pushing Back Against Requests That Violate Freedom of Speech</h3>
<p>Historically, Automattic has demonstrated its support for freedom of speech by <a href="http://en.blog.wordpress.com/2010/07/01/support-the-first-amendment-with-1-for-all/" target="_blank">raising awareness about the First Amendment</a>, even taking to the courts <a href="http://en.blog.wordpress.com/2013/11/21/striking-back-against-censorship/" target="_blank">to stand with users against DMCA abuse</a>. The company also recently joined forces with other organizations around the globe to <a href="http://wptavern.com/wordpress-com-joins-google-reddit-and-tumblr-in-protesting-nsa-surveillance" target="_blank">protest NSA surveillance</a>.</p>
<p>Through its statement today, Automattic emphasized that it will push back against requests that constitute infringements on freedom of speech:</p>
<blockquote><p>We also carefully review all legal requests we receive and actively push back on those that are procedurally deficient, overly-broad, or otherwise improper (i.e., those that target non-criminal free speech).</p></blockquote>
<h3>The US Government Represents 60% of the Information Requests</h3>
<p>Russia, not known for its support of free press, leads the way in <a href="http://transparency.automattic.com/takedown-demands/" target="_blank">takedown demands</a> with 88% of the total requests received by WordPress.com. The United States, however, far and away leads in the number of user <a href="http://transparency.automattic.com/information-requests/" target="_blank">information requests</a> from governments and law enforcement agencies from July 1 – December 31, 2013.</p>
<p>While most of the countries listed have submitted a handful of requests, the US government sent 20 requests, specifying 29 different sites. In 60% of those requests, some or all information was produced. The requests shown here do not include those related to litigation and civil proceedings.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/information-requests.jpg" rel="prettyphoto[21275]"><img src="http://wptavern.com/wp-content/uploads/2014/04/information-requests.jpg" alt="information-requests" width="753" height="736" class="aligncenter size-full wp-image-21315" /></a></p>
<p>Automattic specifies that the company will only turn over private user information upon receipt of valid US legal process. Requests that originate from outside the US are required to be served through a US court or enforcement agency.</p>
<p>The company is not permitted to disclose very much regarding national security requests, despite wishing they could:</p>
<blockquote><p>Finally, we’re reporting the maximum amount of information allowed by law about the number and type(s) of National Security Requests that we received. The disclosures we’re currently allowed to make are limited, and unfortunately, we’re not permitted to paint a more truthful picture.</p></blockquote>
<p>The <a href="http://transparency.automattic.com/" target="_blank">Transparency Report</a> makes it clear that Automattic will not tolerate censorship of its users and is committed to disclosing as much information related to government requests as they are permitted. Many governments are <a href="http://www.bloomberg.com/news/2014-04-11/nsa-said-to-have-used-heartbleed-bug-exposing-consumers.html" target="_blank">ruthless about extracting information from citizens</a>, even when it comes at the expense of the people they serve. Given that the United States leads the pack in information requests, it&#8217;s reassuring to know that WordPress.com, one of the most highly trafficked sites in the US and around the globe, is committed to standing against any request that violates users&#8217; freedom of speech.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 20:43:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: Common Issues and Troubleshooting WordPress 3.9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21274";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:158:"http://wptavern.com/common-issues-and-troubleshooting-wordpress-3-9?utm_source=rss&utm_medium=rss&utm_campaign=common-issues-and-troubleshooting-wordpress-3-9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8165:"<div id="attachment_21291" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP39Support.png" rel="prettyphoto[21274]"><img class="size-full wp-image-21291" src="http://wptavern.com/wp-content/uploads/2014/04/WP39Support.png" alt="WordPress 3.9 Featured Images" width="639" height="200" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/ironrodart/4154904299/">IronRodArt &#8211; Royce Bair (&#8220;Star Shooter&#8221;)</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>After the release of WordPress 3.9, I decided to help out in the <a title="http://wordpress.org/support/" href="http://wordpress.org/support/">support forums</a> since they usually become busy soon after a release. Providing support in the WordPress.org forums gives you a clear indication on how well a release is being received and whether or not anything major broke. After spending five hours in the support forum, here are some common issues being reported by users.</p>
<h3>Visual Editor Disappeared Or Is Broken</h3>
<p>A lot of users are <a title="http://wordpress.org/tags/visual-editor" href="http://wordpress.org/tags/visual-editor">reporting that the visual editor</a> has either disappeared or is broken. Considering the <a title="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/" href="http://make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">number</a> of changes that took place with TinyMCE in 3.9, this is not surprising. In most cases, having users go through the following process solved the problem.</p>
<ol>
<li>Deactivate ALL plugins.</li>
<li>Switch to default TwentyFourteen theme.</li>
<li>Manually empty browser cache.</li>
</ol>
<p>If the visual editor doesn&#8217;t work after disabling all plugins and switching to the default theme, there could be a JavaScript issue. Follow <a title="http://codex.wordpress.org/Using_Your_Browser_to_Diagnose_JavaScript_Errors" href="http://codex.wordpress.org/Using_Your_Browser_to_Diagnose_JavaScript_Errors">these instructions</a> to diagnose JavaScript errors in your browser. Then, open up a new support forum thread and make sure to add the following information:</p>
<ul>
<li>the browsers that you are experiencing the problem in</li>
<li>whether SCRIPT_DEBUG fixed the error or not</li>
<li>the JavaScript error</li>
<li>the location of the error &#8211; both the file name and the line number</li>
<li>the context of the error &#8211; including the whole error stack will help developers</li>
</ul>
<p>This detailed information will help volunteer moderators determine the best way to solve your problem.</p>
<h3>Master List Of Known Issues</h3>
<p>Themes and plugins confirmed to be the cause of the problem are documented and added to the <a title="http://wordpress.org/support/topic/wordpress-39-master-list?replies=4" href="http://wordpress.org/support/topic/wordpress-39-master-list?replies=4">master list</a> of known issues with WordPress 3.9. So far, the list of plugins is up to eight with at least one in the process of being fixed.</p>
<ul>
<li><a href="http://wordpress.org/plugins/wysija-newsletters/">MailPoet Newsletters</a> &#8211; Issue with <a href="https://wordpress.org/support/topic/39-update-tinymce-disappeared?replies=6#post-5465005">outdated TinyMCE plugin in version 2.6.3</a>, disabling plugin fixed Visual Editor problem. MailPoet is already working on a fix for the TinyMCE issue in the next versions 2.6.4 (for post editor screen) and 2.6.5 (for newsletter editor).</li>
<li><a href="https://wordpress.org/plugins/ziplist-recipe-plugin/">ZipList Recipe Plugin</a> &#8211; Version 2.2 has a problem with the post editor in <a href="https://wordpress.org/support/topic/plugin-causes-posts-to-not-be-editable?replies=2">both Visual and Text mode</a>.</li>
<li><a href="http://wordpress.org/plugins/zedity/">Zedity</a> &#8211; Version 3.1.0 causes the Visual Editor to break.</li>
<li><a href="https://wordpress.org/plugins/enhanced-media-library/">Enhanced Media Library</a> &#8211; Version 1.0.4 doesn&#8217;t show any media in the media library when the Add Media button is clicked</li>
<li><a href="http://wordpress.org/plugins/soundcloud-is-gold/">SoundCloud Is Gold</a> &#8211; Version 2.2.1 disables the Visual editor and prevents text from being entered</li>
<li><a href="https://wordpress.org/plugins/nofollow/">Ultimate NoFollow</a> &#8211; Version 1.4.1 doesn&#8217;t allow links to be inserted in the visual editor</li>
<li><a href="https://wordpress.org/plugins/many-tips-together/">Admin Tweaks</a> &#8211; version 2.3.8 causes the visual editor to white out.</li>
<li><a href="http://wordpress.org/plugins/qtranslate/">Qtranslate</a> &#8211; version 2.5.39 causes the media uploaded not to function</li>
</ul>
<p>The support team tries their best to help everyone with any WordPress problem even if it&#8217;s for a commercial theme or plugin. However, due to the great variety of existing themes and plugins it is nearly impossible to know everything. Your best option is to contact the developer for support. It’s always best to go to where the theme/plugin is officially supported when trying to get support.</p>
<h3>How To Create An Audio Playlist</h3>
<p>A few users have asked where the link is to create an audio playlist. In order to see the link to create an audio playlist, you either need existing audio files within the media library or you need to add them. It&#8217;s worth noting that if you host your media files on a content delivery network that&#8217;s not synchronized with the WordPress media library, you won&#8217;t be able to take advantage of the playlist feature.</p>
<h3>Easy Way To Add Borders and Padding To Images Removed</h3>
<p>Although WordPress 3.9 has refined the media editing experience, it did so at the cost of removing a feature users appreciated. In WordPress 3.8, users could easily add a border, vertical, and horizontal padding to images. WordPress 3.9 has removed this from the advanced image settings screen.</p>
<div id="attachment_21279" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP38ImageProperties.png" rel="prettyphoto[21274]"><img class="size-full wp-image-21279" src="http://wptavern.com/wp-content/uploads/2014/04/WP38ImageProperties.png" alt="Image Properties In WordPress 3.8" width="620" height="476" /></a><p class="wp-caption-text">Image Properties In WordPress 3.8</p></div>
<p>It&#8217;s not just those who use the self-hosted version of WordPress that are upset with the change. A WordPress.com <a title="http://en.forums.wordpress.com/topic/image-resize-1?replies=430" href="http://en.forums.wordpress.com/topic/image-resize-1?replies=430">support forum thread</a> with over 430 posts is filled with users asking why the feature was removed. In some cases, WordPress.com staff are explaining how to use HTML code to add or remove borders to images. It&#8217;s possible that a plugin will soon be released that will restore this feature.</p>
<h3>Use Patience When Asking For Support</h3>
<p>Since WordPress 3.9 is a major upgrade, please exercise patience when requesting support on the forum. This <a title="https://codex.wordpress.org/Using_the_Support_Forums#Getting_Your_Questions_Answered_on_the_Forum" href="https://codex.wordpress.org/Using_the_Support_Forums#Getting_Your_Questions_Answered_on_the_Forum">guide on the Codex</a> does a great job explaining how to get your question answered. Last but not least, if a volunteer helps solve your problem, say thank you. During my five-hour support stint, I realized first-hand that providing support is a thankless job. Reading thank you notes and seeing users express joy from having their problem solved gave me the energy to keep on going.</p>
<p>I encourage you to take 15-20 minutes to browse the support forum and help out where you can. Not only will you get a better understanding of problems users are facing, but you&#8217;ll learn a lot in the process. To anyone who&#8217;s taken the time to answer a support question on the forum, <strong>thank you!</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Apr 2014 19:45:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WordPress.tv: Introducing WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34317";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2014/04/16/introducing-wordpress-3-9-smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:635:"<div id="v-sAiXhCfV-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34317/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34317/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34317&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/04/16/introducing-wordpress-3-9-smith/"><img alt="WordPress3-9-Smith" src="http://videos.videopress.com/sAiXhCfV/wordpress3-9-smith_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 21:10:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: How To Set Up 1 Or 2 Columns For WordPress Dashboard Widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21030";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/how-to-set-up-1-or-2-columns-for-wordpress-dashboard-widgets?utm_source=rss&utm_medium=rss&utm_campaign=how-to-set-up-1-or-2-columns-for-wordpress-dashboard-widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3932:"<p>One of the improvements in <a title="http://wordpress.org/news/2013/12/parker/" href="http://wordpress.org/news/2013/12/parker/">WordPress 3.8</a> was the responsive dashboard. Thanks to this improvement, the option to select the number of columns to display dashboard widgets <a title="http://make.wordpress.org/ui/2013/10/11/dash-update-4/" href="http://make.wordpress.org/ui/2013/10/11/dash-update-4/">was removed</a>. The dashboard now shows the appropriate number of columns using the available screen real estate. Unfortunately, for those using wide-screen monitors, this usually means 4-5 skinny columns. In the screenshot below, you can see that even if a column doesn&#8217;t have a widget assigned to it, the column remains in place.</p>
<div id="attachment_21233" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/DashboardWithFourColumns.png" rel="prettyphoto[21030]"><img class="size-full wp-image-21233" src="http://wptavern.com/wp-content/uploads/2014/04/DashboardWithFourColumns.png" alt="The Result Of A Responsive Dashboard" width="1724" height="417" /></a><p class="wp-caption-text">The Result Of A Responsive Dashboard</p></div>
<p>The issue was <a title="http://imtheirwebguy.com/dont-hit-update-just-yet-wp-3-8-overhauls-ui-breaks-dashboard-widgets/" href="http://imtheirwebguy.com/dont-hit-update-just-yet-wp-3-8-overhauls-ui-breaks-dashboard-widgets/">brought up by Chris Jenkins</a> shortly after the release of WordPress 3.8. WordPress core developer Mark Jaquith agreed that &#8220;dashboard widgets should be able to specify a min-width, such that they span multiple columns if WordPress tries to make them smaller than that.&#8221; Jaquith <a title="https://core.trac.wordpress.org/ticket/26575" href="https://core.trac.wordpress.org/ticket/26575">created a ticket</a> suggesting a fix but so far, a patch has not been created.</p>
<p>Since the ticket was created, Jenkins has developed and released a plugin called <a title="http://wordpress.org/plugins/two-column-admin/" href="http://wordpress.org/plugins/two-column-admin/">Two Column Admin</a>. When activated, the plugin restores the ability to select 1 or 2 columns to the screen options tab. The downside to using this plugin is that selecting two columns will disable the responsiveness of the dashboard widgets. Instead of merging into one column when the screen size gets smaller, the two columns will crash into each other.</p>
<div id="attachment_21234" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/TwoColumnUnresponsiveWidgets.png" rel="prettyphoto[21030]"><img class="size-full wp-image-21234" src="http://wptavern.com/wp-content/uploads/2014/04/TwoColumnUnresponsiveWidgets.png" alt="Two Column Unresponsive Widgets" width="500" height="447" /></a><p class="wp-caption-text">Two Column Unresponsive Widgets</p></div>
<p>Matt Beck <a title="https://core.trac.wordpress.org/ticket/26575#comment:1" href="https://core.trac.wordpress.org/ticket/26575#comment:1">responded to the ticket</a> with a good suggestion in lieu of the column option returning:</p>
<blockquote><p>Best case scenario would be for the number/width of columns to adjust to the number of active dashboard widgets instead of displaying the empty drag/drop areas. In lieu of that, some mechanism to specify either column-count of a widget intended to be wide and/or better yet &#8211; maximum number of columns to display on the dashboard would be great.</p></blockquote>
<p>After being stuck with four columns since the release of 3.8, I&#8217;ve forgotten how nice it is to have wide dashboard widgets. I&#8217;m hopeful that in the future, the ability to specify the number of columns in the dashboard returns as I prefer three, not four columns.</p>
<p><strong>How many of you would like to be able to specify a specific amount of columns versus the current implementation?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 19:30:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: BuddyPress Development Trunk to Adopt a Grunt-Powered Build System";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21231";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/buddypress-development-trunk-to-adopt-a-grunt-powered-build-system?utm_source=rss&utm_medium=rss&utm_campaign=buddypress-development-trunk-to-adopt-a-grunt-powered-build-system";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3238:"<p><a href="http://wptavern.com/wp-content/uploads/2014/04/grunt.jpg" rel="prettyphoto[21231]"><img src="http://wptavern.com/wp-content/uploads/2014/04/grunt.jpg" alt="grunt" width="916" height="360" class="aligncenter size-full wp-image-21245" /></a></p>
<p>Now that <a href="http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools" target="_blank">BuddyPress 2.0</a> has been released, the core development team is refining its workflow to make use of <a href="http://gruntjs.com/" target="_blank">Grunt</a>, the Javascript task runner that the WordPress project <a href="http://make.wordpress.org/core/2013/08/06/a-new-frontier-for-core-development/" target="_blank">adopted</a> last year. The <a href="http://buddypress.svn.wordpress.org/trunk" target="_blank">BuddyPress development trunk</a> will be adopting a similar Grunt-powered build system that will automate many tedious tasks.</p>
<p>The BuddyPress trunk will be reorganized to include a <strong>/src</strong> directory for BuddyPress, minus bbPress 1.1 and the BP-Default theme, which will be removed. The <strong>/tests</strong> directory will house the phpUnit tests. <a href="https://travis-ci.org/buddypress/BuddyPress" target="_blank">Travis-CI</a> and configuration files for tests will be moved to the root.</p>
<h3>Who Is Affected?</h3>
<p>The reorganization of the trunk will not affect production releases of BuddyPress, so for most ordinary users nothing will change. BuddyPress core contributor Paul Gibbs specified who will be affected by the changes in his <a href="http://bpdevel.wordpress.com/2014/04/16/grunt-coming-to-buddypress/" target="_blank">post</a> on the development blog. The changes concern you if:</p>
<ul>
<li>You develop plugins for BuddyPress</li>
<li>You are a core contributor</li>
<li>You run a checkout of trunk on a production site</li>
</ul>
<p>While this cross section of affected users represents just a handful of BuddyPress developers, the good news for everyone is that both core and extension development will become more efficient. That means that improvements and new plugins are likely to reach you faster than before.</p>
<h3>How Will Grunt Make BuddyPress Development More Efficient?</h3>
<p>Grunt will reduce the amount of manual labor that developers put into contributing to the BuddyPress core and creating plugins. The task runner will handle all of the following:</p>
<ul>
<li>Validate and lint CSS/JS</li>
<li>Generate right-to-left CSS</li>
<li>Compress images</li>
<li>Run unit tests</li>
<li>Generate the .pot file for internationalization</li>
<li>Check for missing text domains</li>
<li>Make it easier for developers to apply patches from BuddyPress Trac for testing</li>
</ul>
<p>The core team may add to this list in the future. If you want to get involved in the discussion or keep an eye on the &#8220;grunt-ification&#8221; of the BuddyPress trunk, there&#8217;s a <a href="https://buddypress.trac.wordpress.org/ticket/5160" target="_blank">trac ticket</a> open where updates will be posted. Core contributors and developers running a checkout of trunk on production/development sites will want to stay tuned for any changes that might affect your workflow.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 19:16:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WPTavern: WordPress 3.9 “Smith” Released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19881";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://wptavern.com/wordpress-3-9-smith-released?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-3-9-smith-released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:13415:"<div id="attachment_21131" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WordPress39.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21131" src="http://wptavern.com/wp-content/uploads/2014/04/WordPress39.png" alt="WordPress 3.9 Featured Image" width="637" height="227" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/wbaiv/6252639219/">wbaiv</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a></p></div>
<p><a title="http://wordpress.org/news/2014/04/smith/" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9 &#8220;Smith&#8221;</a> is now available, just four months after the release of 3.8. This release continues the strategy of developing features as plugins first. <a title="http://wordpress.org/plugins/widget-customizer/" href="http://wordpress.org/plugins/widget-customizer/">Widgets Customizer</a> by <a title="http://profiles.wordpress.org/westonruter" href="http://profiles.wordpress.org/westonruter">Westonruter</a> is the only plugin that was developed and merged into WordPress this time around. Much of the work in <a title="http://codex.wordpress.org/Version_3.9" href="http://codex.wordpress.org/Version_3.9">WordPress 3.9</a> is an improvement of features added in earlier versions. Without further ado, let&#8217;s take a look at what this release has to offer.</p>
<h3>New: Create Audio/Video Playlists</h3>
<p>Building upon the addition of audio and video in WordPress 3.6, WordPress 3.9 offers a lot of enhancements. For starters, you can now create audio playlists. You can also add multiple sources to help with cross-browser compatibility. Managing multiple sources is easy thanks to an improved workflow. WordPress now has subtitle support for videos as long as you supply the appropriate files. <a title="http://html5doctor.com/video-subtitling-and-webvtt/" href="http://html5doctor.com/video-subtitling-and-webvtt/">This post by HTML5Doctor</a> explains how to create the proper files to add subtitles to videos.</p>
<div id="attachment_21126" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP39AudioPlaylists.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21126" src="http://wptavern.com/wp-content/uploads/2014/04/WP39AudioPlaylists.png" alt="Audio Playlist In The Visual Editor Of WordPress 3.9" width="911" height="464" /></a><p class="wp-caption-text">Audio Playlist In The Visual Editor Of WordPress 3.9</p></div>
<h3>Searching For WordPress Themes Has Never Been Easier</h3>
<p>The theme browsing experience in WordPress 3.8 has been significantly improved in 3.9. The new theme browser features large preview images, indicators on which themes you already have installed, and fast-loading previews. Browsing and installing new themes in WordPress has never been easier.</p>
<div id="attachment_21121" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP39ThemeExperience.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21121" src="http://wptavern.com/wp-content/uploads/2014/04/WP39ThemeExperience.png" alt="Theme Browser Experience Revamped In WordPress 3.9" width="859" height="503" /></a><p class="wp-caption-text">Theme Browser Experience Revamped In WordPress 3.9</p></div>
<h3>Crop and Edit Images From Within The Visual Editor</h3>
<p>Images are easier to edit and remove from posts. Simply click on the image within the visual editor and select the pencil icon. This will launch the image details screen. From here, you can quickly edit the details of the image and if you select the <strong>Edit Original button</strong>, you&#8217;ll be able to crop, flip, and change the image size. You can also drag and drop images right into the editor. Alternatively, you can crop and edit an image from within the visual editor.</p>
<div id="attachment_21117" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/ImageEditingWP39.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21117" src="http://wptavern.com/wp-content/uploads/2014/04/ImageEditingWP39.png" alt="Image Editing In WordPress 3.9" width="818" height="488" /></a><p class="wp-caption-text">Image Editing In WordPress 3.9</p></div>
<p>Instead of seeing a placeholder, galleries can now be previewed as a grid within the visual editor. You cannot yet drag images around to change the display order, but this feature is expected to be added in a future update.</p>
<div id="attachment_21116" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/LivePreviewGalleries.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21116" src="http://wptavern.com/wp-content/uploads/2014/04/LivePreviewGalleries.png" alt="Preview Galleries Live Within The Visual Editor" width="878" height="625" /></a><p class="wp-caption-text">Preview Galleries Live Within The Visual Editor</p></div>
<h3>Live Widget Previews</h3>
<p>You can now preview changes to widgets in real-time thanks to the theme customizer. Gone are the days of having to refresh the page every time you want to preview a change to a widget.</p>
<div id="attachment_21138" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP39LiveWidgetPreview.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21138" src="http://wptavern.com/wp-content/uploads/2014/04/WP39LiveWidgetPreview.png" alt="WordPress 3.9 Live Widget Previews" width="1150" height="569" /></a><p class="wp-caption-text">WordPress 3.9 Live Widget Previews</p></div>
<h3>A New Streamlined Post Editor</h3>
<p>The post editor in WordPress 3.9 has been updated to use TinyMCE 4.0. The update provides the following enhancements:</p>
<ul>
<li>New UI and UI API.</li>
<li>New theme.</li>
<li>Revamped events system/API.</li>
<li>Better code quality, readability and build process.</li>
<li>Lots of (inline) documentation.</li>
</ul>
<p>The Paste from Word button has been removed. When text from Microsoft Word is pasted into WordPress, the editor will automatically strip out the special formatting. The distraction free writing mode button is now on the right side of the editor. Distraction free writing mode <a title="http://wptavern.com/distraction-free-writing-mode-will-be-responsive-in-wordpress-3-9" href="http://wptavern.com/distraction-free-writing-mode-will-be-responsive-in-wordpress-3-9">is also responsive</a>. The changes to the editor are a noticeable improvement when compared to WordPress 3.8.</p>
<div id="attachment_21130" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/WP39TinyMCE40.png" rel="prettyphoto[19881]"><img class="size-full wp-image-21130" src="http://wptavern.com/wp-content/uploads/2014/04/WP39TinyMCE40.png" alt="TinyMCE 4.0 In WordPress 3.9" width="683" height="349" /></a><p class="wp-caption-text">TinyMCE 4.0 In WordPress 3.9</p></div>
<h3>oEmbed Support Added For Meetup and Imgur</h3>
<p>Publishing content from either Meetup.com or Imgur is now as simple as <a title="http://wptavern.com/wordpress-3-9-to-add-oembed-support-for-meetup-com-and-imgur" href="http://wptavern.com/wordpress-3-9-to-add-oembed-support-for-meetup-com-and-imgur">pasting the URL</a> into the editor. Meanwhile, oEmbed support for Qik has been removed.</p>
<div id="attachment_20405" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/04/oembeddedurlformeetupevent2.png" rel="prettyphoto[19881]"><img class="size-full wp-image-20405" src="http://wptavern.com/wp-content/uploads/2014/04/oembeddedurlformeetupevent2.png" alt="Meetup Group Event Embedded Into A Post" width="545" height="255" /></a><p class="wp-caption-text">Meetup Group Event Embedded Into A Post</p></div>
<h3>Take A Tour Of WordPress 3.9</h3>
<p>Michael Pick does a great job showing and explaining the new features in WordPress 3.9.<br />
</p>
<h3>Important Information For WordPress Developers</h3>
<p>There are a lot of under-the-hood improvements in WordPress 3.9. Over the past two-weeks, those responsible for adding specific features to WordPress have written detailed blog posts on the <a title="http://make.wordpress.org/core/" href="http://make.wordpress.org/core/">Make WordPress Core</a> development blog. Here is a list of noteworthy items you may have missed.</p>
<p><a title="http://make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5 Galleries and Captions in WordPress 3.9</a> &#8211; WordPress 3.6 introduced HTML5 versions of popular template tags, starting out with comments, the comment form, and the search form. With the 3.9 release the team added galleries and captions to that list. Now, when adding HTML5 support for those features, WordPress will use <code>&lt;figure&gt;</code> and <code>&lt;figcaption&gt;</code> elements, instead of the generic definition list markup.</p>
<p><a title="http://make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">Symlinked Plugins in WordPress 3.9</a> &#8211; One of the cool little features included with 3.9 is the ability to symlink plugin directories. While it has been possible to symlink plugins in the past, functions such as <code>plugins_url()</code> return the wrong URL, which causes breakage in most plugins. The team has corrected this with the help of a new function.</p>
<p><a title="http://make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload 2.x in WordPress 3.9</a> &#8211; Plupload is the library that powers most of the file upload interfaces in WordPress, and in 3.9 the team has updated the bundled library to version 2.1.1. This post lists some of the things that have changed, which may affect WordPress plugins and themes.</p>
<p><a title="http://make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL in WordPress 3.9</a> &#8211; In WordPress 3.9, we added an extra layer to WPDB, causing it to switch to using the mysqli PHP library, when using PHP 5.5 or higher. For plugin developers, this means that you absolutely shouldn’t be using PHP’s mysql_*() functions any more – you can use the equivalent WPDB functions instead.</p>
<p><a title="http://make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">Masonry in WordPress 3.9</a> &#8211; If you use Masonry in your themes or plugins, here’s what you should know about the 3.9 update.</p>
<p><a title="http://make.wordpress.org/core/2014/03/27/tinymce-4-0-requires-textcss-for-editor-style-files/" href="http://make.wordpress.org/core/2014/03/27/tinymce-4-0-requires-textcss-for-editor-style-files/">TinyMCE 4.0 Requires text/css For Editor Style Files</a> &#8211; As of TinyMCE 4.0, the visual editor iframe now has an HTML5 document type (<code><!--<span class="hiddenSpellError" pre=""-->DOCTYPE html&gt;</code>). In this scenario, CSS files must be served with the <code>text/css</code> content type. A server will serve a <code>*.css</code> file with the proper content type, but if you’re using a PHP file for an editor style file, you need to be the one to do it.</p>
<p><a title="http://make.wordpress.org/core/2014/04/16/multisite-changes-in-3-9/" href="http://make.wordpress.org/core/2014/04/16/multisite-changes-in-3-9/">Multisite Changes In 3.9</a> &#8211; Much of the bootstrap code for Multisite in ms-settings.php has been refactored in<a href="http://core.trac.wordpress.org/ticket/27003"> #27003</a> with the intent to improve how we handle the detection of domains and paths for sites and networks in core. Several other smaller enhancements and bugs have been completed in this and in other tickets.</p>
<p><a title="http://make.wordpress.org/core/2014/04/16/jquery-ui-and-wpdialogs-in-wordpress-3-9/" href="http://make.wordpress.org/core/2014/04/16/jquery-ui-and-wpdialogs-in-wordpress-3-9/">jQuery UI and wpdialogs in WordPress 3.9</a> &#8211; WordPress 3.9 does not use the “wpdialogs” TinyMCE plugin as part of the TinyMCE 4.0 update which comes with a new dialog manager.</p>
<h3>Thanks To Everyone Who Contributed To 3.9</h3>
<p>Although 3.9 doesn&#8217;t have a lot of <strong>new</strong> features, the refinements to existing functionality are just as satisfying. I&#8217;m happy to see a release where the focus was more on improving what WordPress already has versus adding new functionality. Even though the live previews of widgets is my favorite feature, several of the pesky bugs that were squashed are a close second.</p>
<p>WordPress wouldn&#8217;t be what it is today without all of the awesome contributions from the community. Thanks to everyone who helped make 3.9 a reality! This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder. </a>There are 267 contributors with props in this release, which is a new high for WordPress.</p>
<p><strong>What is your favorite feature or enhancement in WordPress 3.9?</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:34:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Dev Blog: WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22531:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>

<h2 class="about-headline-callout">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="http://wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div></div>
<div>
<p><img class="alignright wp-image-3170" src="http://wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div></div>
<div>
<p><img class="alignright wp-image-3187" src="http://wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div></div>
<hr />
<h2>Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="http://wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2>Do more with audio and video</h2>

<a href="http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3">Ain\'t Misbehavin\'</a>
<a href="http://wordpress.org/news/files/2014/04/DavenportBlues.mp3">Davenport Blues</a>
<a href="http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3">Buddy Bolden\'s Blues</a>
<a href="http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3">Squaty Roo</a>
<a href="http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3">Dixie Blues</a>
<a href="http://wordpress.org/news/files/2014/04/WolverineBlues.mp3">Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2>Live widget and header previews</h2>
<div class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<a href="http://wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2>Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="http://wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2>The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/cmmarslender">cmmarslender</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/pbearne">Pbearne</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">salcode</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tellyworth">tellyworth</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: BuddyPress 2.0 Released: Big Performance Improvements and New Administration Tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=21201";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:226:"http://wptavern.com/buddypress-2-0-released-big-performance-improvements-and-new-administration-tools?utm_source=rss&utm_medium=rss&utm_campaign=buddypress-2-0-released-big-performance-improvements-and-new-administration-tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4710:"<p>BuddyPress 2.0 &#8220;<a href="http://buddypress.org/2014/04/buddypress-2-0-juliana/" target="_blank">Juliana</a>&#8221; arrived on schedule today, less than a week after the plugin crossed <a href="http://wptavern.com/major-milestone-for-buddypress-2-million-downloads-and-counting" target="_blank">two million downloads</a>. This release focused heavily on improving BuddyPress performance, adding new administrative tools and enhancing the activity stream. It&#8217;s named for <a href="http://julianaspizza.com/" target="_blank">Juliana’s Pizza</a> in Brooklyn, NY, a pizza joint that is special to members of the core development team.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/buddypress20.png" rel="prettyphoto[21201]"><img src="http://wptavern.com/wp-content/uploads/2014/04/buddypress20.png" alt="buddypress20" width="1555" height="1305" class="aligncenter size-full wp-image-21202" /></a></p>
<h3>Performance Improvements</h3>
<p>One of the major highlights of this release is the <a href="http://wptavern.com/ http://wptavern.com/buddypress-2-0-ramps-up-performance-reduces-footprint-by-up-to-75" target="_blank">massive improvement in performance</a>, especially as it relates to Members and Activity directories. BuddyPress 2.0 improves MySQL efficiency, decreasing queries by up to 75% and reducing query time by up to 71%, depending on the your site&#8217;s hosting environment. If your site uses advanced caching systems, such as APC and Memcached, expect a performance increase here, as 2.0 completely overhauls how these are utilized.</p>
<h3>New BuddyPress Administration Tools</h3>
<p>BuddyPress 2.0 introduces a host of new administration tools that make it easier to manage communities. Administrators can now <a href="http://wptavern.com/buddypress-2-0-to-add-profile-editing-in-the-wordpress-admin" target="_blank">edit member profiles</a> in the WordPress admin. This release also ships with a new <a href="http://wptavern.com/buddypress-2-0-to-add-signups-administration-screen" target="_blank">signups administration screen</a> that allows administrators to track the status of pending accounts and facilitate the signup process.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/signups-featured.jpg" rel="prettyphoto[21201]"><img src="http://wptavern.com/wp-content/uploads/2014/03/signups-featured.jpg" alt="signups-featured" width="800" height="438" class="aligncenter size-full wp-image-19429" /></a></p>
<p>Community managers will be pleased to know that version 2.0 provides <a href="http://wptavern.com/buddypress-2-0-to-add-better-spam-management-capabilities-for-administrators" target="_blank">better spam management capabilities</a> with the ability to mark users as ham/spam within the admin users panel, a feature that was previously only available on multisite installations.</p>
<p>Version 2.0 includes a handy new &#8220;Repair Tools&#8221; menu at Dashboard > Tools > BuddyPress. This menu makes it easy to correct data that can sometimes get out of sync on BuddyPress sites.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/buddypress-tools.jpg" rel="prettyphoto[21201]"><img src="http://wptavern.com/wp-content/uploads/2014/04/buddypress-tools.jpg" alt="buddypress-tools" width="750" height="516" class="aligncenter size-full wp-image-21219" /></a></p>
<h3>Improved Activity Stream</h3>
<p>The activity stream has received a few enhancements in 2.0. It will now automatically let you know when new items are ready to be loaded. It&#8217;s also much better integrated with blog posts. Comments are synced across blog-related activity items and the actual post itself. This unifies conversations that take place in different areas on a BP site.</p>
<p>The activity stream will also play better with translations. Given that roughly half of BuddyPress installs are in a language other than English, this is a nice update. Check out this demo video created by <a href="https://twitter.com/BoweFrankema/status/455055453706526721" target="_blank">Bowe Frankema</a> to see how that works.</p>
<p></p>
<p></p>
<p>Improvements in BuddyPress 2.0 help the social features to really shine and make community management more efficient for administrators. The plugin has come a long way since <a href="http://buddypress.org/2009/04/buddypress-10-has-arrived/" target="_blank">version 1.0</a> was released almost five years ago. The BuddyPress community has grown and thanks to the work of 42 volunteer contributors, 2.0 is ready for download today. Check out the full <a href="http://codex.buddypress.org/developer/releases/version-2-0/" target="_blank">2.0 changelog</a> to see everything that&#8217;s new and improved.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 15:53:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"BuddyPress: BuddyPress 2.0 “Juliana”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://buddypress.org/?p=181333";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://buddypress.org/2014/04/buddypress-2-0-juliana/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:10225:"<p>The BuddyPress team is thrilled to announce that BuddyPress 2.0 &#8220;Juliana&#8221; is now available!</p>
<p>This release focuses on administrative tools, performance, and improvements to the activity stream. Let&#8217;s take a look at some of the highlights.</p>
<div></div>
<h4>New Administrative Tools</h4>
<p>If you manage a BuddyPress-powered community, BuddyPress 2.0 is for you. We have built a number of new tools that simplify and centralize common administrative tasks:</p>
<ul>
<li><em>Profile editing</em> &#8211; Need to manage a user&#8217;s profile information? We&#8217;ve integrated a new &#8220;Extended Profile&#8221; tab into the Dashboard &gt; Users interface, where you can manage profile data, avatars, user status, and more.<br /><a href="http://buddypress.org/wp-content/uploads/1/2014/04/admin-xprofile.jpg"><img src="http://buddypress.org/wp-content/uploads/1/2014/04/admin-xprofile-300x206.jpg" alt="admin-xprofile" width="300" height="206" class="alignleft size-medium wp-image-181344" /></a>
  </li>
<li><em>Spam User Management</em> &#8211; WordPress Multisite has long had the ability to manage spam users from the Dashboard. We&#8217;ve brought the same capabilities to non-Multisite installations. <br />
<a href="http://buddypress.org/wp-content/uploads/1/2014/04/user-mark-spam.jpg"><img src="http://buddypress.org/wp-content/uploads/1/2014/04/user-mark-spam-300x206.jpg" alt="user-mark-spam" class="size-thumbnail wp-image-181342" /></a>
  </li>
<div> </div>
<li><em>Pending Users</em> &#8211; The Pending users tab in Dashboard &gt; Users lets you see a list of signups that have not yet been activated. You can also perform useful tasks like manual account activation and resending activation emails. <br /><a href="http://buddypress.org/wp-content/uploads/1/2014/04/users-pending.jpg"><img src="http://buddypress.org/wp-content/uploads/1/2014/04/users-pending-300x206.jpg" alt="users-pending" class="size-thumbnail wp-image-181343" /></a>
  </li>
<li><em>Repair Tools</em> &#8211; Occasionally, BP friend counts and other data can get out of sync. The new Tools screen lets admins manually reset these values. <br /><a href="http://buddypress.org/wp-content/uploads/1/2014/04/tools-buddypress.jpg"><img src="http://buddypress.org/wp-content/uploads/1/2014/04/tools-buddypress-300x206.jpg" alt="tools-buddypress" class="size-thumbnail wp-image-181341" /></a>
  </li>
</ul>
<div></div>
<h4>Performance Improvements</h4>
<p>The most successful BuddyPress sites are highly dynamic, with a steady stream of new visitors and new content. This dynamic nature means that BuddyPress is a highly database-driven platform, and database performance is often a bottleneck when it comes to scaling BP sites. BuddyPress 2.0 tackles this problem head-on. We&#8217;ve streamlined some of the most common problematic queries &#8211; such as those in the Members and Activity directories &#8211; to shave up to 95% of the query time off of certain individual queries. The sheer number of queries has been dramatically reduced as well, so that single page views access the database up to 50% less than in BP 1.9. And we&#8217;ve totally overhauled the way that BuddyPress utilizes advanced caching systems like APC and Memcached, so that users of these systems will see up to 75% fewer cache misses on costly queries.</p>
<p>If you&#8217;re a BuddyPress developer or site administrator, you can get more in-depth explanation of changes and an overview of selected benchmarks <a href="http://bpdevel.wordpress.com/2014/04/02/one-of-the-primary-focuses/">in this post on bpdevel.wordpress.com</a>. If you are a BuddyPress user, you can just sit back and enjoy the speedier pageloads and reduced server overhead of your BuddyPress 2.0 site!</p>
<div></div>
<h4>Activity Stream Enhancements</h4>
<p>Spend a lot of time viewing the activity stream? BuddyPress 2.0 automatically lets you know when new items are ready to be loaded.</p>
<p><a href="http://buddypress.org/wp-content/uploads/1/2014/04/load-newest.jpg"><img src="http://buddypress.org/wp-content/uploads/1/2014/04/load-newest.jpg" alt="load-newest" width="558" height="302" class="size-full wp-image-181356" /></a></p>
<p>The activity stream is better integrated with blog posts, too. Comment on a blog post, and an activity item is posted. Comment on a blog-related activity item, and a blog comment is posted. No more worrying about fractured conversations.</p>
<p>We’ve also reworked the way that phrases like &#8220;Boone posted an update&#8221; are handled, so that they’re always up-to-date and always translatable.</p>
<div></div>
<h4>And much more</h4>
<p>BuddyPress 2.0 introduces dozens more small features, and fixes scores of bugs. We&#8217;ve compiled <a href="http://codex.buddypress.org/developer/releases/version-2-0/">a complete 2.0 changelog</a> on the BuddyPress Codex.</p>
<div></div>
<h4>Juliana is Number Two</h4>
<p>BuddyPress 2.0 is named for <a href="http://julianaspizza.com/">Juliana&#8217;s Pizza</a> in Brooklyn, NY. Juliana&#8217;s is the second pizza establishment opened in the same location by master pizzaiolo Patsy Grimaldi (it&#8217;s a long story), and was also the locale for a serious BuddyPress powwow and up-close dining experience by two members of the core team. For these reasons (not to mention the outstanding pizza) we think that BuddyPress 2.0 &#8220;Juliana&#8221; has a special ring to it.</p>
<div></div>
<h4>Thanks, thanks, and more thanks</h4>
<p>BuddyPress is built, with love, by a worldwide network of volunteers. The following people contributed patches during the BuddyPress 2.0 development cycle:</p>
<p><a href="https://profiles.wordpress.org/boonebgorges/">boonebgorges</a>, <a href="https://profiles.wordpress.org/Bowromir/">Bowromir</a>, <a href="https://profiles.wordpress.org/burakali/">burakali</a>, <a href="https://profiles.wordpress.org/chouf1/">chouf1</a>, <a href="https://profiles.wordpress.org/cmmarslender/">cmmarslender</a>, <a href="https://profiles.wordpress.org/danbp/">danbp</a>, <a href="https://profiles.wordpress.org/dcavins/">dcavins</a>, <a href="https://profiles.wordpress.org/Denis-de-Bernardy/">Denis-de-Bernardy</a>, <a href="https://profiles.wordpress.org/DJPaul/">DJPaul</a>, <a href="https://profiles.wordpress.org/ericlewis/">ericlewis</a>, <a href="https://profiles.wordpress.org/glyndavidson/">glyndavidson</a>, <a href="https://profiles.wordpress.org/graham-washbrook/">graham-washbrook</a>, <a href="https://profiles.wordpress.org/henrywright/">henrywright</a>, <a href="https://profiles.wordpress.org/henry.wright/">henry.wright</a>, <a href="https://profiles.wordpress.org/hnla/">hnla</a>, <a href="https://profiles.wordpress.org/imath/">imath</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby/">johnjamesjacoby</a>, <a href="https://profiles.wordpress.org/karmatosed/">karmatosed</a>, <a href="https://profiles.wordpress.org/lenasterg/">lenasterg</a>, <a href="https://profiles.wordpress.org/MacPresss/">MacPresss</a>, <a href="https://profiles.wordpress.org/markoheijnen/">markoheijnen</a>, <a href="https://profiles.wordpress.org/megainfo/">megainfo</a>, <a href="https://profiles.wordpress.org/mercime">mercime</a>, <a href="https://profiles.wordpress.org/modemlooper/">modemlooper</a>, <a href="https://profiles.wordpress.org/mpa4hu/">mpa4hu</a>, <a href="https://profiles.wordpress.org/needle/">needle</a>, <a href="https://profiles.wordpress.org/netweb/">netweb</a>, <a href="https://profiles.wordpress.org/ninnypants/">ninnypants</a>, Pietro Oliva, <a href="https://profiles.wordpress.org/pross/">pross</a>, <a href="https://profiles.wordpress.org/r-a-y/">r-a-y</a>, <a href="https://profiles.wordpress.org/reactuate/">reactuate</a>, <a href="https://profiles.wordpress.org/rodrigorznd/">rodrigorznd</a>, <a href="https://profiles.wordpress.org/rogercoathup/">rogercoathup</a>, <a href="https://profiles.wordpress.org/rzen/">rzen</a>, <a href="https://profiles.wordpress.org/SergeyBiryukov/">SergeyBiryukov</a>, <a href="https://profiles.wordpress.org/shanebp/">shanebp</a>, <a href="https://profiles.wordpress.org/SlothLoveChunk/">SlothLoveChunk</a>, <a href="https://profiles.wordpress.org/StijnDeWitt/">StijnDeWitt</a>, <a href="https://profiles.wordpress.org/terraling/">terraling</a>, <a href="https://profiles.wordpress.org/trishasalas/">trishasalas</a>, <a href="https://profiles.wordpress.org/tw2113/">tw2113</a>, <a href="https://profiles.wordpress.org/vanillalounge/">vanillalounge</a>.</p>
<p>Many thanks to these contributors, and to all who have pitched in the forums and elsewhere.</p>
<p>One final point. Technically, BuddyPress &#8220;2.0&#8243; is just the version between 1.9 and 2.1. But still, there&#8217;s something special about crossing into the 2.x series, especially given the timing: we just crossed <a href="http://wptavern.com/major-milestone-for-buddypress-2-million-downloads-and-counting">2 million downloads</a>, and it&#8217;s been almost exactly five years since <a href="http://buddypress.org/2009/04/buddypress-10-has-arrived/">BuddyPress 1.0 was released</a>. On behalf of the core team and contributors, I&#8217;d like to extend a few special thanks: to founding developer <a href="http://apeatling.com/">Andy Peatling</a> for getting the ball rolling; to <a href="http://ma.tt">Matt Mullenweg</a> for providing support to the BuddyPress project; and especially to the many thousands of BuddyPress users who have followed and advocated for the project over the years. If BP has done great things for the thousands of communities that depend on it (and I think it has), it&#8217;s because of the incredible community around the software itself. <strike>A million</strike> Two million thanks to all of you.</p>
<div></div>
<h4>Upgrade Today</h4>
<p>You can get BuddyPress 2.0 from the <a href="http://wordpress.org/plugins/buddypress/">wordpress.org plugin repository</a>, or right from your WordPress Dashboard. </p>
<p>As always, questions, comments, bug reports, feature requests, and general laudatory remarks can be directed toward our <a href="https://buddypress.org/support/">support forums</a> or our <a href="https://buddypress.trac.wordpress.org">development tracker</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 14:48:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Boone Gorges";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Akismet: Akismet 3.0.0 is now available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1294";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://blog.akismet.com/2014/04/15/akismet-3-0-0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1738:"<p>Version 3.0.0 of the <a href="http://wordpress.org/plugins/akismet/">Akismet plugin for WordPress</a> is now available.</p>
<p>This is a <strong>major rewrite</strong> of the plugin code. It includes many small improvements and some new features. In particular:</p>
<ul>
<li>An easier signup and activation process</li>
<li>An even easier activation process for <a href="http://jetpack.me/">Jetpack</a> users</li>
<li>A redesigned configuration tab</li>
<li>New stats charts (example shown below)</li>
<li>A new discard feature for outright blocking of the worst spam</li>
</ul>
<p><a href="http://akismet.files.wordpress.com/2014/04/stats-at-a-glance2.png"><img src="http://akismet.files.wordpress.com/2014/04/stats-at-a-glance2.png?w=640&h=295" alt="stats-at-a-glance" width="640" height="295" class="alignnone size-large wp-image-1304" /></a></p>
<p>To update to version 3.0.0, just use the plugin updater in your WordPress dashboard. If you&#8217;re running WordPress 3.9, there&#8217;s no need to update. If you haven&#8217;t installed Akismet on your WordPress blog yet, <a href="http://docs.akismet.com/getting-started/activate/">follow these instructions</a> to get started.</p>
<p>Thanks again to everyone who helped <a href="http://blog.akismet.com/2014/04/11/help-test-the-next-akismet-plugin/">test the new plugin</a> and offered suggestions and bug reports.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1294/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1294/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1294&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 23:40:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"Andrew Nacin: My Talk Proposals for Open Source Bridge";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:24:"http://nacin.com/?p=4228";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://nacin.com/2014/04/15/my-talk-proposals-for-open-source-bridge/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2106:"<p>I submitted two proposals to <a href="http://opensourcebridge.org/">Open Source Bridge</a>, an annual conference in Portland, Oregon, for &#8220;open source citizens.&#8221; The call for papers is now closed, but they let anyone leave comments on proposals that are private to the conference organizers. If you have any feedback on these, or have seen me speak before, it would be awesome if you could leave a comment. Here they are:</p>
<h2><a href="http://opensourcebridge.org/proposals/1413">Extreme Software Portability as an Art Form</a></h2>
<p>Writing portable software is hard. Throw in thousands of bad and worse shared hosting configurations, a decade of technical debt, the need to cater to a sprawling ecosystem, and PHP — and you have WordPress. We&#8217;ve found breaking changes harm our community and unfairly punish our users, so we don&#8217;t make them. But that doesn&#8217;t mean we don&#8217;t innovate or evolve — we&#8217;re just forced to get really clever. And it works, with adoption continuing to soar.</p>
<h2><a href="http://opensourcebridge.org/proposals/1419">Trust, Community, and Automatic Updates</a></h2>
<p>WordPress shipped in October what is perhaps its most polarizing feature ever — automatic updates in the background of self-hosted web software, on by default and no easy way to turn it off. In most open source communities, this would be cause for open revolt. Learn how through trust, communication, and a steadfast commitment to its philosophies, the WordPress core team convinced a skeptical community to go along, even if it meant users giving up some control.</p>
<p>WordPress contributors Mel Choyce and Aaron Jorbin also both submitted proposals: <a href="http://opensourcebridge.org/proposals/1315">My Journey into Open Source Design</a> and <a href="http://opensourcebridge.org/proposals/1312">Modernizing a Stagnant Toolbox</a>.</p>
<p class="share-sfc-stc"><a href="http://twitter.com/share?url=http%3A%2F%2Fwp.me%2FpQEdq-16c&count=horizontal&related=nacin&text=My Talk Proposals for Open Source Bridge" class="twitter-share-button"></a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 21:04:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: Ozh’ Tweet Archiver 2.0 Backs Up Your Tweets to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=20985";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=ozh-tweet-archiver-2-0-backs-up-your-tweets-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3526:"<p><a href="http://wptavern.com/wp-content/uploads/2014/04/tweet-archiver.png" rel="prettyphoto[20985]"><img src="http://wptavern.com/wp-content/uploads/2014/04/tweet-archiver.png" alt="tweet-archiver" width="772" height="250" class="aligncenter size-full wp-image-21135" /></a></p>
<p>Social networks come and go but your blog lives forever. The advent of social media brought a revolution in how people communicate, but it has also chained us to data silos that house many of our important thoughts, writings and memories. That is, unless you have your own blog or website as your home for your content on the web.</p>
<p>Instead of mindlessly pumping content into a social network that is owned by someone else, you might stop to consider archiving that data to a better place where you can keep it forever. In a time when digital transactions and communications are the lifeblood of our work, owning your own data has become more important than owning land.</p>
<p><a href="http://wordpress.org/plugins/ozh-tweet-archiver/" target="_blank">Ozh Tweet Archiver</a> is one tool that makes owning your Twitter data a practical possibility. This free plugin automatically archives all of your tweets to your WordPress site. Browsing your tweet history is nearly impossible on Twitter, but with Ozh Tweet Archiver in place, you can easily search through your past tweets.</p>
<p>Version 2.0 is compatible with Twitter&#8217;s OAuth API. The plugin should be installed on a fresh WordPress site or subdomain. Once in place, it offers the following benefits:</p>
<ul>
<li>Searching is easier in WordPress than on Twitter</li>
<li>WordPress is not limited to the most recent 3200 tweets</li>
<li>It will automatically expand all those ugly t.co links</li>
<li>All your #hashtags can be converted to WordPress tags</li>
</ul>
<p>Check out a <a href="http://planetozh.com/tweets/" target="_blank">live demo</a> of <a href="http://twitter.com/ozh" target="_blank">@ozh Twitter account</a> archives.</p>
<p>Once the plugin is set up, it will automatically perform checks for new tweets at your chosen interval, so you won&#8217;t need to do anything else.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/04/twitter-archive-settings.jpg" rel="prettyphoto[20985]"><img src="http://wptavern.com/wp-content/uploads/2014/04/twitter-archive-settings.jpg" alt="twitter-archive-settings" width="585" height="454" class="aligncenter size-full wp-image-21161" /></a></p>
<p>Tweets are imported as regular posts with a few custom fields. The plugin includes an options panel for setting the post author, category for tweets, and the ability to turn on links for usernames. It also has an option to link hashtags to WordPress tags or Twitter hashtags. You can even turn on embedding for images that originate on pic.twitter.com.</p>
<p>Someday Twitter may lose all of its charms and fall to the wayside like many other networks before it. When that day comes, you&#8217;ll be glad that you archived all of your tweets to WordPress. If Twitter is one of your primary communication channels, consider the value of backing up your content to your home on the web with <a href="http://wordpress.org/plugins/ozh-tweet-archiver/" target="_blank">Ozh Tweet Archiver</a>. For more information on getting your archive set up, please refer to the <a href="http://planetozh.com/blog/my-projects/ozh-tweet-archiver-backup-twitter-with-wordpress/" target="_blank">official plugin page</a>, which includes documentation and troubleshooting tips.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 20:36:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 26 Apr 2014 02:43:50 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"243133";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sat, 26 Apr 2014 02:30:13 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (113, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1398523432', 'no') ; 
INSERT INTO `wp_options` VALUES (114, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1398480232', 'no') ; 
INSERT INTO `wp_options` VALUES (115, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1398523432', 'no') ; 
INSERT INTO `wp_options` VALUES (116, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 26 Apr 2014 02:30:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"25254@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Fully customise WordPress edit screens with powerful fields. Boasting a professional interface and a powerful API, it’s a must have for any web deve";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"Wordfence Security is a free enterprise class security plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 9 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 26 Apr 2014 02:43:52 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Fri, 09 Mar 2007 22:11:30 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911110210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (117, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1398523432', 'no') ; 
INSERT INTO `wp_options` VALUES (118, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1398480232', 'no') ; 
INSERT INTO `wp_options` VALUES (119, '_transient_timeout_plugin_slugs', '1398567563', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:24:"wordpress-seo/wp-seo.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (121, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1398523432', 'no') ; 
INSERT INTO `wp_options` VALUES (122, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/04/smith/\'>WordPress 3.9 “Smith”</a> <span class="rss-date">April 16, 2014</span><div class="rssSummary">Version 3.9 of WordPress, named “Smith” in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you’ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/how-to-repair-a-crashed-wordpress-posts-table?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=how-to-repair-a-crashed-wordpress-posts-table\' title=\'photo credit: Code &amp; Martini by Ivana Vasilj – cc license Every now and then the WordPress posts table will crash and screw up your website. Why does this happen? It’s not always clear how tables get corrupted, although it can usually be attributed to an unexpected event, such as the MySQL server or the server host getting killed in the middle of an upda\'>WPTavern: How to Repair a Crashed WordPress Posts Table</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordpress-code-reference-is-now-live?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordpress-code-reference-is-now-live\' title=\'Siobhan McKeown announced that the first version of the WordPress Code Reference is now live. It’s still in the very early stages of development but is now out in the wild so that people can help contribute. Go try it out to see how easy it is to search the WordPress code base. The reference was created as part of the devhub project to make it easy for devel\'>WPTavern: WordPress Code Reference is Now Live</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/interface-a-free-responsive-business-theme-for-wordpress?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=interface-a-free-responsive-business-theme-for-wordpress\' title=\'Interface is a new business theme in the WordPress Themes Directory, created by Theme Horse, the same folks behind the popular Clean Retina and Attitude themes that have more than 80,000 downloads combined. If you need to set up a simple business site and you’re into the flat-style mint green design trend, then the new Interface theme might be just the ticke\'>WPTavern: Interface: A Free Responsive Business Theme for WordPress</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/jetpack/\' class=\'dashboard-news-plugin-link\'>Jetpack by WordPress.com</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=jetpack&amp;_wpnonce=b73914c673&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Jetpack by WordPress.com\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (123, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (124, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (126, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398480249;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (127, 'current_theme', 'lp-bootstrap', 'yes') ; 
INSERT INTO `wp_options` VALUES (128, 'theme_mods_lp-bootstrap', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (129, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (130, '_transient_lp_bootstrap_categories', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (131, 'recently_activated', 'a:1:{s:38:"simple-backup/simple-backup-loader.php";i:1398480751;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (132, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1398491080', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1398568216;s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (143, 'hmbkp_default_path', '/Users/LizPonce/Websites/www.lizponce.com/wp-content/backupwordpress-20d87becf0-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'hmbkp_path', '/Users/LizPonce/Websites/www.lizponce.com/wp-content/backupwordpress-20d87becf0-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1398553200;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (146, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1398567600;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (147, 'hmbkp_plugin_version', '2.6', 'yes') ; 
INSERT INTO `wp_options` VALUES (148, '_transient_timeout_hmbkp_plugin_data', '1398567455', 'no') ; 
INSERT INTO `wp_options` VALUES (149, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":19:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:3:"2.6";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:32:"//profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:34:"//profiles.wordpress.org/humanmade";s:7:"willmot";s:32:"//profiles.wordpress.org/willmot";s:13:"pauldewouters";s:38:"//profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:33:"//profiles.wordpress.org/joehoyle";s:7:"mattheu";s:32:"//profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:34:"//profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.7.1";s:6:"tested";s:3:"3.9";s:13:"compatibility";a:32:{s:5:"2.8.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:3:"2.9";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"2.9.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}}s:5:"2.9.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}}s:3:"3.0";a:2:{s:5:"0.4.5";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.1.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.0.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:56;i:1;i:9;i:2;i:5;}}s:5:"3.0.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.3";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.4";a:2:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:33;i:1;i:3;i:2;i:1;}}s:3:"3.1";a:9:{s:5:"0.4.5";a:3:{i:0;i:57;i:1;i:7;i:2;i:4;}s:5:"1.0.3";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.0.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:3:"1.1";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.2";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.4";a:3:{i:0;i:50;i:1;i:4;i:2;i:2;}}s:5:"3.1.1";a:1:{s:5:"1.1.4";a:3:{i:0;i:90;i:1;i:10;i:2;i:9;}}s:5:"3.1.2";a:3:{s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:3:"1.2";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:3:"1.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:5:"3.1.3";a:2:{s:3:"1.3";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:3:"3.2";a:3:{s:5:"0.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.2";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.2.1";a:15:{s:5:"1.3.1";a:3:{i:0;i:67;i:1;i:9;i:2;i:6;}s:5:"1.3.2";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:8:"1.4 beta";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.4.1";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}s:3:"1.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"1.6";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.3";a:6:{s:3:"1.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.3.1";a:7:{s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:9;i:2;i:9;}s:5:"1.6.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.6.6";a:3:{i:0;i:63;i:1;i:19;i:2;i:12;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:8;i:2;i:8;}}s:5:"3.3.2";a:3:{s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:5:"1.6.8";a:3:{i:0;i:92;i:1;i:12;i:2;i:11;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.4";a:1:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.1";a:2:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:12;i:2;i:12;}s:5:"1.6.9";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.2";a:9:{s:5:"1.6.9";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}s:8:"2.0 RC 1";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.0.1";a:3:{i:0;i:45;i:1;i:22;i:2;i:10;}s:5:"2.0.3";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"2.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.0.6";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.1.3";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}}s:3:"3.5";a:1:{s:5:"2.1.3";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}}s:5:"3.5.1";a:5:{s:5:"2.1.3";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.1";a:3:{i:0;i:100;i:1;i:10;i:2;i:10;}s:5:"2.2.4";a:3:{i:0;i:94;i:1;i:16;i:2;i:15;}s:3:"2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.5.2";a:3:{s:5:"2.2.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"2.3";a:3:{i:0;i:57;i:1;i:14;i:2;i:8;}s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}}s:3:"3.6";a:2:{s:3:"2.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.3.3";a:3:{i:0;i:50;i:1;i:6;i:2;i:3;}}s:5:"3.6.1";a:1:{s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}}s:3:"3.7";a:2:{s:5:"2.3.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.7.1";a:1:{s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:3:"3.8";a:5:{s:5:"2.3.3";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:3:"2.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.4.1";a:3:{i:0;i:75;i:1;i:4;i:2;i:3;}s:5:"2.4.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:3:"2.6";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.8.1";a:5:{s:5:"2.4.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"2.4.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.4.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:3:"2.5";a:3:{i:0;i:100;i:1;i:10;i:2;i:10;}s:3:"2.6";a:3:{i:0;i:100;i:1;i:4;i:2;i:4;}}s:5:"3.8.2";a:1:{s:3:"2.6";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}}s:6:"rating";d:91.599999999999994315658113919198513031005859375;s:11:"num_ratings";i:663;s:10:"downloaded";i:983963;s:12:"last_updated";s:10:"2014-03-17";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:30:"http://hmn.md/backupwordpress/";s:8:"sections";a:5:{s:11:"description";s:1433:"<p><a href="https://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">BackUpWordPress</a> will back up your entire site including your database and all your files on a schedule that suits you. Try it now to see how easy it is!</p>

<h4>Features</h4>

<ul>
<li>Super simple to use, no setup required.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Manage multiple schedules.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster backups if they are available.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your backups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted on GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:1083:"<ol>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=859578\' title=\'Click to view full-size screenshot 1\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=859578\' alt=\'backupwordpress screenshot 1\' />
		</a>		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=859578\' title=\'Click to view full-size screenshot 2\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=859578\' alt=\'backupwordpress screenshot 2\' />
		</a>		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=859578\' title=\'Click to view full-size screenshot 3\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=859578\' alt=\'backupwordpress screenshot 3\' />
		</a>		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:31772:"<h4>2.6</h4>

<ul>
<li>It\'s now possible to choose the time and day that your schedule will run on.</li>
<li>Introduces several new unit tests around schedule timings.</li>
<li>Fixes a bug that could cause the hourly schedule to run constantly.</li>
<li>Improved the layout of the Constants help panel.</li>
<li>If the backup root directory is unreadable then the plugin will no longer function.</li>
<li>Update the backups table match the standard WordPress table styles.</li>
<li>Improved styling for the settings dialogue.</li>
<li>Improved styling for the Server Info help tab.</li>
<li>/s/back ups/backups.</li>
<li>Remove Deprecated call to <code>screen_icon</code>.</li>
<li>Updated French translation.</li>
<li>Update the <code>WP CLI</code> command to use the new method for registering command.</li>
<li>Reload the schedules when re-setting up the default schedules so they show up straight away.</li>
<li>s/dpesnt\'t/doesn\'t.</li>
<li>Only show the estimated total schedule size when editing an existing schedule.</li>
<li>Stop stripping 0 from the minutes on hourly backups so that backups at 10 (&#38; 20, etc.) past the hour correctly show.</li>
<li>Disable buttons whilst ajax requests are running.</li>
<li>Move spinners outside the buttons as they didn\'t look very good inside.</li>
<li>Improve the detection of the home path on multisite installs which have WordPress in a subdirectory.</li>
<li>Track the time that the running backup is started and display how long a backup has been running for.</li>
<li>Fix an issue that meant it wasn\'t possible to run multiple manual backups at the same time.</li>
<li>Many other minor improvements.</li>
</ul>

<h4>2.5</h4>

<ul>
<li>BackUpWordPress now requires WordPress 3.7.1 as a minimum.</li>
<li>Remove some old back-compat code that was required because we supported older WP versions.</li>
<li>It\'s now possible to change the email address that notification emails are sent from using the <code>hmbkp_from_email</code> filter.</li>
<li>The spinner is now retina!</li>
<li>Close the PHP Session before starting the backup process to work around the 1 request per session issue. Backup status will now work on sites which happen to call <code>session_start</code>.</li>
<li>Pass <code>max_execution_time</code> and the BackUpWordPress Plugin version back to support. * Include the users real name in support requests</li>
<li>Stop passing <code>$_SERVER</code> with support requests as it can contain things like <code>.htaccess</code> passwords on some server configurations.</li>
<li>Improve the display of the server info in the enable support popup.</li>
<li>New screenshots</li>
<li>Use <code>wp_safe_redirect</code> for internal redirects.</li>
<li>Use <code>wp_is_writable</code> instead of <code>is_writable</code>.</li>
</ul>

<h4>2.4.2</h4>

<ul>
<li>In WordPress Multisite the backups admin page is now located in Network admin instead of the wp-admin of the main site.</li>
<li>Fixed an issue with the new intercom support integration that could cause loading the backups page to timeout</li>
<li>Fixed 3 stray PHP warnings.</li>
<li>BackUpWordPress will now always be loaded before any BackUpWordPress Extensions.</li>
<li>Fixed an issue that could cause a long modal (excludes) to show underneath the WP admin bar.</li>
</ul>

<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4410:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>What if I want I want to back up my site to another destination?</strong></p>

<p>BackUpWordPress Pro supports Dropbox, Google Drive, Amazon S3, Rackspace, Azure, DreamObjects and FTP/SFTP. Check it out here: <a href="http://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">https://bwp.hmn.md</a></p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:62:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.zip";s:4:"tags";a:0:{}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (150, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2797048512', 'no') ; 
INSERT INTO `wp_options` VALUES (151, '_transient_hmbkp_schedule_default-1_database_filesize', '655360', 'no') ; 
INSERT INTO `wp_options` VALUES (152, 'wpseo_titles', 'a:60:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:0:"";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:0:"";s:15:"title-404-wpseo";s:0:"";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:17:"noauthorship-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:17:"noauthorship-page";b:1;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:23:"noauthorship-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (153, 'wpseo', 'a:18:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:11:"ignore_tour";b:1;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:19:"tracking_popup_done";b:1;s:7:"version";s:7:"1.5.2.8";s:11:"alexaverify";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:15:"pinterestverify";s:0:"";s:12:"yandexverify";s:0:"";s:14:"yoast_tracking";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (157, '_transient_doing_cron', '1398568202.0875270366668701171875', 'yes') ; 
INSERT INTO `wp_options` VALUES (159, '_site_transient_timeout_theme_roots', '1398570011', 'yes') ; 
INSERT INTO `wp_options` VALUES (160, '_site_transient_theme_roots', 'a:4:{s:12:"lp-bootstrap";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (1 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (3 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-04-26 02:43:37', '2014-04-26 02:43:37', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-04-26 02:43:37', '2014-04-26 02:43:37', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-04-26 02:43:37', '2014-04-26 02:43:37', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-04-26 02:43:37', '2014-04-26 02:43:37', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3, 1, '2014-04-26 02:43:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-04-26 02:43:49', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=3', 0, 'post', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (1 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (1 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (1 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (14 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'lizponce') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '3') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Sunday 27. April 2014 03:10 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'lizponce', '$P$BjOkeFMnX2C7uXXfxMPr09FSyOguuy/', 'lizponce', 'liz@lizponce.com', '', '2014-04-26 02:43:37', '', 0, 'lizponce') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

